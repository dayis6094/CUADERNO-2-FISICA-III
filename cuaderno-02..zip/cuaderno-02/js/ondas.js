/* Aplicación SPA de lectura del segundo cuaderno. */
(() => {
'use strict';
const pages=window.WAVE_PAGES||[];
if(!pages.length) return;
const $=sel=>document.querySelector(sel);
const app=$('#waves-app'),content=$('#page-content'),paper=$('#paper'),stage=$('#stage'),nav=$('#side-nav');
const pad=n=>String(n).padStart(2,'0');
let page=0,disposeLab=null,mathQueue=Promise.resolve();
const stateKey='fisica-iii-ondas-v2-visitadas';
let visited=[];
try{visited=JSON.parse(localStorage.getItem(stateKey)||'[]').filter(n=>Number.isInteger(n)&&n>=0&&n<pages.length);}catch{};
const chapters=['Portada','Antes de empezar','Panorama','Historia','Fundamentos','Magnitudes','Clasificación','Modelo matemático','Derivación','Laboratorio 01','Laboratorio 02','Laboratorio 03','Laboratorio 04','Laboratorio 05','Fenómenos','Energía','Aplicaciones','Laboratorio 06','Laboratorio 07','Ejercicio 01','Ejercicio 02','Ejercicio 03','Ejercicio 04','Actividad','Consulta','Fuentes'];
$('#pages-count').textContent=`${pages.length} PÁGINAS`;
$('#total-page').textContent=`/ ${pages.length}`;
nav.innerHTML=pages.map((p,i)=>`<button type="button" data-index="${i}" aria-label="Ir a página ${i+1}: ${p.title}"><span class="nav-n">${pad(i+1)}</span><span>${p.title}</span></button>`).join('');
function closeNav(){app.classList.remove('nav-open');$('#sidebar-overlay').hidden=true;$('#toggle-sidebar').setAttribute('aria-expanded','false');}
function toggleNav(){const open=!app.classList.contains('nav-open');app.classList.toggle('nav-open',open);$('#sidebar-overlay').hidden=!open;$('#toggle-sidebar').setAttribute('aria-expanded',String(open));}
$('#toggle-sidebar').addEventListener('click',toggleNav);
$('#close-sidebar').addEventListener('click',closeNav);
$('#sidebar-overlay').addEventListener('click',closeNav);
$('#current-page-btn').addEventListener('click',toggleNav);
nav.addEventListener('click',e=>{const btn=e.target.closest('[data-index]');if(btn)go(Number(btn.dataset.index));});
$('#prev-page').addEventListener('click',()=>go(page-1));
$('#next-page').addEventListener('click',()=>go(page+1));
$('#btn-fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{}});
let mathFallbackUsed=false,mathReady=false;
function readableMath(tex){
 let v=tex.trim();
 const frac=/\\frac\{([^{}]*)\}\{([^{}]*)\}/g;
 for(let i=0;i<6;i++)v=v.replace(frac,'($1)/($2)');
 v=v.replace(/\\frac1f/g,'1/f').replace(/\\sqrt\{([^{}]+)\}/g,'√($1)')
   .replace(/\\(?:boxed|mathrm|operatorname|text)\{([^{}]*)\}/g,'$1')
   .replace(/\\(?:left|right|!|,|;|quad|qquad)/g,' ');
 const macro={lambda:'λ',omega:'ω',mu:'μ',Delta:'Δ',delta:'δ',varphi:'φ',phi:'φ',pi:'π',theta:'θ',partial:'∂',times:'×',cdot:'·',approx:'≈',propto:'∝',sum:'∑',sen:'sen',sin:'sen',cos:'cos',mathrm:'',sqrt:'√',le:'≤',ge:'≥',ne:'≠',infty:'∞',text:'',boxed:''};
 v=v.replace(/\\([A-Za-z]+)/g,(m,key)=>Object.hasOwn(macro,key)?macro[key]:key);
 v=v.replace(/\{([^{}]*)\}/g,'$1').replace(/\\/g,'').replace(/\s+/g,' ');
 return v;
}
function mathFallback(){
 if(mathReady||mathFallbackUsed)return;
 mathFallbackUsed=true;
 const walker=document.createTreeWalker(content,NodeFilter.SHOW_TEXT);const texts=[];
 while(walker.nextNode())if(/\\[\(\[]/.test(walker.currentNode.nodeValue))texts.push(walker.currentNode);
 const r=/\\\(([\s\S]*?)\\\)|\\\[([\s\S]*?)\\\]/g;
 for(const node of texts){const source=node.nodeValue,frag=document.createDocumentFragment();let last=0,m;
   r.lastIndex=0;while((m=r.exec(source))){frag.append(document.createTextNode(source.slice(last,m.index)));const el=document.createElement('span');el.className='math-fallback'+(m[2]!==undefined?' display':'');el.textContent=readableMath(m[1]??m[2]);el.title='Expresión matemática';frag.append(el);last=r.lastIndex;}
   if(last){frag.append(document.createTextNode(source.slice(last)));node.parentNode.replaceChild(frag,node);}
 }
}
function typeset(){
 if(!window.MathJax?.typesetPromise)return;
 mathReady=true;
 const target=content;
 mathQueue=mathQueue.catch(()=>{}).then(()=>window.MathJax.typesetPromise(target.isConnected?[target]:[])).catch(e=>console.warn('Ecuación no renderizada',e));
}
function checkMath(attempt=0){
 if(window.MathJax?.typesetPromise){mathReady=true;if(mathFallbackUsed){mathFallbackUsed=false;go(page);}else typeset();return;}
 if(attempt<60)setTimeout(()=>checkMath(attempt+1),200);else mathFallback();
}
const mathTag=$('#mathjax-library');
mathTag?.addEventListener('load',()=>checkMath());
mathTag?.addEventListener('error',()=>mathFallback());
setTimeout(()=>{if(!mathReady)mathFallback();},2500);
checkMath();
function makeIndex(){
 const box=$('#interactive-index');if(!box)return;
 const groupNames={'Antes de empezar':'INTRODUCCIÓN','Fundamentos':'BASES FÍSICAS','Laboratorio 01':'EXPERIMENTACIÓN','Fenómenos':'FENÓMENOS Y ENERGÍA','Ejercicio 01':'RESOLUCIÓN DE PROBLEMAS','Actividad':'CIERRE ACADÉMICO'};
 let html='<div class="study-index">';
 pages.forEach((p,i)=>{if(i===0||i===1)return;if(groupNames[p.section])html+=`<div class="study-index__group">${groupNames[p.section]}</div>`;html+=`<button type="button" data-goto="${i}"><span>${pad(i+1)}</span><b>${p.title}</b><span class="study-index__dot"></span><small>${pad(i+1)}</small></button>`;});
 box.innerHTML=html+'</div>';
}
function makeGlossary(){const list=$('#glossary-grid'),inp=$('#glossary-search');if(!list||!inp)return;const terms=Object.entries(window.WAVE_GLOSSARY||{}).sort((a,b)=>a[0].localeCompare(b[0],'es'));
 const render=()=>{const q=inp.value.toLocaleLowerCase('es').trim();const items=terms.filter(([title,desc])=>(title+' '+desc).toLocaleLowerCase('es').includes(q));list.innerHTML=items.map(([title,def])=>`<div class="gloss-item"><dt>${title}</dt><dd>${def}</dd></div>`).join('')||'<p class="micro-note">No se encontraron coincidencias.</p>';$('#glossary-count').textContent=`${items.length} de ${terms.length} términos visibles.`;};
 inp.addEventListener('input',render);render();}
function makeQuiz(){
 const quiz=$('#wave-quiz');if(!quiz)return;
 quiz.innerHTML=(window.WAVE_QUIZ||[]).map((item,i)=>`<section class="practice-q"><h3>${pad(i+1)} · ${item.q}</h3>${item.options.map((option,j)=>`<label><input type="radio" name="pq-${i}" value="${j}"> ${option}</label>`).join('')}<div class="feedback" hidden id="feedback-${i}"></div></section>`).join('');
 $('#grade-quiz').addEventListener('click',()=>{
  let score=0,answered=0;
  (window.WAVE_QUIZ||[]).forEach((item,i)=>{
   const choice=document.querySelector(`input[name="pq-${i}"]:checked`),feedback=document.querySelector(`#feedback-${i}`);
   const correct=choice&&Number(choice.value)===item.answer;
   if(choice){answered++;if(correct)score++;}
   feedback.hidden=false;feedback.textContent=`${!choice?'⚠ Sin responder. ':correct?'✓ Correcto. ':'✗ Revisa tu respuesta. '}${item.why}`;
   feedback.style.background=correct?'#e8f7ec':'#fff0e9';feedback.style.color=correct?'#1b6a55':'#965338';
  });
  $('#quiz-score').textContent=`Resultado: ${score} de 5 respuestas correctas · ${answered} contestadas.`;
 });
 $('#reset-quiz').addEventListener('click',()=>{quiz.querySelectorAll('input').forEach(input=>input.checked=false);quiz.querySelectorAll('.feedback').forEach(n=>n.hidden=true);$('#quiz-score').textContent='';});
}
function markProgress(){if(!visited.includes(page))visited.push(page);try{localStorage.setItem(stateKey,JSON.stringify(visited));}catch{};const percent=Math.round(visited.length/pages.length*100);$('#progress-percent').textContent=percent+'%';$('#progress-fill').style.width=percent+'%';}
function go(index){
 if(index<0||index>=pages.length)return;
 if(disposeLab){disposeLab();disposeLab=null;}
 const previous=content;
 if(window.MathJax?.typesetClear) try{MathJax.typesetClear([previous]);}catch{};
 page=index;const p=pages[index];
 content.innerHTML=p.html;
 if(mathFallbackUsed&&!mathReady){mathFallbackUsed=false;setTimeout(mathFallback,0);}
 $('#paper-section').textContent=`VOL. II · ${p.section.toUpperCase()}`;
 $('#top-current').textContent=p.title.toUpperCase();
 $('#current-page').textContent=pad(index+1);
 $('#printed-page').textContent=`${pad(index+1)} / ${pad(pages.length)}`;
 $('#prev-page').disabled=index===0;$('#next-page').disabled=index===pages.length-1;
 const buttons=[...nav.querySelectorAll('button')];buttons.forEach((btn,i)=>{btn.classList.toggle('active',i===index);btn.setAttribute('aria-current',i===index?'page':'false');});
 buttons[index]?.scrollIntoView({block:'nearest',behavior:'instant'});
 stage.scrollTop=0;content.style.animation='none';void content.offsetWidth;content.style.animation='';
 markProgress();closeNav();
 content.querySelectorAll('[data-goto]').forEach(el=>el.addEventListener('click',()=>go(Number(el.dataset.goto))));
 if(index===1)makeIndex();
 if(p.section==='Consulta')makeGlossary();
 if(p.section==='Actividad')makeQuiz();
 const host=content.querySelector('.lab-render');if(host&&window.createWaveLab)disposeLab=window.createWaveLab(host,host.dataset.mode);
 if(mathReady)typeset();else if(mathFallbackUsed)mathFallback();
 try{history.replaceState(null,'',`#pagina-${index+1}`);}catch{}
}
const initialMatch=(location.hash||'').match(/pagina-(\d+)/);
const initial=initialMatch?Math.max(0,Math.min(pages.length-1,Number(initialMatch[1])-1)):0;
window.addEventListener('keydown',e=>{
 if(e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey)return;
 if(['INPUT','SELECT','TEXTAREA','BUTTON','CANVAS'].includes(document.activeElement?.tagName))return;
 if(e.key==='ArrowRight'||e.key==='PageDown'){e.preventDefault();go(page+1);}
 if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();go(page-1);}
 if(e.key==='Escape')closeNav();
});
window.addEventListener('hashchange',()=>{const m=location.hash.match(/pagina-(\d+)/);if(m&&Number(m[1])-1!==page)go(Number(m[1])-1);});
if(window.lucide?.createIcons)window.lucide.createIcons({attrs:{'stroke-width':1.9}});
go(initial);
})();
