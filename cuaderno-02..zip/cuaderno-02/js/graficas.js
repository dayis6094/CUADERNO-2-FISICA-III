/* Motor Canvas original: grilla milimetrada, escala independiente, zoom, pan, selección, estilos y animación. */
(() => {
'use strict';
const PI=Math.PI, TAU=2*PI;
const fmt=(v,n=2)=>Number(v).toLocaleString('es-CO',{maximumFractionDigits:n,minimumFractionDigits:n});
const configs={
 travel:{title:'Forma y propagación · y(x,t)',controls:[['A','Amplitud A','m',.2,2.5,.1,1.4],['f','Frecuencia f','Hz',.2,3,.1,1.1],['lam','Longitud de onda λ','m',1,8,.1,3],['phi','Fase inicial φ','rad',0,6.28,.1,0]],initial:{xRange:12,yRange:7},desc:'La línea es la forma instantánea de la onda. El punto marcado identifica una posición fija del medio.'},
 particles:{title:'Partículas del medio · trayectoria local',controls:[['A','Amplitud A','m',.1,1.4,.1,.7],['f','Frecuencia f','Hz',.1,2.5,.1,.8],['lam','Longitud de onda λ','m',1,9,.2,4],['kind','Tipo de onda','',0,0,0,'transverse']],initial:{xRange:12,yRange:6},desc:'Los puntos grises marcan las posiciones de equilibrio; el punto naranja destaca una partícula del medio.'},
 string:{title:'Onda sobre una cuerda con tensión',controls:[['Ft','Tensión de cuerda Fₜ','N',10,160,5,80],['mu','Densidad lineal μ','kg/m',.01,.2,.005,.04],['A','Amplitud A','m',.1,1.5,.1,.7],['f','Frecuencia de excitación f','Hz',2,22,1,8]],initial:{xRange:12,yRange:6},desc:'El gráfico muestra una onda ideal sobre cuerda; su longitud de onda se calcula según la rapidez y f.'},
 interference:{title:'Onda 1 + onda 2 = resultante',controls:[['A','Amplitud de cada onda','m',.1,2,.1,.8],['phi','Diferencia de fase Δφ','rad',0,6.28,.05,0],['f','Frecuencia f','Hz',.2,2,.1,.7],['lam','Longitud de onda λ','m',1.5,7,.1,3.5]],initial:{xRange:12,yRange:8},desc:'Curva azul: onda 1. Curva naranja: onda 2. Curva turquesa: suma algebraica.'},
 standing:{title:'Modos normales de una cuerda',controls:[['L','Longitud de cuerda L','m',2,9,.5,6],['v','Rapidez de onda v','m/s',1,10,.5,4],['n','Número armónico n','',1,5,1,2],['A','Amplitud máxima','m',.1,1.6,.1,.9]],initial:{xRange:11,yRange:7},desc:'Los extremos permanecen fijos. Los nodos interiores también tienen desplazamiento cero.'},
 doppler:{title:'Frentes de onda de fuente móvil',controls:[['c','Rapidez del sonido c','m/s',300,370,1,343],['vs','Velocidad de fuente vₛ','m/s',0,110,5,35],['f','Frecuencia emitida f','Hz',200,1200,50,600]],initial:{xRange:17,yRange:12},desc:'Los círculos representan frentes emitidos en instantes anteriores. El observador permanece a la derecha.'}
};
const miniIcon=(name,fallback)=>`<i data-lucide="${name}" aria-hidden="true"></i><span class="icon-fallback">${fallback}</span>`;
const controlHTML=c=>c[0]==='kind'?`<label class="field-group"><span>${c[1]}</span><select data-param="kind"><option value="transverse">Transversal</option><option value="longitudinal">Longitudinal</option></select></label>`:`<label class="field-group"><span>${c[1]}<output data-out="${c[0]}">${fmt(c[6],c[5]<.01?3:1)} ${c[2]}</output></span><input aria-label="${c[1]}" type="range" data-param="${c[0]}" min="${c[3]}" max="${c[4]}" step="${c[5]}" value="${c[6]}"></label>`;
function setup(host,mode){
 const config=configs[mode]; if(!config) return()=>{};
 host.innerHTML=`<div class="lab-layout"><div><section class="lab-screen" aria-label="Plano cartesiano interactivo"><div class="graph-head"><strong>${config.title}</strong><span>PLANO DINÁMICO · ejes graduados</span></div><div class="graph-canvas-wrap"><canvas aria-label="Gráfica interactiva tipo GeoGebra con cuadrícula, ejes y escala ajustable" role="img" tabindex="0"></canvas></div><div class="graph-tools"><button data-tool="zoom-in" title="Acercar vista" aria-label="Zoom in">${miniIcon('zoom-in','＋')}</button><button data-tool="zoom-out" title="Alejar vista" aria-label="Zoom out">${miniIcon('zoom-out','−')}</button><button data-tool="pan" title="Arrastrar plano; arrastra los ejes para cambiar sus escalas" aria-label="Arrastrar plano" aria-pressed="true">${miniIcon('hand','☞')}</button><button data-tool="select" title="Seleccionar y leer coordenadas" aria-label="Seleccionar un punto" aria-pressed="false">${miniIcon('mouse-pointer-2','⌖')}</button><button data-tool="reset" title="Restablecer vista" aria-label="Restablecer vista">${miniIcon('rotate-ccw','↻')}</button><span class="graph-spacer"></span><span class="point-info" data-pointer-info>x · y</span><div class="graph-style"><button data-tool="style" title="Estilo de trazo" aria-label="Cambiar estilos">${miniIcon('palette','🎨')}</button><div class="style-pop" data-style-menu hidden><strong style="font-size:12px;color:#244e5a">Estilo del gráfico</strong><label>Color <input type="color" value="#118e83" data-style="color"></label><label>Grosor <input type="range" min="1" max="6" value="2.8" step=".5" data-style="width"></label><label>Trazo <select data-style="dash"><option value="solid">Continuo</option><option value="dash">Discontinuo</option><option value="dot">Punteado</option></select></label></div></div></div></section><p class="lab-caption">${config.desc}</p><p class="micro-note">Usa la rueda o dos dedos para zoom; arrastra el eje X o Y para cambiar su escala independientemente.</p></div><aside class="control-card"><h3>⚙ Parámetros físicos</h3>${config.controls.map(controlHTML).join('')}<div class="lab-stats" data-stats></div><div class="lab-actions"><button class="play" data-action="play">⏸ Pausar</button><button data-action="reset">↺ Reiniciar</button></div></aside></div>`;
 if(window.lucide?.createIcons) window.lucide.createIcons({attrs:{'stroke-width':1.8}});
 const $=sel=>host.querySelector(sel),cv=$('canvas'),ctx=cv.getContext('2d');
 if(!ctx) return()=>{};
 const values=Object.fromEntries(config.controls.map(c=>[c[0],c[6]]));
 let playing=!window.matchMedia('(prefers-reduced-motion: reduce)').matches,t=0,last=0,raf=0,closed=false;
 const state={centerX:0,centerY:0,scaleX:1,scaleY:1,mode:'pan',style:{color:'#118e83',width:2.8,dash:'solid'},selected:null,width:0,height:0,pointers:new Map(),drag:null,pinch:null};
 const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
 function initialScale(){state.centerX=mode==='standing'?values.L/2:0;state.centerY=0;state.scaleX=state.width/(config.initial.xRange||12);state.scaleY=state.height/(config.initial.yRange||7);}
 const wx=x=>(x-state.width/2)/state.scaleX+state.centerX;
 const wy=y=>(state.height/2-y)/state.scaleY+state.centerY;
 const px=x=>(x-state.centerX)*state.scaleX+state.width/2;
 const py=y=>(state.centerY-y)*state.scaleY+state.height/2;
 const tickStep=(scale)=>{const raw=75/scale,pow=Math.pow(10,Math.floor(Math.log10(raw))),n=raw/pow;return (n<=1?1:n<=2?2:n<=5?5:10)*pow;};
 function drawGrid(){
  const w=state.width,h=state.height;ctx.fillStyle='#ffffff';ctx.fillRect(0,0,w,h);
  const sx=tickStep(state.scaleX),sy=tickStep(state.scaleY),xmin=wx(0),xmax=wx(w),ymin=wy(h),ymax=wy(0);
  const axisX=clamp(px(0),0,w),axisY=clamp(py(0),0,h);
  const grid=(vertical,step,minor=false)=>{
   if(!Number.isFinite(step)||step<=0)return;
   const a=vertical?xmin:ymin,b=vertical?xmax:ymax;
   ctx.lineWidth=minor?.65:1;
   ctx.strokeStyle=minor?'#edf4f6':'#dbe8ec';ctx.beginPath();
   let total=0;
   for(let i=Math.ceil((a-1e-8)/step);i<=Math.floor((b+1e-8)/step)&&total++<400;i++){
    if(minor&&i%5===0)continue;
    const at=vertical?px(i*step):py(i*step);
    if(vertical){ctx.moveTo(at,0);ctx.lineTo(at,h);}else{ctx.moveTo(0,at);ctx.lineTo(w,at);}
   }ctx.stroke();
  };
  grid(true,sx/5,true);grid(false,sy/5,true);grid(true,sx);grid(false,sy);
  ctx.lineWidth=1.6;ctx.strokeStyle='#8199a7';ctx.beginPath();ctx.moveTo(0,axisY);ctx.lineTo(w,axisY);ctx.moveTo(axisX,0);ctx.lineTo(axisX,h);ctx.stroke();
  ctx.fillStyle='#668294';ctx.font='10px DM Sans, sans-serif';ctx.textAlign='center';ctx.textBaseline='top';
  let nt=0;
  for(let i=Math.ceil(xmin/sx);i<=Math.floor(xmax/sx)&&nt++<100;i++){
   const x=i*sx,X=px(x);ctx.strokeStyle='#7a919d';ctx.beginPath();ctx.moveTo(X,axisY-4);ctx.lineTo(X,axisY+4);ctx.stroke();ctx.fillText(Number(x.toPrecision(6)).toString(),X,clamp(axisY+7,4,h-15));
  }
  ctx.textAlign='right';ctx.textBaseline='middle';nt=0;
  for(let i=Math.ceil(ymin/sy);i<=Math.floor(ymax/sy)&&nt++<100;i++){
   const y=i*sy,Y=py(y);ctx.beginPath();ctx.moveTo(axisX-4,Y);ctx.lineTo(axisX+4,Y);ctx.stroke();if(i!==0)ctx.fillText(Number(y.toPrecision(6)).toString(),clamp(axisX-8,25,w-5),Y);
  }
  ctx.textAlign='left';ctx.textBaseline='bottom';ctx.font='700 11px DM Sans, sans-serif';ctx.fillStyle='#54859a';ctx.fillText('x (m)',w-42,clamp(axisY-5,14,h-20));ctx.fillText('y (m)',clamp(axisX+9,9,w-45),16);
 }
 function lineFn(fn,color=state.style.color,width=state.style.width,dash=state.style.dash,x0=wx(0),x1=wx(state.width)){
  ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.setLineDash(dash==='dash'?[10,6]:dash==='dot'?[2,6]:[]);
  const N=Math.max(220,Math.min(1100,Math.round(state.width*1.4)));
  for(let i=0;i<=N;i++){
   const x=x0+(x1-x0)*i/N,y=fn(x);if(!Number.isFinite(y))continue;
   if(i===0)ctx.moveTo(px(x),py(y));else ctx.lineTo(px(x),py(y));
  }ctx.stroke();ctx.setLineDash([]);
 }
 function disc(x,y,r,color,stroke='#fff'){ctx.beginPath();ctx.arc(px(x),py(y),r,0,TAU);ctx.fillStyle=color;ctx.fill();ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke();}
 function drawWave(){
  let A=+values.A||1,f=+values.f||1,lam=+values.lam||3,k=TAU/lam,phi=+values.phi||0;
  let v=lam*f;
  if(mode==='string'){v=Math.sqrt(+values.Ft/+values.mu);lam=v/f;k=TAU/lam;}
  if(mode==='travel'||mode==='string'){lineFn(x=>A*Math.sin(k*x-TAU*f*t+phi));disc(0,A*Math.sin(-TAU*f*t+phi),5,'#d99246');}
  if(mode==='interference'){
   const p=+values.phi;
   const a=x=>A*Math.sin(k*x-TAU*f*t), b=x=>A*Math.sin(k*x-TAU*f*t+p);
   lineFn(a,'#3d87cc',2,'dash');lineFn(b,'#d08c52',2,'dash');lineFn(x=>a(x)+b(x));
  }
  if(mode==='standing'){
   let n=+values.n,L=+values.L,v=+values.v,f=n*v/(2*L),amp=+values.A;
   ctx.fillStyle='#f1f7f3';ctx.fillRect(px(0),py(1.9),px(L)-px(0),py(-1.9)-py(1.9));
   lineFn(x=>x<0||x>L?NaN:2*amp*Math.sin(n*PI*x/L)*Math.cos(TAU*f*t),state.style.color,state.style.width,state.style.dash,0,L);
   lineFn(x=>x<0||x>L?NaN:2*amp*Math.sin(n*PI*x/L),'#8fbba5',1,'dot',0,L);
   for(let j=0;j<=n;j++)disc(j*L/n,0,4,'#243e55');
   for(let j=0;j<n;j++){const xx=(j+.5)*L/n; ctx.fillStyle='#496b73';ctx.font='10px DM Sans';ctx.textAlign='center';ctx.fillText('vientre',px(xx),py(-2.2));}
  }
  if(mode==='particles'){
   const A=+values.A,f=+values.f,lam=+values.lam,k=TAU/lam,isLong=values.kind==='longitudinal';
   ctx.setLineDash([4,4]);ctx.strokeStyle='#95c6c1';ctx.beginPath();ctx.moveTo(0,py(0));ctx.lineTo(state.width,py(0));ctx.stroke();ctx.setLineDash([]);
   const xmin=Math.max(wx(0),-6),xmax=Math.min(wx(state.width),6);
   for(let i=0;i<33;i++){
    const x=-6+i*12/32;if(x<xmin-.3||x>xmax+.3)continue;
    const phase=k*x-TAU*f*t;
    const y=isLong?0:A*Math.sin(phase),X=isLong?x+A*.6*Math.sin(phase):x;
    ctx.globalAlpha=.6;disc(x,0,2.8,'#a4b9bd');ctx.globalAlpha=1;
    disc(X,y,i===16?7:3.8,i===16?'#df8a37':state.style.color);
   }
   ctx.fillStyle='#61808c';ctx.font='11px DM Sans';ctx.fillText(isLong?'Compresiones y rarefacciones ↔':'Vibración de cada punto ↑↓',10,20);
  }
  if(mode==='doppler'){
   const ratio=+values.vs/+values.c;
   const speed=2.65,sourceSpeed=ratio*speed,interval=.42;
   const age=t%interval;
   // Each wavefront expands at propagation speed from the source position at emission.
   const sourceX=Math.sin(t*.11)*1.1;
   for(let i=0;i<12;i++){
    const elapsed=age+i*interval,r=speed*elapsed;
    const cx=sourceX-sourceSpeed*elapsed;
    ctx.beginPath();ctx.ellipse(px(cx),py(0),r*state.scaleX,r*state.scaleY,0,0,TAU);
    ctx.strokeStyle=i%2===0?'#7dbcb5':'#b8d2c9';ctx.lineWidth=1.6;ctx.stroke();
   }
   disc(sourceX,0,7,'#df8a37');disc(6,0,7,'#3676bc');
   ctx.fillStyle='#6c8790';ctx.font='700 11px DM Sans';ctx.textAlign='center';ctx.fillText('Fuente',px(sourceX),py(-.8));ctx.fillText('Observador',px(6),py(-.8));
  }
  if(state.selected){const {x,y}=state.selected;ctx.setLineDash([4,5]);ctx.strokeStyle='#ba8753';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(px(x),0);ctx.lineTo(px(x),state.height);ctx.moveTo(0,py(y));ctx.lineTo(state.width,py(y));ctx.stroke();ctx.setLineDash([]);disc(x,y,5,'#d9954e');}
 }
 function stats(){
  const A=+values.A||0,f=+values.f||0,lam=+values.lam||1,disp=host.querySelector('[data-stats]');let data=[];
  if(mode==='travel')data=[['Rapidez · v',`${fmt(lam*f)} m/s`],['Período · T',`${fmt(1/f)} s`],['ω',`${fmt(TAU*f)} rad/s`],['k',`${fmt(TAU/lam)} rad/m`]];
  if(mode==='particles')data=[['Rapidez',`${fmt(lam*f)} m/s`],['Período',`${fmt(1/f)} s`]];
  if(mode==='string'){const v=Math.sqrt(+values.Ft/+values.mu);data=[['Rapidez · v',`${fmt(v)} m/s`],['Longitud · λ',`${fmt(v/+values.f)} m`],['Período',`${fmt(1/+values.f)} s`],['Tensión',`${fmt(+values.Ft,0)} N`]];}
  if(mode==='interference')data=[['Amplitud total',`${fmt(2*A*Math.abs(Math.cos(+values.phi/2)))} m`],['Δφ',`${fmt(+values.phi)} rad`]];
  if(mode==='standing'){const f=+values.n*+values.v/(2*+values.L);data=[['Frecuencia · fₙ',`${fmt(f)} Hz`],['Longitud · λₙ',`${fmt(2*+values.L/+values.n)} m`],['Nodos',`${+values.n+1}`],['Vientres',`${+values.n}`]];}
  if(mode==='doppler'){const c=+values.c,vs=+values.vs,ff=+values.f;data=[['Acercándose',`${fmt(ff*c/(c-vs))} Hz`],['Alejándose',`${fmt(ff*c/(c+vs))} Hz`],['vₛ / c',`${fmt(vs/c*100,1)} %`]];}
  disp.innerHTML=data.map(([name,v])=>`<div><span>${name}</span><strong>${v}</strong></div>`).join('');
 }
 function render(){if(closed)return;ctx.clearRect(0,0,state.width,state.height);drawGrid();ctx.save();ctx.beginPath();ctx.rect(0,0,state.width,state.height);ctx.clip();drawWave();ctx.restore();}
 function resize(){if(closed)return;const rect=cv.getBoundingClientRect();if(!rect.width||!rect.height)return;const oldw=state.width,oldh=state.height;state.width=rect.width;state.height=rect.height;const dpr=Math.min(devicePixelRatio||1,2);cv.width=Math.round(rect.width*dpr);cv.height=Math.round(rect.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);if(!oldw||!oldh)initialScale();else{state.scaleX*=state.width/oldw;state.scaleY*=state.height/oldh;}render();}
 const ro=window.ResizeObserver?new ResizeObserver(resize):null;ro?.observe(cv.parentElement);window.addEventListener('resize',resize);resize();
 const pos=e=>{const r=cv.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};};
 function zoom(mult,around={x:state.width/2,y:state.height/2}){
  const x=wx(around.x),y=wy(around.y);state.scaleX=clamp(state.scaleX*mult,8,1000);state.scaleY=clamp(state.scaleY*mult,8,1000);
  state.centerX=x-(around.x-state.width/2)/state.scaleX;state.centerY=y+(around.y-state.height/2)/state.scaleY;
  render();
 }
 const label=$('[data-pointer-info]');
 function pointerPosition(pt){label.textContent=`${fmt(wx(pt.x))} · ${fmt(wy(pt.y))}`;}
 function pointerDown(e){if(e.pointerType==='mouse'&&e.button!==0)return;const pt=pos(e);state.pointers.set(e.pointerId,pt);cv.setPointerCapture(e.pointerId);pointerPosition(pt);
  if(state.pointers.size===2){const q=[...state.pointers.values()];state.pinch={dist:Math.hypot(q[0].x-q[1].x,q[0].y-q[1].y),sx:state.scaleX,sy:state.scaleY,centerX:state.centerX,centerY:state.centerY,mx:(q[0].x+q[1].x)/2,my:(q[0].y+q[1].y)/2};state.drag=null;return;}
  if(state.mode==='select'){state.selected={x:wx(pt.x),y:wy(pt.y)};render();return;}
  const axisY=py(0),axisX=px(0);
  state.drag={pt,centerX:state.centerX,centerY:state.centerY,scaleX:state.scaleX,scaleY:state.scaleY,axis:(Math.abs(pt.y-axisY)<11&&Math.abs(pt.x-axisX)>25)?'x':(Math.abs(pt.x-axisX)<11&&Math.abs(pt.y-axisY)>25)?'y':'pan'};
 }
 function pointerMove(e){const pt=pos(e);pointerPosition(pt);if(!state.pointers.has(e.pointerId))return;state.pointers.set(e.pointerId,pt);
  if(state.pinch&&state.pointers.size>=2){const q=[...state.pointers.values()];const dist=Math.hypot(q[0].x-q[1].x,q[0].y-q[1].y);const mult=clamp(dist/Math.max(state.pinch.dist,1),.25,4);state.scaleX=clamp(state.pinch.sx*mult,8,1000);state.scaleY=clamp(state.pinch.sy*mult,8,1000);const mid={x:(q[0].x+q[1].x)/2,y:(q[0].y+q[1].y)/2};state.centerX=state.pinch.centerX-(mid.x-state.pinch.mx)/state.scaleX;state.centerY=state.pinch.centerY+(mid.y-state.pinch.my)/state.scaleY;render();return;}
  if(!state.drag)return;const d=state.drag,dx=pt.x-d.pt.x,dy=pt.y-d.pt.y;
  if(d.axis==='pan'){state.centerX=d.centerX-dx/d.scaleX;state.centerY=d.centerY+dy/d.scaleY;}
  else if(d.axis==='x'){const anchor=Math.abs(d.pt.x-state.width/2);state.scaleX=clamp(d.scaleX*(1+dx/Math.max(anchor,70)),8,1000);}
  else{const anchor=Math.abs(d.pt.y-state.height/2);state.scaleY=clamp(d.scaleY*(1-dy/Math.max(anchor,70)),8,1000);}
  render();
 }
 function pointerUp(e){state.pointers.delete(e.pointerId);state.drag=null;if(state.pointers.size<2)state.pinch=null;}
 cv.addEventListener('pointerdown',pointerDown);cv.addEventListener('pointermove',pointerMove);cv.addEventListener('pointerup',pointerUp);cv.addEventListener('pointercancel',pointerUp);
 cv.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1.12:1/1.12,pos(e));},{passive:false});
 cv.addEventListener('keydown',e=>{if(e.key==='+'||e.key==='='){zoom(1.2);e.preventDefault();}else if(e.key==='-'){zoom(1/1.2);e.preventDefault();}else if(e.key.startsWith('Arrow')){if(e.key==='ArrowLeft')state.centerX-=.4;if(e.key==='ArrowRight')state.centerX+=.4;if(e.key==='ArrowUp')state.centerY+=.4;if(e.key==='ArrowDown')state.centerY-=.4;render();e.preventDefault();}});
 host.querySelectorAll('[data-param]').forEach(el=>el.addEventListener('input',()=>{
  values[el.dataset.param]=el.tagName==='SELECT'?el.value:Number(el.value);
  const out=host.querySelector(`[data-out="${el.dataset.param}"]`);if(out)out.textContent=`${fmt(+el.value,(+el.step<.01)?3:1)} ${config.controls.find(c=>c[0]===el.dataset.param)[2]}`;
  if(mode==='standing'&&el.dataset.param==='L')state.centerX=+values.L/2;
  stats();render();
 }));
 host.querySelectorAll('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const cmd=btn.dataset.tool;
  if(cmd==='zoom-in')zoom(1.25);if(cmd==='zoom-out')zoom(.8);if(cmd==='reset'){initialScale();state.selected=null;render();}
  if(cmd==='style')$('[data-style-menu]').hidden=!$('[data-style-menu]').hidden;
  if(cmd==='pan'||cmd==='select'){state.mode=cmd;state.selected=null;cv.classList.toggle('is-select',cmd==='select');host.querySelectorAll('[data-tool="pan"],[data-tool="select"]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.tool===cmd)));render();}
 }));
 host.querySelectorAll('[data-style]').forEach(el=>el.addEventListener('input',()=>{state.style[el.dataset.style]=el.dataset.style==='width'?Number(el.value):el.value;render();}));
 const playBtn=$('[data-action="play"]');
 function updatePlay(){playBtn.textContent=playing?'⏸ Pausar':'▶ Reproducir';}
 playBtn.addEventListener('click',()=>{playing=!playing;updatePlay();});updatePlay();
 $('[data-action="reset"]').addEventListener('click',()=>{t=0;for(const c of config.controls){values[c[0]]=c[6];const el=host.querySelector(`[data-param="${c[0]}"]`);if(el)el.value=c[6];const out=host.querySelector(`[data-out="${c[0]}"]`);if(out)out.textContent=`${fmt(c[6],c[5]<.01?3:1)} ${c[2]}`;}initialScale();state.selected=null;stats();render();});
 function loop(now){if(closed)return;raf=requestAnimationFrame(loop);if(now-last<29)return;const dt=Math.min((now-last)/1000,.05);last=now;if(playing)t+=dt;render();}
 stats();raf=requestAnimationFrame(loop);
 return()=>{closed=true;cancelAnimationFrame(raf);ro?.disconnect();window.removeEventListener('resize',resize);};
}
window.createWaveLab=setup;
})();
