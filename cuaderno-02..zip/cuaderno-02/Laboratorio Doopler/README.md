# Simulador Avanzado del Efecto Doppler Acústico
### Aplicación Web Educativa y Científica para Física III

Este proyecto contiene una aplicación web completa, rigurosa y didáctica para la exploración interactiva del **Efecto Doppler acústico en un medio homogéneo e inmóvil**, desarrollada en español (`es-CO`).

---

## 🚀 Inicio Rápido

La aplicación es completamente estática y autónoma. No requiere dependencias de instalación (`npm`, `pip`, etc.) para su uso directo en el navegador.

1. **Apertura Directa:**  
   Haz doble clic sobre el archivo [`index.html`](file:///c:/Users/hogar/OneDrive/Escritorio/UTP%20DEIRY/2026-2/FISICA%20III/Simulador%20Doopler/index.html) para abrirlo en cualquier navegador web moderno (Google Chrome, Edge, Firefox, Safari).

2. **Servidor Local (Opcional):**  
   ```bash
   python -m http.server 8000
   ```
   Luego ingresa a `http://localhost:8000`.

---

## 📁 Estructura del Proyecto

```
Simulador Doopler/
├── index.html               # Estructura semántica HTML5 y maquetación responsiva
├── css/
│   └── styles.css           # Estilos visuales modernos, temas Claro/Oscuro y adaptabilidad móvil
├── js/
│   ├── physics.js           # Motor de física acústica analítico y determinista
│   ├── audio.js             # Módulo de Web Audio API (pulsos y síntesis tonal)
│   ├── renderer.js          # Renderizado Canvas 2D (frentes, conos de Mach, iconos, regla)
│   ├── charts.js            # Motor de gráficas sincronizadas en tiempo real
│   ├── guided.js            # Sistema curricular interactivo con los 8 escenarios
│   ├── verifier.js          # Verificador de pruebas científicas en el navegador
│   ├── codelab.js           # Laboratorio de trayectorias programables en sandbox seguro
│   └── app.js               # Controlador maestro de la aplicación y ciclo de animación
├── test_doppler.py          # Suite de verificación científica independiente en Python 3.14
├── test_physics_js.js       # Suite de verificación unitaria en Node.js
├── MANUAL_USUARIO.md        # Manual detallado de uso didáctico y marco teórico
└── README.md                # Este documento de presentación técnica
```

---

## 🔬 Verificación Científica Automatizada

Para ejecutar las pruebas científicas en terminal con Python:

```bash
python test_doppler.py
```

Para ejecutar las pruebas en Node.js:

```bash
node test_physics_js.js
```

---

## 🛠️ Tecnologías Empleadas

- **HTML5 & CSS3:** Variables CSS nativas, Grid, Flexbox, soporte de accesibilidad WCAG y pantallas táctiles.
- **JavaScript Moderno (ES6+):** Programación orientada a objetos modular y desacoplada sin dependencias externas obligatorias.
- **HTML5 Canvas 2D:** Renderizado vectorial de alto rendimiento a 60+ FPS con compensación de `devicePixelRatio`.
- **Web Audio API:** Generación de pulsos de llegada con envolvente exponencial y osciladores continuos con transposición didáctica visible.
- **KaTeX:** Renderizado nítido de fórmulas matemáticas LaTeX con soporte fuera de línea.
- **Python 3.14:** Verificación científica independiente de ecuaciones cinemáticas, raíces analíticas y geometría cónica.

