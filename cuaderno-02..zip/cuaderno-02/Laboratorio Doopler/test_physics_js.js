const { DopplerPhysics } = require('./js/physics.js');

const c = 340.0;
const f_e = 1000.0;
const v = 34.0;
const tol = 1e-4;

function assertClose(actual, expected, desc) {
    if (Math.abs(actual - expected) > tol) {
        console.error(`FAIL: ${desc} -> Obtenido: ${actual}, Esperado: ${expected}`);
        process.exit(1);
    } else {
        console.log(`OK: ${desc} -> ${actual.toFixed(6)}`);
    }
}

console.log('--- Probando js/physics.js en Node.js ---');

// 1. Reposo
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e, c, v_f: 0, v_o: 0, x_f0: { x: 0, y: 0 }, x_o0: { x: 340, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].fo_theoretical, 1000.0, 'Ambos en reposo');
}

// 2. Fuente aproxima a 34 m/s
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e, c, v_f: v, v_o: 0, x_f0: { x: 0, y: 0 }, x_o0: { x: 500, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].fo_theoretical, 1000.0 * (340.0 / 306.0), 'Fuente aproxima a 34 m/s');
}

// 3. Fuente aleja a 34 m/s
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e, c, v_f: -v, v_o: 0, x_f0: { x: 0, y: 0 }, x_o0: { x: 500, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].fo_theoretical, 1000.0 * (340.0 / 374.0), 'Fuente aleja a 34 m/s');
}

// 4. Observador aproxima a 34 m/s
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e, c, v_f: 0, v_o: -v, x_f0: { x: 0, y: 0 }, x_o0: { x: 500, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].fo_theoretical, 1100.0, 'Observador aproxima a 34 m/s');
}

// 5. Observador aleja a 34 m/s
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e, c, v_f: 0, v_o: v, x_f0: { x: 0, y: 0 }, x_o0: { x: 500, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].fo_theoretical, 900.0, 'Observador aleja a 34 m/s');
}

// 6. Ambos misma velocidad
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e, c, v_f: v, v_o: v, x_f0: { x: 0, y: 0 }, x_o0: { x: 500, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].fo_theoretical, 1000.0, 'Ambos misma velocidad');
}

// 7. Tiempo de vuelo exacto
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e: 1, c: 340.0, v_f: 0, v_o: 0, x_f0: { x: 0, y: 0 }, x_o0: { x: 340, y: 0 }, is2D: false });
    assertClose(engine.receptions[0].tr, 1.0, 'Tiempo de vuelo a 340 m');
}

// 8. Mach 2 semiángulo
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e: 1, c: 340.0, v_f: 680.0, v_o: 0, is2D: true });
    assertClose(engine.getMachAngle() * 180 / Math.PI, 30.0, 'Semiángulo cono Mach 2');
}

// 9. Medición empírica independiente f_medida = 1 / Delta t_r
{
    const engine = new DopplerPhysics();
    engine.updateParameters({ f_e: 1000.0, c: 340.0, v_f: 34.0, v_o: 0, x_f0: { x: 0, y: 0 }, x_o0: { x: 1000, y: 0 }, is2D: false });
    const rec2 = engine.receptions[1];
    assertClose(rec2.measuredFreq, 1000.0 * (340.0 / 306.0), 'Medición empírica por llegadas discretas');
}

console.log('--- ¡Todos los tests de física en JavaScript pasaron al 100%! ---');

