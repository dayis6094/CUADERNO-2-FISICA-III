/**
 * audio.js - Sistema de Audio y Sonificación con Web Audio API
 * 
 * Implementa:
 * - Activación obligatoria bajo interacción explícita del usuario (política de navegadores).
 * - Modo 1: Pulsos de llegada (blip/sonar de cruce físico con ritmo exacto de t_r).
 * - Modo 2: Comparación tonal (oscilador continuo con factor didáctico de transposición visible).
 * - Envolventes suaves (Attack-Decay) para prevenir clics o distorsiones acústicas.
 * - Sonificación ilustrativa del frente de choque de Mach sincronizada con el cruce geométrico.
 * - Silenciamiento y cancelación instantánea en pausa, reinicio o deslizamiento temporal (seek).
 */

class DopplerAudioEngine {
    constructor() {
        this.ctx = null;
        this.isAudioEnabled = false;
        this.isMuted = false;
        this.masterVolume = 0.5;

        // Modos de audio
        // 'pulses': sonido por cada llegada física
        // 'tones': comparación tonal continua
        this.mode = 'pulses';

        // Escala pedagógica para transponer frecuencias bajas visuales a tonos audibles
        // Por defecto: 2 Hz visuales -> 440 Hz audibles (La 4), factor = 220
        this.pitchScaleFactor = 220.0;

        // Nodos Web Audio
        this.masterGain = null;
        this.sourceOsc = null;
        this.sourceGain = null;
        this.observerOsc = null;
        this.observerGain = null;

        // Registro de eventos reproducidos para evitar duplicados en scrubbing
        this.playedReceptionIds = new Set();
        this.machBoomPlayed = false;
    }

    /**
     * Inicializa el contexto de audio tras acción del usuario.
     */
    async init() {
        if (!this.ctx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioContext();

            // Ganancia maestra
            this.masterGain = this.ctx.createGain();
            this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.masterVolume, this.ctx.currentTime);
            this.masterGain.connect(this.ctx.destination);
        }

        if (this.ctx.state === 'suspended') {
            await this.ctx.resume();
        }

        this.isAudioEnabled = true;
        return true;
    }

    /**
     * Detiene y cancela todos los sonidos y osciladores inmediatamente.
     */
    stopAll() {
        if (!this.ctx) return;
        const now = this.ctx.currentTime;

        if (this.sourceOsc) {
            try {
                this.sourceGain.gain.cancelScheduledValues(now);
                this.sourceGain.gain.setValueAtTime(0, now);
                this.sourceOsc.stop(now);
                this.sourceOsc.disconnect();
            } catch (e) {}
            this.sourceOsc = null;
        }

        if (this.observerOsc) {
            try {
                this.observerGain.gain.cancelScheduledValues(now);
                this.observerGain.gain.setValueAtTime(0, now);
                this.observerOsc.stop(now);
                this.observerOsc.disconnect();
            } catch (e) {}
            this.observerOsc = null;
        }
    }

    /**
     * Reinicia el registro de eventos reproducidos (al reiniciar simulación o al hacer seek).
     */
    resetPlaybackTracking(currentTime = 0) {
        this.playedReceptionIds.clear();
        this.machBoomPlayed = false;
        this.stopAll();
    }

    /**
     * Ajusta el volumen maestro (0 a 1).
     */
    setVolume(val) {
        this.masterVolume = Math.max(0, Math.min(1, val));
        if (this.masterGain && this.ctx) {
            const now = this.ctx.currentTime;
            this.masterGain.gain.cancelScheduledValues(now);
            this.masterGain.gain.linearRampToValueAtTime(
                this.isMuted ? 0 : this.masterVolume,
                now + 0.05
            );
        }
    }

    /**
     * Alterna o establece el estado de silencio (Mute).
     */
    toggleMute(forceState) {
        this.isMuted = forceState !== undefined ? forceState : !this.isMuted;
        this.setVolume(this.masterVolume);
        return this.isMuted;
    }

    /**
     * Cambia de modo de audio: 'pulses' o 'tones'.
     */
    setMode(mode) {
        if (this.mode !== mode) {
            this.mode = mode;
            this.stopAll();
        }
    }

    /**
     * Ajusta el factor de transposición tonal didáctica.
     */
    setPitchScaleFactor(factor) {
        this.pitchScaleFactor = Math.max(1, factor);
    }

    /**
     * Reproduce un pulso suave percusivo cuando una onda cruza al observador.
     */
    playArrivalPulse(freqHint = 880) {
        if (!this.isAudioEnabled || this.isMuted || !this.ctx || this.ctx.state !== 'running') return;
        if (this.mode !== 'pulses') return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        // Tono didáctico agradable y nítido
        osc.frequency.setValueAtTime(Math.min(2200, Math.max(220, freqHint)), now);

        // Envolvente Attack-Decay suave (~35 ms) sin clic
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.35, now + 0.005);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.040);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.045);
        setTimeout(() => {
            try { osc.disconnect(); gain.disconnect(); } catch (e) {}
        }, 50);
    }

    /**
     * Sonificación ilustrativa del estampido sónico de Mach.
     * Se produce únicamente al cruzar la envolvente de choque con el observador.
     */
    playMachBoom() {
        if (!this.isAudioEnabled || this.isMuted || !this.ctx || this.ctx.state !== 'running') return;

        const now = this.ctx.currentTime;
        // Ruido filtrado de baja frecuencia para efecto de estampido lejano
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(45, now + 0.25);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.exponentialRampToValueAtTime(0.6, now + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.36);
        setTimeout(() => {
            try { osc.disconnect(); gain.disconnect(); } catch (e) {}
        }, 380);
    }

    /**
     * Actualiza el audio en cada tick de la simulación.
     */
    update(simState, isPlaying) {
        if (!this.isAudioEnabled || !this.ctx || this.ctx.state !== 'running' || !isPlaying) {
            if (!isPlaying) {
                this.stopAll();
            }
            return;
        }

        const now = this.ctx.currentTime;

        // 1. Modo Pulsos
        if (this.mode === 'pulses') {
            for (const rec of simState.pastReceptions) {
                if (!this.playedReceptionIds.has(rec.wfId)) {
                    this.playedReceptionIds.add(rec.wfId);
                    // Frecuencia sugerida para modular ligeramente el pitch del pulso
                    let tonePitch = 880;
                    if (rec.measuredFreq && isFinite(rec.measuredFreq)) {
                        tonePitch = 880 * (rec.measuredFreq / (simState.currentTheoretical || 1));
                    }
                    this.playArrivalPulse(tonePitch);
                }
            }

            // Mach boom si acaba de cruzar
            if (simState.machShockPassed && !this.machBoomPlayed) {
                this.machBoomPlayed = true;
                this.playMachBoom();
            }
        }

        // 2. Modo Comparación Tonal
        if (this.mode === 'tones') {
            // Calcular frecuencias transpuestas audibles
            const f_emit_audio = (simState.lastReception ? simState.lastReception.wfId : 2) * this.pitchScaleFactor;
            const f_e = (typeof window.physicsEngine !== 'undefined' ? window.physicsEngine.f_e : 2.0);
            const baseAudioFreq = f_e * this.pitchScaleFactor;

            let obsAudioFreq = baseAudioFreq;
            if (simState.currentTheoretical && isFinite(simState.currentTheoretical) && simState.currentTheoretical > 0) {
                obsAudioFreq = simState.currentTheoretical * this.pitchScaleFactor;
            }
            obsAudioFreq = Math.min(3000, Math.max(50, obsAudioFreq));

            // Iniciar osciladores continuos si no existen
            if (!this.observerOsc) {
                this.observerOsc = this.ctx.createOscillator();
                this.observerGain = this.ctx.createGain();
                this.observerOsc.type = 'sine';
                this.observerOsc.frequency.setValueAtTime(obsAudioFreq, now);

                this.observerGain.gain.setValueAtTime(0.0001, now);
                this.observerGain.gain.linearRampToValueAtTime(0.25, now + 0.1);

                this.observerOsc.connect(this.observerGain);
                this.observerGain.connect(this.masterGain);
                this.observerOsc.start(now);
            } else {
                // Rampa suave de frecuencia para no causar chasquidos
                this.observerOsc.frequency.cancelScheduledValues(now);
                this.observerOsc.frequency.setTargetAtTime(obsAudioFreq, now, 0.05);
            }
        }
    }
}

if (typeof window !== 'undefined') {
    window.DopplerAudioEngine = DopplerAudioEngine;
}

