/**
 * physics.js - Motor Físico Acústico Riguroso para el Efecto Doppler
 * 
 * Implementa:
 * - Sistema Internacional de Unidades (m, s, Hz, m/s).
 * - Emisión determinista en instantes exactos t_{e,n} = n / f_e.
 * - Centros de frentes de onda fijos en el medio homogéneo en reposo.
 * - Cálculo analítico exacto de instantes de recepción t_{r,n} para MRU.
 * - Resolvedor numérico de raíces por bisección/secante para trayectorias arbitrarias.
 * - Frecuencia teórica Doppler vectorial general: f_o = f_e * (c - n · v_o) / (c - n · v_f).
 * - Medición empírica independiente por intervalos de llegada f_medida = 1 / (t_{r,n+1} - t_{r,n}).
 * - Envolvente y cono de Mach (M = |v_f|/c, mu = arcsin(1/M) para M >= 1).
 * - Longitudes de onda espaciales lambda_0, lambda_delante, lambda_detras.
 * - Determinismo absoluto: estado a tiempo t independiente del framerate.
 */

class DopplerPhysics {
    constructor() {
        // Parámetros fundamentales
        this.f_e = 2.0;          // Frecuencia emitida (Hz)
        this.c = 340.0;          // Rapidez de propagación en el medio (m/s)
        this.v_f = { x: 0.0, y: 0.0 }; // Velocidad de la fuente (m/s)
        this.v_o = { x: 0.0, y: 0.0 }; // Velocidad del observador (m/s)
        this.x_f0 = { x: -170.0, y: 0.0 }; // Posición inicial fuente (m)
        this.x_o0 = { x: 170.0, y: 0.0 };  // Posición inicial observador (m)
        
        // Modo de duración y tiempo
        this.durationMode = 'fixed'; // 'fixed' | 'periods'
        this.totalDuration = 10.0;   // Duración total (s)
        this.numPeriods = 20;        // Períodos si durationMode == 'periods'
        this.subdivisionsPerPeriod = 100; // k subdivisiones por período
        
        // Modo dimensional
        this.is2D = false; // false: 1D colineal sobre eje X; true: 2D plano
        
        // Trayectorias personalizadas (para Codelab)
        this.customTrajectory = null; // Función opcional: { posF(t), velF(t), posO(t), velO(t) }

        // Cache de eventos precalculados para determinismo y rendimiento
        this.wavefronts = [];
        this.receptions = []; // Lista ordenada de llegadas al observador
        
        // Inicializar
        this.recalculateAll();
    }

    /**
     * Actualiza parámetros y recalcula la historia física analítica completa.
     */
    updateParameters(params) {
        if (params.f_e !== undefined) this.f_e = Math.max(0.01, params.f_e);
        if (params.c !== undefined) this.c = Math.max(1.0, params.c);
        if (params.v_f !== undefined) {
            this.v_f.x = params.v_f.x !== undefined ? params.v_f.x : params.v_f;
            this.v_f.y = params.v_f.y !== undefined ? params.v_f.y : 0.0;
        }
        if (params.v_o !== undefined) {
            this.v_o.x = params.v_o.x !== undefined ? params.v_o.x : params.v_o;
            this.v_o.y = params.v_o.y !== undefined ? params.v_o.y : 0.0;
        }
        if (params.x_f0 !== undefined) {
            this.x_f0.x = params.x_f0.x !== undefined ? params.x_f0.x : this.x_f0.x;
            this.x_f0.y = params.x_f0.y !== undefined ? params.x_f0.y : this.x_f0.y;
        }
        if (params.x_o0 !== undefined) {
            this.x_o0.x = params.x_o0.x !== undefined ? params.x_o0.x : this.x_o0.x;
            this.x_o0.y = params.x_o0.y !== undefined ? params.x_o0.y : this.x_o0.y;
        }
        if (params.durationMode !== undefined) this.durationMode = params.durationMode;
        if (params.totalDuration !== undefined) this.totalDuration = Math.max(0.5, params.totalDuration);
        if (params.numPeriods !== undefined) this.numPeriods = Math.max(1, Math.round(params.numPeriods));
        if (params.subdivisionsPerPeriod !== undefined) this.subdivisionsPerPeriod = Math.max(10, params.subdivisionsPerPeriod);
        if (params.is2D !== undefined) this.is2D = !!params.is2D;
        if (params.customTrajectory !== undefined) this.customTrajectory = params.customTrajectory;

        this.recalculateAll();
    }

    /**
     * Calcula la duración máxima física del experimento.
     */
    getDuration() {
        if (this.durationMode === 'periods') {
            return this.numPeriods / this.f_e;
        }
        return this.totalDuration;
    }

    /**
     * Paso temporal manual recomendado: Delta t = 1 / (k * f)
     */
    getTimeStep() {
        return 1.0 / (this.subdivisionsPerPeriod * this.f_e);
    }

    /**
     * Período de emisión T = 1 / f
     */
    getPeriod() {
        return 1.0 / this.f_e;
    }

    /**
     * Número de Mach: M = |v_f| / c
     */
    getMachNumber() {
        const speed = Math.hypot(this.v_f.x, this.v_f.y);
        return speed / this.c;
    }

    /**
     * Semiángulo del cono de Mach en radianes: mu = arcsin(1/M) para M >= 1
     */
    getMachAngle() {
        const M = this.getMachNumber();
        if (M < 1.0) return null;
        return Math.asin(1.0 / M);
    }

    /**
     * Longitud de onda en el medio en reposo: lambda_0 = c / f
     */
    getWavelength0() {
        return this.c / this.f_e;
    }

    /**
     * Longitud de onda comprimida hacia adelante (1D): lambda_delante = (c - v_fx) / f
     */
    getWavelengthFront() {
        return (this.c - this.v_f.x) / this.f_e;
    }

    /**
     * Longitud de onda expandida hacia atrás (1D): lambda_detras = (c + v_fx) / f
     */
    getWavelengthBack() {
        return (this.c + this.v_f.x) / this.f_e;
    }

    /**
     * Posición de la fuente en cualquier tiempo t.
     */
    getSourcePosition(t) {
        if (this.customTrajectory && typeof this.customTrajectory.posF === 'function') {
            return this.customTrajectory.posF(t);
        }
        return {
            x: this.x_f0.x + this.v_f.x * t,
            y: this.is2D ? (this.x_f0.y + this.v_f.y * t) : 0.0
        };
    }

    /**
     * Velocidad de la fuente en cualquier tiempo t.
     */
    getSourceVelocity(t) {
        if (this.customTrajectory && typeof this.customTrajectory.velF === 'function') {
            return this.customTrajectory.velF(t);
        }
        return {
            x: this.v_f.x,
            y: this.is2D ? this.v_f.y : 0.0
        };
    }

    /**
     * Posición del observador en cualquier tiempo t.
     */
    getObserverPosition(t) {
        if (this.customTrajectory && typeof this.customTrajectory.posO === 'function') {
            return this.customTrajectory.posO(t);
        }
        return {
            x: this.x_o0.x + this.v_o.x * t,
            y: this.is2D ? (this.x_o0.y + this.v_o.y * t) : 0.0
        };
    }

    /**
     * Velocidad del observador en cualquier tiempo t.
     */
    getObserverVelocity(t) {
        if (this.customTrajectory && typeof this.customTrajectory.velO === 'function') {
            return this.customTrajectory.velO(t);
        }
        return {
            x: this.v_o.x,
            y: this.is2D ? this.v_o.y : 0.0
        };
    }

    /**
     * Resuelve analíticamente el instante de recepción t_r para MRU.
     * Ecuación: |x_o(0) + v_o*t_r - x_c|^2 = c^2 * (t_r - t_e)^2 con t_r >= t_e.
     */
    solveReceptionTimeMRU(xc, yc, te) {
        const xo0 = this.x_o0.x;
        const yo0 = this.is2D ? this.x_o0.y : 0.0;
        const vox = this.v_o.x;
        const voy = this.is2D ? this.v_o.y : 0.0;
        const c = this.c;

        const d0x = xo0 - xc;
        const d0y = yo0 - yc;
        const d0Sq = d0x * d0x + d0y * d0y;
        const voSq = vox * vox + voy * voy;
        const d0DotVo = d0x * vox + d0y * voy;

        const A = voSq - c * c;
        const B = 2.0 * (d0DotVo + (c * c) * te);
        const C = d0Sq - (c * c) * (te * te);

        if (Math.abs(A) < 1e-9) {
            // Caso vo = c (degenerado lineal)
            if (Math.abs(B) < 1e-9) return null;
            const tr = -C / B;
            return tr >= te - 1e-7 ? tr : null;
        }

        const disc = B * B - 4.0 * A * C;
        if (disc < -1e-9) return null; // No hay intersección física

        const sqrtDisc = Math.sqrt(Math.max(0.0, disc));
        const t1 = (-B - sqrtDisc) / (2.0 * A);
        const t2 = (-B + sqrtDisc) / (2.0 * A);

        const candidates = [];
        for (const tr of [t1, t2]) {
            if (tr >= te - 1e-7) {
                // Verificar que la distancia física coincida con c*(tr - te)
                const obsX = xo0 + vox * tr;
                const obsY = yo0 + voy * tr;
                const dist = Math.hypot(obsX - xc, obsY - yc);
                const travel = c * (tr - te);
                if (Math.abs(dist - travel) < 1e-4) {
                    candidates.push(tr);
                }
            }
        }

        if (candidates.length === 0) return null;
        // La primera llegada causal
        return Math.min(...candidates);
    }

    /**
     * Resolvedor numérico robusto para trayectorias arbitrarias (Codelab).
     */
    solveReceptionTimeNumeric(xc, yc, te) {
        const maxT = this.getDuration() * 2.0 + 10.0;
        const c = this.c;
        const f = (t) => {
            const obs = this.getObserverPosition(t);
            const dist = Math.hypot(obs.x - xc, obs.y - yc);
            return dist - c * (t - te);
        };

        // Búsqueda de cambio de signo en intervalos
        const steps = 300;
        const dt = (maxT - te) / steps;
        let prevT = te;
        let prevVal = f(prevT);

        for (let i = 1; i <= steps; i++) {
            const currT = te + i * dt;
            const currVal = f(currT);

            if (prevVal * currVal <= 0) {
                // Bisección en [prevT, currT]
                let a = prevT;
                let b = currT;
                for (let k = 0; k < 40; k++) {
                    const mid = 0.5 * (a + b);
                    const valMid = f(mid);
                    if (Math.abs(valMid) < 1e-6) return mid;
                    if (valMid * f(a) < 0) {
                        b = mid;
                    } else {
                        a = mid;
                    }
                }
                return 0.5 * (a + b);
            }
            prevT = currT;
            prevVal = currVal;
        }

        return null;
    }

    /**
     * Recalcula toda la tabla de emisiones y recepciones analíticas.
     */
    recalculateAll() {
        this.wavefronts = [];
        this.receptions = [];

        const T_total = this.getDuration();
        const period = this.getPeriod();
        
        // Emisión exacta en t_{e,n} = n / f_e con n >= 0
        const totalEmissions = Math.floor(T_total * this.f_e) + 1;

        for (let n = 0; n <= totalEmissions; n++) {
            const te = n * period;
            if (te > T_total + 1e-7) break;

            const posF = this.getSourcePosition(te);
            const velF = this.getSourceVelocity(te);

            let tr = null;
            if (this.customTrajectory) {
                tr = this.solveReceptionTimeNumeric(posF.x, posF.y, te);
            } else {
                tr = this.solveReceptionTimeMRU(posF.x, posF.y, te);
            }

            const wf = {
                id: n,
                n: n,
                te: te,
                xc: posF.x,
                yc: posF.y,
                velFx: velF.x,
                velFy: velF.y,
                tr: tr,
                // Función para radio en cualquier t >= te
                getRadius: function(t) {
                    return t >= this.te ? (this.parentEngine.c * (t - this.te)) : 0;
                }
            };
            wf.parentEngine = this;

            this.wavefronts.push(wf);

            if (tr !== null && tr <= T_total * 1.5 + 20.0) {
                // Obtenemos datos de recepción
                const posO_tr = this.getObserverPosition(tr);
                const velO_tr = this.getObserverVelocity(tr);
                
                // Vector unitario retardado n
                const dx = posO_tr.x - wf.xc;
                const dy = posO_tr.y - wf.yc;
                const dist = Math.hypot(dx, dy);
                const nx = dist > 1e-9 ? dx / dist : 1.0;
                const ny = dist > 1e-9 ? dy / dist : 0.0;

                // Frecuencia teórica Doppler en el instante de recepción
                const n_dot_vo = nx * velO_tr.x + ny * velO_tr.y;
                const n_dot_vf = nx * wf.velFx + ny * wf.velFy;
                const den = this.c - n_dot_vf;
                const num = this.c - n_dot_vo;

                let fo_theo = null;
                if (Math.abs(den) < 1e-6) {
                    fo_theo = Infinity; // Barrera sónica
                } else {
                    fo_theo = this.f_e * (num / den);
                }

                this.receptions.push({
                    wfId: n,
                    te: te,
                    tr: tr,
                    xc: wf.xc,
                    yc: wf.yc,
                    xo_tr: posO_tr.x,
                    yo_tr: posO_tr.y,
                    nx: nx,
                    ny: ny,
                    fo_theoretical: fo_theo,
                    measuredPeriod: null,
                    measuredFreq: null
                });
            }
        }

        // Ordenar recepciones por tiempo de llegada (crucial para supersónico donde hay inversión de orden)
        this.receptions.sort((a, b) => a.tr - b.tr);

        // Calcular frecuencias medidas empíricas por llegadas sucesivas
        for (let i = 1; i < this.receptions.length; i++) {
            const dt_rec = this.receptions[i].tr - this.receptions[i - 1].tr;
            this.receptions[i].measuredPeriod = dt_rec;
            if (dt_rec > 1e-7) {
                this.receptions[i].measuredFreq = 1.0 / dt_rec;
            } else {
                this.receptions[i].measuredFreq = Infinity;
            }
        }
    }

    /**
     * Obtiene el estado determinista completo en cualquier tiempo simulado t.
     */
    getStateAt(t) {
        const clampedT = Math.max(0, Math.min(t, this.getDuration()));
        const posF = this.getSourcePosition(clampedT);
        const velF = this.getSourceVelocity(clampedT);
        const posO = this.getObserverPosition(clampedT);
        const velO = this.getObserverVelocity(clampedT);

        const separation = Math.hypot(posO.x - posF.x, posO.y - posF.y);

        // Frentes emitidos hasta el tiempo t
        const activeWavefronts = [];
        let emittedCount = 0;
        for (const wf of this.wavefronts) {
            if (wf.te <= clampedT) {
                emittedCount++;
                const r = this.c * (clampedT - wf.te);
                activeWavefronts.push({
                    id: wf.id,
                    te: wf.te,
                    xc: wf.xc,
                    yc: wf.yc,
                    r: r,
                    tr: wf.tr,
                    hasReachedObserver: wf.tr !== null && clampedT >= wf.tr
                });
            }
        }

        // Recepciones ocurridas hasta el tiempo t
        const pastReceptions = [];
        let lastReception = null;
        let lastMeasuredFreq = null;
        let lastMeasuredPeriod = null;
        let theoreticalFreqAtLast = null;

        for (const rec of this.receptions) {
            if (rec.tr <= clampedT) {
                pastReceptions.push(rec);
                lastReception = rec;
                if (rec.measuredFreq !== null) {
                    lastMeasuredFreq = rec.measuredFreq;
                    lastMeasuredPeriod = rec.measuredPeriod;
                }
                theoreticalFreqAtLast = rec.fo_theoretical;
            } else {
                break;
            }
        }

        // Frecuencia teórica instantánea basada en la geometría actual si el observador estuviera recibiendo ahora
        // O calculada con la onda que está más próxima
        let currentTheoretical = this.calculateInstantaneousDoppler(posF, velF, posO, velO);

        // Comprobación de cruce de Mach
        const M = this.getMachNumber();
        const isSupersonic = M > 1.0;
        let machShockPassed = false;
        if (isSupersonic && this.v_f.x > 0) {
            // El vértice de la envolvente está en posF.x
            // El frente de choque se extiende hacia atrás formando un ángulo mu
            const mu = this.getMachAngle();
            const dx = posF.x - posO.x;
            const dy = Math.abs(posO.y - posF.y);
            // Punto observador está dentro del cono si dx > 0 y dy <= dx * tan(mu)
            if (dx > 0 && dy <= dx * Math.tan(mu)) {
                machShockPassed = true;
            }
        }

        return {
            t: clampedT,
            posF,
            velF,
            posO,
            velO,
            separation,
            emittedCount,
            receivedCount: pastReceptions.length,
            activeWavefronts,
            pastReceptions,
            lastReception,
            lastMeasuredFreq,
            lastMeasuredPeriod,
            theoreticalFreqAtLast,
            currentTheoretical,
            M,
            isSupersonic,
            machShockPassed
        };
    }

    /**
     * Frecuencia Doppler teórica instantánea para las posiciones y velocidades dadas.
     */
    calculateInstantaneousDoppler(posF, velF, posO, velO) {
        const dx = posO.x - posF.x;
        const dy = posO.y - posF.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 1e-9) return this.f_e;

        const nx = dx / dist;
        const ny = dy / dist;

        const n_dot_vo = nx * velO.x + ny * velO.y;
        const n_dot_vf = nx * velF.x + ny * velF.y;

        const den = this.c - n_dot_vf;
        const num = this.c - n_dot_vo;

        if (Math.abs(den) < 1e-6) return Infinity;
        return this.f_e * (num / den);
    }

    /**
     * Genera datos tabulares completos para exportación CSV.
     */
    generateCSV() {
        let csv = 'ID_Frente,t_emision_s,x_emision_m,y_emision_m,t_recepcion_s,x_obs_recepcion_m,y_obs_recepcion_m,f_teorica_Hz,f_medida_Hz,periodo_medido_s\n';
        for (const wf of this.wavefronts) {
            const rec = this.receptions.find(r => r.wfId === wf.id);
            const trStr = rec ? rec.tr.toFixed(6) : 'No alcanzado';
            const xoStr = rec ? rec.xo_tr.toFixed(3) : '-';
            const yoStr = rec ? rec.yo_tr.toFixed(3) : '-';
            const fTheoStr = (rec && rec.fo_theoretical !== null && isFinite(rec.fo_theoretical)) ? rec.fo_theoretical.toFixed(4) : '-';
            const fMedStr = (rec && rec.measuredFreq !== null && isFinite(rec.measuredFreq)) ? rec.measuredFreq.toFixed(4) : (rec ? 'Esperando 2da llegada' : '-');
            const perMedStr = (rec && rec.measuredPeriod !== null) ? rec.measuredPeriod.toFixed(6) : '-';

            csv += `${wf.id},${wf.te.toFixed(6)},${wf.xc.toFixed(3)},${wf.yc.toFixed(3)},${trStr},${xoStr},${yoStr},${fTheoStr},${fMedStr},${perMedStr}\n`;
        }
        return csv;
    }
}

// Exportar globalmente para uso en navegadores y pruebas
if (typeof window !== 'undefined') {
    window.DopplerPhysics = DopplerPhysics;
}
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DopplerPhysics };
}

