/**
 * renderer.js - Renderizador Gráfico en Canvas 2D
 * 
 * Implementa:
 * - Soporte para devicePixelRatio y redimensionamiento dinámico.
 * - Transformación afín Mundo (metros) <-> Pantalla (píxeles).
 * - Cuadrícula métrica adaptativa, ejes cartesianos y barra de escala física.
 * - Frentes de onda circulares con estilo (continuo, discontinuo, punteado), color y atenuación.
 * - Envolvente y cono de Mach con semiángulo mu = arcsin(1/M) para régimen supersónico.
 * - Iconos vectoriales de la fuente: Punto Emisor, Automóvil / Ambulancia, Avión Jet.
 * - Observador con micrófono/sensor y animación de pulso de recepción.
 * - Vectores de velocidad etiquetados con magnitud y dirección.
 * - Cotas de medición de longitudes de onda (lambda_delante, lambda_detras).
 * - Herramienta interactiva de regla/cinta métrica.
 * - Inspección visual de frentes de onda interactiva.
 */

class DopplerRenderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        
        // Vista y cámara
        this.camX = 0.0; // Coordenada X del centro de cámara en metros
        this.camY = 0.0; // Coordenada Y del centro de cámara en metros
        this.scale = 1.0; // Píxeles por metro (zoom)
        this.followSource = false;

        // Opciones de estilo visual
        this.theme = 'dark'; // 'dark' | 'light'
        this.sourceType = 'ambulance'; // 'point' | 'ambulance' | 'jet'
        this.waveStyle = 'solid'; // 'solid' | 'dashed' | 'dotted'
        this.waveColor = '#38bdf8'; // Celeste brillante
        this.waveLineWidth = 2.0;
        this.visualAttenuation = true; // Atenuación gráfica ilustrativa

        // Capas activas
        this.showGrid = true;
        this.showAxes = true;
        this.showVectors = true;
        this.showWavelengthDimensions = true;
        this.showMachEnvelope = true;

        // Herramienta de regla / medición
        this.measureToolActive = false;
        this.measurePointA = null; // { x, y } en metros
        this.measurePointB = null; // { x, y } en metros

        // Inspección de frentes
        this.selectedWavefrontId = null;
        this.hoveredWavefrontId = null;

        // Animación de pulso del observador en recepción
        this.lastReceptionPulseTime = -100;
    }

    /**
     * Ajusta el tamaño del canvas con soporte para pantallas Retina/HiDPI.
     */
    resize() {
        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.getBoundingClientRect();
        
        const width = Math.max(300, Math.floor(rect.width));
        const height = Math.max(200, Math.floor(rect.height));

        this.canvas.width = width * dpr;
        this.canvas.height = height * dpr;
        
        this.ctx.resetTransform();
        this.ctx.scale(dpr, dpr);

        this.viewportWidth = width;
        this.viewportHeight = height;
    }

    /**
     * Convierte coordenadas físicas del mundo (metros) a coordenadas de pantalla (píxeles).
     */
    worldToScreen(wx, wy) {
        const cx = this.viewportWidth / 2;
        const cy = this.viewportHeight / 2;
        return {
            x: cx + (wx - this.camX) * this.scale,
            y: cy - (wy - this.camY) * this.scale // Eje Y hacia arriba
        };
    }

    /**
     * Convierte coordenadas de pantalla (píxeles) a coordenadas físicas del mundo (metros).
     */
    screenToWorld(sx, sy) {
        const cx = this.viewportWidth / 2;
        const cy = this.viewportHeight / 2;
        return {
            x: this.camX + (sx - cx) / this.scale,
            y: this.camY - (sy - cy) / this.scale
        };
    }

    /**
     * Centra y ajusta el zoom automáticamente para ver fuente, observador y frentes.
     */
    fitScene(posF, posO, maxRadius = 400) {
        const minX = Math.min(posF.x, posO.x) - maxRadius * 0.7;
        const maxX = Math.max(posF.x, posO.x) + maxRadius * 0.7;
        const minY = Math.min(posF.y, posO.y) - maxRadius * 0.6;
        const maxY = Math.max(posF.y, posO.y) + maxRadius * 0.6;

        this.camX = (minX + maxX) / 2;
        this.camY = (minY + maxY) / 2;

        const rangeX = Math.max(100, maxX - minX);
        const rangeY = Math.max(80, maxY - minY);

        const scaleX = (this.viewportWidth * 0.85) / rangeX;
        const scaleY = (this.viewportHeight * 0.85) / rangeY;
        this.scale = Math.min(scaleX, scaleY);
        this.scale = Math.max(0.05, Math.min(5.0, this.scale));
    }

    /**
     * Restaura la vista inicial estándar.
     */
    resetView() {
        this.camX = 0.0;
        this.camY = 0.0;
        this.scale = 0.85;
    }

    /**
     * Ciclo principal de dibujo.
     */
    render(simState, physicsEngine) {
        if (!this.ctx || !this.viewportWidth) return;

        // Si seguimiento de fuente está activo, centrar cámara en fuente
        if (this.followSource) {
            this.camX = simState.posF.x;
            this.camY = simState.posF.y;
        }

        // Colores según tema
        const isDark = this.theme === 'dark';
        const bgColor = isDark ? '#090d16' : '#f8fafc';
        const gridColor = isDark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.06)';
        const gridTextColor = isDark ? '#64748b' : '#94a3b8';
        const axisColor = isDark ? 'rgba(255, 255, 255, 0.25)' : 'rgba(0, 0, 0, 0.25)';

        // 1. Limpiar fondo
        this.ctx.fillStyle = bgColor;
        this.ctx.fillRect(0, 0, this.viewportWidth, this.viewportHeight);

        // 2. Cuadrícula y ejes métricos
        if (this.showGrid) {
            this.drawGrid(gridColor, gridTextColor);
        }
        if (this.showAxes) {
            this.drawAxes(axisColor, gridTextColor);
        }

        // 3. Cono / Envolvente de Mach (si M > 1 y régimen supersónico)
        if (this.showMachEnvelope && simState.isSupersonic) {
            this.drawMachEnvelope(simState, physicsEngine);
        }

        // 4. Frentes de onda
        this.drawWavefronts(simState, physicsEngine);

        // 5. Cotas de longitud de onda (1D colineal)
        if (this.showWavelengthDimensions && !physicsEngine.is2D) {
            this.drawWavelengthDimensions(simState, physicsEngine);
        }

        // 6. Observador (micrófono / sensor)
        this.drawObserver(simState);

        // 7. Fuente emisora (punto, auto o avión)
        this.drawSource(simState);

        // 8. Vectores de velocidad
        if (this.showVectors) {
            this.drawVelocityVectors(simState);
        }

        // 9. Barra de escala física en metros
        this.drawPhysicalScaleBar(isDark);

        // 10. Herramienta de regla de medición si está activa
        if (this.measureToolActive && this.measurePointA) {
            this.drawMeasureTool();
        }

        // 11. Tooltip de inspección de frente
        this.drawWavefrontInspection(simState);
    }

    /**
     * Dibuja la cuadrícula métrica adaptativa según el zoom.
     */
    drawGrid(gridColor, textColor) {
        const stepOptions = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000];
        const minPixelDistance = 60;
        let meterStep = 100;

        for (const s of stepOptions) {
            if (s * this.scale >= minPixelDistance) {
                meterStep = s;
                break;
            }
        }

        const topLeft = this.screenToWorld(0, 0);
        const bottomRight = this.screenToWorld(this.viewportWidth, this.viewportHeight);

        const startX = Math.floor(topLeft.x / meterStep) * meterStep;
        const endX = Math.ceil(bottomRight.x / meterStep) * meterStep;
        const startY = Math.floor(bottomRight.y / meterStep) * meterStep;
        const endY = Math.ceil(topLeft.y / meterStep) * meterStep;

        this.ctx.save();
        this.ctx.lineWidth = 1;
        this.ctx.strokeStyle = gridColor;
        this.ctx.fillStyle = textColor;
        this.ctx.font = '10px Inter, system-ui, sans-serif';

        this.ctx.beginPath();
        for (let x = startX; x <= endX; x += meterStep) {
            const sx = this.worldToScreen(x, 0).x;
            this.ctx.moveTo(sx, 0);
            this.ctx.lineTo(sx, this.viewportHeight);
        }
        for (let y = startY; y <= endY; y += meterStep) {
            const sy = this.worldToScreen(0, y).y;
            this.ctx.moveTo(0, sy);
            this.ctx.lineTo(this.viewportWidth, sy);
        }
        this.ctx.stroke();

        this.ctx.restore();
    }

    /**
     * Dibuja los ejes coordenados con etiquetas métricas.
     */
    drawAxes(axisColor, textColor) {
        const origin = this.worldToScreen(0, 0);
        this.ctx.save();
        this.ctx.lineWidth = 1.5;
        this.ctx.strokeStyle = axisColor;

        // Eje X
        if (origin.y >= 0 && origin.y <= this.viewportHeight) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, origin.y);
            this.ctx.lineTo(this.viewportWidth, origin.y);
            this.ctx.stroke();
        }

        // Eje Y
        if (origin.x >= 0 && origin.x <= this.viewportWidth) {
            this.ctx.beginPath();
            this.ctx.moveTo(origin.x, 0);
            this.ctx.lineTo(origin.x, this.viewportHeight);
            this.ctx.stroke();
        }

        // Etiquetas de ejes
        this.ctx.fillStyle = textColor;
        this.ctx.font = '11px Inter, system-ui, sans-serif';
        this.ctx.fillText('+X (m)', this.viewportWidth - 45, Math.min(this.viewportHeight - 10, Math.max(20, origin.y - 8)));
        this.ctx.fillText('+Y (m)', Math.min(this.viewportWidth - 40, Math.max(10, origin.x + 8)), 20);

        this.ctx.restore();
    }

    /**
     * Dibuja los frentes de onda circulares emitidos.
     */
    drawWavefronts(simState, physicsEngine) {
        this.ctx.save();

        // Configuración de estilo de línea
        if (this.waveStyle === 'dashed') {
            this.ctx.setLineDash([8, 6]);
        } else if (this.waveStyle === 'dotted') {
            this.ctx.setLineDash([3, 4]);
        } else {
            this.ctx.setLineDash([]);
        }

        for (const wf of simState.activeWavefronts) {
            const screenCenter = this.worldToScreen(wf.xc, wf.yc);
            const screenRadius = wf.r * this.scale;

            if (screenRadius < 1) continue;

            // Descartar círculos completamente fuera de pantalla
            if (
                screenCenter.x + screenRadius < 0 ||
                screenCenter.x - screenRadius > this.viewportWidth ||
                screenCenter.y + screenRadius < 0 ||
                screenCenter.y - screenRadius > this.viewportHeight
            ) {
                continue;
            }

            // Opacidad / atenuación gráfica opcional
            let alpha = 0.85;
            if (this.visualAttenuation) {
                // Atenuación suave para legibilidad visual
                alpha = Math.max(0.18, 0.95 / (1.0 + wf.r * 0.0015));
            }

            const isSelected = wf.id === this.selectedWavefrontId;
            const isHovered = wf.id === this.hoveredWavefrontId;

            this.ctx.beginPath();
            this.ctx.arc(screenCenter.x, screenCenter.y, screenRadius, 0, Math.PI * 2);

            if (isSelected) {
                this.ctx.strokeStyle = '#e11d48'; // Rosa fuerte de selección
                this.ctx.lineWidth = this.waveLineWidth + 2.5;
            } else if (isHovered) {
                this.ctx.strokeStyle = '#f59e0b'; // Ámbar de hover
                this.ctx.lineWidth = this.waveLineWidth + 1.5;
            } else {
                this.ctx.strokeStyle = this.waveColor;
                this.ctx.lineWidth = this.waveLineWidth;
            }

            this.ctx.globalAlpha = isSelected || isHovered ? 1.0 : alpha;
            this.ctx.stroke();

            // Dibujar punto centro de emisión fijo en el medio (para recalcar que no viaja con la fuente)
            if (this.scale >= 0.3) {
                this.ctx.beginPath();
                this.ctx.arc(screenCenter.x, screenCenter.y, 2.5, 0, Math.PI * 2);
                this.ctx.fillStyle = this.waveColor;
                this.ctx.globalAlpha = alpha * 0.5;
                this.ctx.fill();
            }
        }

        this.ctx.restore();
    }

    /**
     * Dibuja el cono / envolvente de Mach en régimen supersónico (M > 1).
     */
    drawMachEnvelope(simState, physicsEngine) {
        const mu = physicsEngine.getMachAngle();
        if (mu === null) return;

        const posF = simState.posF;
        const speed = Math.hypot(simState.velF.x, simState.velF.y);
        if (speed < 1e-4) return;

        // Dirección de movimiento de la fuente
        const angleV = Math.atan2(simState.velF.y, simState.velF.x);

        // Vértice en la posición actual de la fuente
        const vTip = this.worldToScreen(posF.x, posF.y);

        // Longitud del cono hacia atrás
        const coneLengthMeters = Math.max(1200, this.viewportWidth / this.scale);
        const backAngle = angleV + Math.PI;

        const leftAngle = backAngle + mu;
        const rightAngle = backAngle - mu;

        const pLeft = {
            x: posF.x + coneLengthMeters * Math.cos(leftAngle),
            y: posF.y + coneLengthMeters * Math.sin(leftAngle)
        };
        const pRight = {
            x: posF.x + coneLengthMeters * Math.cos(rightAngle),
            y: posF.y + coneLengthMeters * Math.sin(rightAngle)
        };

        const sLeft = this.worldToScreen(pLeft.x, pLeft.y);
        const sRight = this.worldToScreen(pRight.x, pRight.y);

        this.ctx.save();
        // Sombreado translúcido del interior del cono
        this.ctx.beginPath();
        this.ctx.moveTo(vTip.x, vTip.y);
        this.ctx.lineTo(sLeft.x, sLeft.y);
        this.ctx.lineTo(sRight.x, sRight.y);
        this.ctx.closePath();
        this.ctx.fillStyle = 'rgba(239, 68, 68, 0.08)'; // Rojo muy suave
        this.ctx.fill();

        // Líneas de la envolvente de choque
        this.ctx.beginPath();
        this.ctx.moveTo(sLeft.x, sLeft.y);
        this.ctx.lineTo(vTip.x, vTip.y);
        this.ctx.lineTo(sRight.x, sRight.y);
        this.ctx.strokeStyle = '#ef4444'; // Rojo advertencia
        this.ctx.lineWidth = 2.5;
        this.ctx.stroke();

        // Etiqueta del ángulo mu
        const muDeg = (mu * 180 / Math.PI).toFixed(1);
        this.ctx.fillStyle = '#ef4444';
        this.ctx.font = 'bold 12px Inter, system-ui, sans-serif';
        const labelOffset = 40;
        this.ctx.fillText(`Cono de Mach: μ = ${muDeg}° (M = ${simState.M.toFixed(2)})`, vTip.x - 140, vTip.y - 25);

        this.ctx.restore();
    }

    /**
     * Dibuja cotas de dimensión entre frentes consecutivos para visualizar compresión/expansión.
     */
    drawWavelengthDimensions(simState, physicsEngine) {
        if (simState.activeWavefronts.length < 2) return;
        const posF = simState.posF;
        const yOff = posF.y - 45; // Cota por debajo

        // Buscar dos frentes consecutivos hacia adelante (+x respecto a la fuente)
        const frontWfs = simState.activeWavefronts
            .filter(wf => wf.xc + wf.r > posF.x)
            .sort((a, b) => (b.xc + b.r) - (a.xc + a.r));

        if (frontWfs.length >= 2) {
            const x1 = frontWfs[0].xc + frontWfs[0].r;
            const x2 = frontWfs[1].xc + frontWfs[1].r;
            if (x1 > x2 && Math.abs(x1 - x2) < physicsEngine.c * 2) {
                const s1 = this.worldToScreen(x1, yOff);
                const s2 = this.worldToScreen(x2, yOff);
                const dist = Math.abs(x1 - x2);

                this.drawDimensionLine(s2.x, s2.y, s1.x, s1.y, `λ_delante = ${dist.toFixed(1)} m`, '#10b981');
            }
        }

        // Buscar dos frentes consecutivos hacia atrás (-x respecto a la fuente)
        const backWfs = simState.activeWavefronts
            .filter(wf => wf.xc - wf.r < posF.x)
            .sort((a, b) => (a.xc - a.r) - (b.xc - b.r));

        if (backWfs.length >= 2) {
            const x1 = backWfs[0].xc - backWfs[0].r;
            const x2 = backWfs[1].xc - backWfs[1].r;
            if (x2 > x1 && Math.abs(x2 - x1) < physicsEngine.c * 2) {
                const s1 = this.worldToScreen(x1, yOff);
                const s2 = this.worldToScreen(x2, yOff);
                const dist = Math.abs(x2 - x1);

                this.drawDimensionLine(s1.x, s1.y, s2.x, s2.y, `λ_detrás = ${dist.toFixed(1)} m`, '#f59e0b');
            }
        }
    }

    /**
     * Dibuja una línea de cota con flechas y texto.
     */
    drawDimensionLine(x1, y1, x2, y2, text, color) {
        if (Math.abs(x2 - x1) < 15) return;
        this.ctx.save();
        this.ctx.strokeStyle = color;
        this.ctx.fillStyle = color;
        this.ctx.lineWidth = 1.5;
        this.ctx.font = '11px Inter, system-ui, sans-serif';
        this.ctx.textAlign = 'center';

        // Línea principal
        this.ctx.beginPath();
        this.ctx.moveTo(x1, y1);
        this.ctx.lineTo(x2, y1);
        // Ticks en extremos
        this.ctx.moveTo(x1, y1 - 5);
        this.ctx.lineTo(x1, y1 + 5);
        this.ctx.moveTo(x2, y1 - 5);
        this.ctx.lineTo(x2, y1 + 5);
        this.ctx.stroke();

        // Texto centrado
        this.ctx.fillText(text, (x1 + x2) / 2, y1 - 8);
        this.ctx.restore();
    }

    /**
     * Dibuja la fuente emisora según el estilo seleccionado.
     */
    drawSource(simState) {
        const s = this.worldToScreen(simState.posF.x, simState.posF.y);
        const heading = Math.atan2(simState.velF.y, simState.velF.x);

        this.ctx.save();
        this.ctx.translate(s.x, s.y);

        if (this.sourceType === 'point') {
            // Punto emisor pulsante
            this.ctx.beginPath();
            this.ctx.arc(0, 0, 10, 0, Math.PI * 2);
            this.ctx.fillStyle = '#f43f5e';
            this.ctx.shadowColor = '#f43f5e';
            this.ctx.shadowBlur = 15;
            this.ctx.fill();

            this.ctx.beginPath();
            this.ctx.arc(0, 0, 4, 0, Math.PI * 2);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fill();
        } else if (this.sourceType === 'ambulance') {
            // Ambulancia / Carro estilizado
            this.ctx.rotate(heading);
            this.ctx.shadowColor = 'rgba(0,0,0,0.4)';
            this.ctx.shadowBlur = 8;

            // Cuerpo del auto
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillRect(-22, -12, 44, 24);
            // Cabina y parabrisas
            this.ctx.fillStyle = '#38bdf8';
            this.ctx.fillRect(8, -9, 10, 18);
            // Cruz roja
            this.ctx.fillStyle = '#ef4444';
            this.ctx.fillRect(-8, -9, 6, 18);
            this.ctx.fillRect(-14, -3, 18, 6);
            // Sirena destellante
            this.ctx.fillStyle = (Math.floor(simState.t * 8) % 2 === 0) ? '#ef4444' : '#3b82f6';
            this.ctx.beginPath();
            this.ctx.arc(0, 0, 4, 0, Math.PI * 2);
            this.ctx.fill();
            // Ruedas
            this.ctx.fillStyle = '#1e293b';
            this.ctx.fillRect(-16, -14, 8, 4);
            this.ctx.fillRect(-16, 10, 8, 4);
            this.ctx.fillRect(8, -14, 8, 4);
            this.ctx.fillRect(8, 10, 8, 4);
        } else if (this.sourceType === 'jet') {
            // Avión supersónico estilizado
            this.ctx.rotate(heading);
            this.ctx.shadowColor = '#38bdf8';
            this.ctx.shadowBlur = 10;

            this.ctx.fillStyle = '#94a3b8';
            this.ctx.beginPath();
            this.ctx.moveTo(26, 0);       // Nariz afilada
            this.ctx.lineTo(-12, -22);    // Ala izquierda
            this.ctx.lineTo(-6, -6);
            this.ctx.lineTo(-24, -14);    // Estabilizador izquierdo
            this.ctx.lineTo(-20, 0);      // Tobera
            this.ctx.lineTo(-24, 14);     // Estabilizador derecho
            this.ctx.lineTo(-6, 6);
            this.ctx.lineTo(-12, 22);     // Ala derecha
            this.ctx.closePath();
            this.ctx.fill();
            this.ctx.strokeStyle = '#f1f5f9';
            this.ctx.lineWidth = 1.2;
            this.ctx.stroke();

            // Tobera encendida si M > 0.8
            if (simState.M >= 0.8) {
                this.ctx.fillStyle = '#f97316';
                this.ctx.beginPath();
                this.ctx.moveTo(-20, -3);
                this.ctx.lineTo(-32, 0);
                this.ctx.lineTo(-20, 3);
                this.ctx.closePath();
                this.ctx.fill();
            }
        }

        this.ctx.restore();

        // Etiqueta de la fuente
        this.ctx.save();
        this.ctx.fillStyle = this.theme === 'dark' ? '#f1f5f9' : '#0f172a';
        this.ctx.font = 'bold 11px Inter, system-ui, sans-serif';
        this.ctx.fillText('Fuente (S)', s.x - 25, s.y - 25);
        this.ctx.restore();
    }

    /**
     * Dibuja el observador / micrófono con punto de detección y destello de onda.
     */
    drawObserver(simState) {
        const s = this.worldToScreen(simState.posO.x, simState.posO.y);

        this.ctx.save();
        this.ctx.translate(s.x, s.y);

        // Si se recibió una onda recientemente, dibujar pulso/anillo concéntrico expansivo
        if (simState.lastReception && (simState.t - simState.lastReception.tr < 0.25)) {
            const pulseDt = simState.t - simState.lastReception.tr;
            const pulseRadius = 14 + pulseDt * 80;
            const pulseAlpha = Math.max(0, 1.0 - pulseDt / 0.25);

            this.ctx.beginPath();
            this.ctx.arc(0, 0, pulseRadius, 0, Math.PI * 2);
            this.ctx.strokeStyle = `rgba(16, 185, 129, ${pulseAlpha})`; // Esmeralda
            this.ctx.lineWidth = 2.5;
            this.ctx.stroke();
        }

        // Símbolo de micrófono / sensor acústico
        // Rejilla del micrófono
        this.ctx.fillStyle = '#10b981'; // Verde esmeralda
        this.ctx.shadowColor = '#10b981';
        this.ctx.shadowBlur = 10;
        this.ctx.beginPath();
        this.ctx.arc(0, -6, 9, Math.PI, 0, false);
        this.ctx.lineTo(9, 2);
        this.ctx.arc(0, 2, 9, 0, Math.PI, false);
        this.ctx.closePath();
        this.ctx.fill();

        // Soporte del micrófono
        this.ctx.fillStyle = '#475569';
        this.ctx.fillRect(-2, 10, 4, 12);
        this.ctx.fillRect(-8, 22, 16, 3);

        // Cruz de punto exacto de recepción
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 1.5;
        this.ctx.beginPath();
        this.ctx.moveTo(-4, 0);
        this.ctx.lineTo(4, 0);
        this.ctx.moveTo(0, -4);
        this.ctx.lineTo(0, 4);
        this.ctx.stroke();

        this.ctx.restore();

        // Etiqueta del observador
        this.ctx.save();
        this.ctx.fillStyle = this.theme === 'dark' ? '#f1f5f9' : '#0f172a';
        this.ctx.font = 'bold 11px Inter, system-ui, sans-serif';
        this.ctx.fillText('Observador (O)', s.x - 35, s.y - 25);
        this.ctx.restore();
    }

    /**
     * Dibuja los vectores de velocidad de la fuente y observador.
     */
    drawVelocityVectors(simState) {
        const arrowScale = 0.5; // Factor visual para que el vector se aprecie claramente

        // Vector fuente
        if (Math.hypot(simState.velF.x, simState.velF.y) > 0.5) {
            const start = this.worldToScreen(simState.posF.x, simState.posF.y);
            const end = this.worldToScreen(
                simState.posF.x + simState.velF.x * arrowScale,
                simState.posF.y + simState.velF.y * arrowScale
            );
            const speed = Math.hypot(simState.velF.x, simState.velF.y);
            this.drawArrow(start.x, start.y, end.x, end.y, `vf = ${speed.toFixed(1)} m/s`, '#ec4899');
        }

        // Vector observador
        if (Math.hypot(simState.velO.x, simState.velO.y) > 0.5) {
            const start = this.worldToScreen(simState.posO.x, simState.posO.y);
            const end = this.worldToScreen(
                simState.posO.x + simState.velO.x * arrowScale,
                simState.posO.y + simState.velO.y * arrowScale
            );
            const speed = Math.hypot(simState.velO.x, simState.velO.y);
            this.drawArrow(start.x, start.y, end.x, end.y, `vo = ${speed.toFixed(1)} m/s`, '#8b5cf6');
        }
    }

    /**
     * Dibuja una flecha vectorial con cabeza y texto.
     */
    drawArrow(fromX, fromY, toX, toY, label, color) {
        const headLength = 10;
        const dx = toX - fromX;
        const dy = toY - fromY;
        const angle = Math.atan2(dy, dx);

        this.ctx.save();
        this.ctx.strokeStyle = color;
        this.ctx.fillStyle = color;
        this.ctx.lineWidth = 2.5;

        this.ctx.beginPath();
        this.ctx.moveTo(fromX, fromY);
        this.ctx.lineTo(toX, toY);
        this.ctx.stroke();

        // Cabeza de flecha
        this.ctx.beginPath();
        this.ctx.moveTo(toX, toY);
        this.ctx.lineTo(
            toX - headLength * Math.cos(angle - Math.PI / 6),
            toY - headLength * Math.sin(angle - Math.PI / 6)
        );
        this.ctx.lineTo(
            toX - headLength * Math.cos(angle + Math.PI / 6),
            toY - headLength * Math.sin(angle + Math.PI / 6)
        );
        this.ctx.closePath();
        this.ctx.fill();

        // Texto
        this.ctx.font = 'bold 11px Inter, system-ui, sans-serif';
        this.ctx.fillText(label, toX + 8, toY - 6);
        this.ctx.restore();
    }

    /**
     * Dibuja la barra de escala física en metros en la esquina inferior izquierda.
     */
    drawPhysicalScaleBar(isDark) {
        const targetPixels = 100;
        const metersEstimate = targetPixels / this.scale;
        
        // Redondear a números legibles (10, 20, 50, 100, 200, 500, etc.)
        const pow = Math.pow(10, Math.floor(Math.log10(metersEstimate)));
        let roundedMeters = 100;
        for (const mult of [1, 2, 5, 10]) {
            if (mult * pow >= metersEstimate * 0.7) {
                roundedMeters = mult * pow;
                break;
            }
        }

        const barPixelLength = roundedMeters * this.scale;
        const startX = 25;
        const startY = this.viewportHeight - 25;

        this.ctx.save();
        this.ctx.strokeStyle = isDark ? '#e2e8f0' : '#1e293b';
        this.ctx.fillStyle = isDark ? '#e2e8f0' : '#1e293b';
        this.ctx.lineWidth = 2;

        this.ctx.beginPath();
        this.ctx.moveTo(startX, startY);
        this.ctx.lineTo(startX + barPixelLength, startY);
        this.ctx.moveTo(startX, startY - 5);
        this.ctx.lineTo(startX, startY + 5);
        this.ctx.moveTo(startX + barPixelLength, startY - 5);
        this.ctx.lineTo(startX + barPixelLength, startY + 5);
        this.ctx.stroke();

        this.ctx.font = '11px Inter, system-ui, sans-serif';
        this.ctx.fillText(`Escala: ${roundedMeters} m`, startX, startY - 8);
        this.ctx.restore();
    }

    /**
     * Dibuja la herramienta de regla interactiva (medidor de distancias).
     */
    drawMeasureTool() {
        if (!this.measurePointA) return;
        const sA = this.worldToScreen(this.measurePointA.x, this.measurePointA.y);
        const sB = this.measurePointB ? this.worldToScreen(this.measurePointB.x, this.measurePointB.y) : sA;

        const distMeters = this.measurePointB
            ? Math.hypot(this.measurePointB.x - this.measurePointA.x, this.measurePointB.y - this.measurePointA.y)
            : 0;

        this.ctx.save();
        this.ctx.strokeStyle = '#eab308'; // Amarillo regla
        this.ctx.fillStyle = '#eab308';
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([5, 5]);

        this.ctx.beginPath();
        this.ctx.moveTo(sA.x, sA.y);
        this.ctx.lineTo(sB.x, sB.y);
        this.ctx.stroke();

        // Puntos extremos
        this.ctx.setLineDash([]);
        this.ctx.beginPath();
        this.ctx.arc(sA.x, sA.y, 4, 0, Math.PI * 2);
        this.ctx.arc(sB.x, sB.y, 4, 0, Math.PI * 2);
        this.ctx.fill();

        // Etiqueta con distancia física
        const midX = (sA.x + sB.x) / 2;
        const midY = (sA.y + sB.y) / 2;
        this.ctx.font = 'bold 12px Inter, system-ui, sans-serif';
        this.ctx.fillText(`Distancia: ${distMeters.toFixed(2)} m`, midX + 10, midY - 10);

        this.ctx.restore();
    }

    /**
     * Dibuja el panel flotante de inspección de frente de onda seleccionado/hovered.
     */
    drawWavefrontInspection(simState) {
        const wfId = this.selectedWavefrontId !== null ? this.selectedWavefrontId : this.hoveredWavefrontId;
        if (wfId === null) return;

        const wf = simState.activeWavefronts.find(w => w.id === wfId);
        if (!wf) return;

        const s = this.worldToScreen(wf.xc, wf.yc);

        this.ctx.save();
        const boxW = 210;
        const boxH = 95;
        const boxX = Math.min(this.viewportWidth - boxW - 15, Math.max(15, s.x + 15));
        const boxY = Math.min(this.viewportHeight - boxH - 15, Math.max(15, s.y - boxH - 15));

        // Fondo del popup
        this.ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
        this.ctx.strokeStyle = '#38bdf8';
        this.ctx.lineWidth = 1.5;
        this.ctx.fillRect(boxX, boxY, boxW, boxH);
        this.ctx.strokeRect(boxX, boxY, boxW, boxH);

        // Contenido
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = 'bold 12px Inter, system-ui, sans-serif';
        this.ctx.fillText(`Frente de Onda #${wf.id}`, boxX + 10, boxY + 20);

        this.ctx.fillStyle = '#94a3b8';
        this.ctx.font = '11px Inter, system-ui, sans-serif';
        this.ctx.fillText(`Emisión: t = ${wf.te.toFixed(3)} s`, boxX + 10, boxY + 38);
        this.ctx.fillText(`Centro: (${wf.xc.toFixed(1)}, ${wf.yc.toFixed(1)}) m`, boxX + 10, boxY + 54);
        this.ctx.fillText(`Radio actual: r = ${wf.r.toFixed(1)} m`, boxX + 10, boxY + 70);
        
        const statusText = wf.hasReachedObserver
            ? `Recibido en tr = ${wf.tr.toFixed(3)} s`
            : (wf.tr ? `Llegará en tr ≈ ${wf.tr.toFixed(3)} s` : 'No interceptará al observador');
        this.ctx.fillStyle = wf.hasReachedObserver ? '#10b981' : '#f59e0b';
        this.ctx.fillText(statusText, boxX + 10, boxY + 86);

        this.ctx.restore();
    }
}

if (typeof window !== 'undefined') {
    window.DopplerRenderer = DopplerRenderer;
}

