/**
 * app.js - Controlador Principal del Simulador del Efecto Doppler
 * 
 * Orquesta:
 * - Ciclo de animación desacoplado con requestAnimationFrame.
 * - Despacho de estado determinista hacia el renderizador, audio, gráficas y HUD.
 * - Sincronización bidireccional entre controles numéricos y deslizadores con validación.
 * - Interacción táctil y de ratón (zoom en cursor, arrastre, reposicionamiento, regla).
 * - Modos Exploración y Laboratorio.
 * - Panel matemático dinámico con fórmulas simbólicas y sustitución numérica.
 * - Exportación de datos a CSV y capturas PNG.
 * - Atajos de teclado y accesibilidad.
 */

class DopplerApp {
    constructor() {
        // Módulos
        this.physics = new DopplerPhysics();
        window.physicsEngine = this.physics; // Referencia global

        this.canvas = document.getElementById('sim-canvas');
        this.renderer = new DopplerRenderer(this.canvas);
        this.audio = new DopplerAudioEngine();
        
        this.chartCanvas = document.getElementById('chart-canvas');
        this.charts = new DopplerCharts(this.chartCanvas);

        this.verifier = new DopplerScientificVerifier();
        
        // Estado de reproducción
        this.isPlaying = false;
        this.simTime = 0.0;
        this.playbackRate = 1.0;
        this.lastWallTime = null;

        // Modo de interacción
        this.appMode = 'exploration'; // 'exploration' | 'laboratory'
        this.draggedObject = null; // 'source' | 'observer' | 'pan'
        this.dragStartPos = null;

        // Inicializar
        this.initDOM();
        this.initCurriculumAndCodeLab();
        this.bindEvents();
        this.updateMathPanel();
        
        // Ajuste de vista inicial
        this.renderer.resize();
        this.renderer.resetView();

        // Arrancar bucle
        requestAnimationFrame((t) => this.animationLoop(t));
    }

    initDOM() {
        // Cargar valores iniciales en los inputs
        this.syncInputsFromPhysics();
        this.updateHUD();
    }

    initCurriculumAndCodeLab() {
        const curriculumContainer = document.getElementById('curriculum-container');
        if (curriculumContainer) {
            this.curriculum = new DopplerGuidedCurriculum(curriculumContainer, (params) => {
                this.pause();
                this.physics.updateParameters(params);
                if (params.sourceType) {
                    this.renderer.sourceType = params.sourceType;
                    const srcSel = document.getElementById('source-type-select');
                    if (srcSel) srcSel.value = params.sourceType;
                }
                this.syncInputsFromPhysics();
                this.simTime = 0.0;
                this.audio.resetPlaybackTracking();
                this.renderer.fitScene(this.physics.getSourcePosition(0), this.physics.getObserverPosition(0));
                this.updateMathPanel();
                this.updateHUD();
            });
            this.curriculum.render();
        }

        const codelabContainer = document.getElementById('codelab-container');
        if (codelabContainer) {
            this.codelab = new DopplerCodeLab(codelabContainer, (customTrajectory) => {
                this.pause();
                this.physics.updateParameters({ customTrajectory });
                this.simTime = 0.0;
                this.audio.resetPlaybackTracking();
                this.updateMathPanel();
                this.updateHUD();
            });
            this.codelab.render();
        }

        const verifierContainer = document.getElementById('verifier-container');
        if (verifierContainer) {
            this.verifier.renderTable(verifierContainer);
        }
    }

    /**
     * Sincroniza los controles del DOM a partir de los parámetros del motor físico.
     */
    syncInputsFromPhysics() {
        this.setInputValue('param-fe-slider', this.physics.f_e);
        this.setInputValue('param-fe-num', this.physics.f_e);

        this.setInputValue('param-c-slider', this.physics.c);
        this.setInputValue('param-c-num', this.physics.c);

        this.setInputValue('param-vf-slider', this.physics.v_f.x);
        this.setInputValue('param-vf-num', this.physics.v_f.x);

        this.setInputValue('param-vo-slider', this.physics.v_o.x);
        this.setInputValue('param-vo-num', this.physics.v_o.x);

        this.setInputValue('param-xf-num', this.physics.x_f0.x);
        this.setInputValue('param-xo-num', this.physics.x_o0.x);

        this.setInputValue('param-duration-num', this.physics.getDuration());

        const is2dCheck = document.getElementById('toggle-2d');
        if (is2dCheck) is2dCheck.checked = this.physics.is2D;

        // Actualizar rango del slider de tiempo
        const timeSlider = document.getElementById('time-slider');
        if (timeSlider) {
            timeSlider.min = 0;
            timeSlider.max = this.physics.getDuration();
            timeSlider.step = this.physics.getTimeStep();
            timeSlider.value = this.simTime;
        }

        document.getElementById('total-time-display').textContent = this.physics.getDuration().toFixed(2) + ' s';
    }

    setInputValue(id, val) {
        const el = document.getElementById(id);
        if (el) el.value = val;
    }

    /**
     * Bucle de animación continuo usando requestAnimationFrame.
     */
    animationLoop(currentWallTime) {
        if (!this.lastWallTime) this.lastWallTime = currentWallTime;
        const deltaWallMs = currentWallTime - this.lastWallTime;
        this.lastWallTime = currentWallTime;

        // Si la simulación está en reproducción, avanzar tiempo simulado
        if (this.isPlaying) {
            const dt = (deltaWallMs / 1000.0) * this.playbackRate;
            this.simTime += dt;

            const maxT = this.physics.getDuration();
            if (this.simTime >= maxT) {
                this.simTime = maxT;
                this.pause();
            }
        }

        // Obtener estado determinista puro en simTime
        const simState = this.physics.getStateAt(this.simTime);

        // Renderizar escena en canvas
        this.renderer.render(simState, this.physics);

        // Actualizar audio
        this.audio.update(simState, this.isPlaying);

        // Actualizar gráficas científicas
        this.charts.render(simState, this.physics);

        // Actualizar interfaz HUD y panel matemático
        this.updateHUD(simState);

        // Si la simulación corre o se scrubbea, actualizar panel matemático suavemente
        if (this.isPlaying || this.draggedObject) {
            this.updateMathPanel(simState);
        }

        // Solicitar siguiente cuadro
        requestAnimationFrame((t) => this.animationLoop(t));
    }

    play() {
        this.isPlaying = true;
        const playBtn = document.getElementById('btn-play');
        if (playBtn) {
            playBtn.innerHTML = '⏸ Pausar';
            playBtn.classList.add('btn-active-playing');
        }
    }

    pause() {
        this.isPlaying = false;
        const playBtn = document.getElementById('btn-play');
        if (playBtn) {
            playBtn.innerHTML = '▶ Reproducir';
            playBtn.classList.remove('btn-active-playing');
        }
        this.audio.stopAll();
    }

    togglePlay() {
        if (this.isPlaying) this.pause();
        else this.play();
    }

    reset() {
        this.pause();
        this.simTime = 0.0;
        this.audio.resetPlaybackTracking();
        this.syncInputsFromPhysics();
        this.updateMathPanel();
        this.updateHUD();
    }

    stepForward() {
        this.pause();
        const dt = this.physics.getTimeStep();
        this.simTime = Math.min(this.physics.getDuration(), this.simTime + dt);
        this.audio.resetPlaybackTracking(this.simTime);
        this.updateHUD();
        this.updateMathPanel();
    }

    stepBackward() {
        this.pause();
        const dt = this.physics.getTimeStep();
        this.simTime = Math.max(0, this.simTime - dt);
        this.audio.resetPlaybackTracking(this.simTime);
        this.updateHUD();
        this.updateMathPanel();
    }

    stepPeriodForward() {
        this.pause();
        const T = this.physics.getPeriod();
        this.simTime = Math.min(this.physics.getDuration(), this.simTime + T);
        this.audio.resetPlaybackTracking(this.simTime);
        this.updateHUD();
        this.updateMathPanel();
    }

    stepPeriodBackward() {
        this.pause();
        const T = this.physics.getPeriod();
        this.simTime = Math.max(0, this.simTime - T);
        this.audio.resetPlaybackTracking(this.simTime);
        this.updateHUD();
        this.updateMathPanel();
    }

    seekToTime(t) {
        this.simTime = Math.max(0, Math.min(this.physics.getDuration(), t));
        this.audio.resetPlaybackTracking(this.simTime);
        this.updateHUD();
        this.updateMathPanel();
    }

    /**
     * Actualiza el panel HUD de métricas visuales en pantalla.
     */
    updateHUD(state) {
        if (!state) state = this.physics.getStateAt(this.simTime);

        // Reloj y deslizador de tiempo
        document.getElementById('current-time-display').textContent = state.t.toFixed(3) + ' s';
        const slider = document.getElementById('time-slider');
        if (slider && document.activeElement !== slider) {
            slider.value = state.t;
        }

        // Frecuencias
        document.getElementById('hud-fe').textContent = this.physics.f_e.toFixed(2) + ' Hz';

        const foTheoStr = (state.currentTheoretical && isFinite(state.currentTheoretical))
            ? state.currentTheoretical.toFixed(2) + ' Hz'
            : (state.currentTheoretical === Infinity ? 'Barrera Sónica (∞)' : '-');
        document.getElementById('hud-fo-theo').textContent = foTheoStr;

        const foMedStr = (state.lastMeasuredFreq && isFinite(state.lastMeasuredFreq))
            ? state.lastMeasuredFreq.toFixed(2) + ' Hz'
            : (state.receivedCount < 2 ? 'Esperando 2 llegadas' : '-');
        document.getElementById('hud-fo-med').textContent = foMedStr;

        // Mach y régimen
        const machEl = document.getElementById('hud-mach');
        if (machEl) {
            machEl.textContent = `M = ${state.M.toFixed(2)}`;
            if (state.M < 1.0) machEl.className = 'badge badge-info';
            else if (Math.abs(state.M - 1.0) < 0.05) machEl.className = 'badge badge-warning';
            else machEl.className = 'badge badge-danger';
        }

        // Conteo de frentes
        document.getElementById('hud-emitted-count').textContent = state.emittedCount;
        document.getElementById('hud-received-count').textContent = state.receivedCount;

        // Longitudes de onda
        document.getElementById('hud-lambda0').textContent = this.physics.getWavelength0().toFixed(1) + ' m';
        document.getElementById('hud-lambda-front').textContent = this.physics.getWavelengthFront().toFixed(1) + ' m';
        document.getElementById('hud-lambda-back').textContent = this.physics.getWavelengthBack().toFixed(1) + ' m';
    }

    /**
     * Actualiza el panel matemático con fórmulas simbólicas y sustitución numérica exacta.
     */
    updateMathPanel(state) {
        if (!state) state = this.physics.getStateAt(this.simTime);
        const mathContainer = document.getElementById('math-panel-content');
        if (!mathContainer) return;

        const c = this.physics.c;
        const fe = this.physics.f_e;
        const vf = this.physics.v_f.x;
        const vo = this.physics.v_o.x;

        // Determinación de régimen didáctico
        let regimeDesc = '';
        if (state.M < 1.0) {
            regimeDesc = 'Régimen Subsónico (M < 1): Propagación regular de frentes de onda.';
        } else if (Math.abs(state.M - 1.0) < 0.02) {
            regimeDesc = 'Barrera Sónica (M = 1): Frentes apilados en el frente de avance (singularidad matemática).';
        } else {
            const muDeg = (this.physics.getMachAngle() * 180 / Math.PI).toFixed(1);
            regimeDesc = `Régimen Supersónico (M = ${state.M.toFixed(2)} > 1): Cono de Mach con semiángulo μ = ${muDeg}°.`;
        }

        const foTheoVal = (state.currentTheoretical && isFinite(state.currentTheoretical))
            ? state.currentTheoretical.toFixed(3)
            : 'Indeterminado';

        const foMedVal = (state.lastMeasuredFreq && isFinite(state.lastMeasuredFreq))
            ? state.lastMeasuredFreq.toFixed(3)
            : 'Esperando dos llegadas';

        mathContainer.innerHTML = `
            <div class="math-box">
                <div class="math-title">Ecuación Doppler Vectorial General (Medio en reposo):</div>
                <div class="math-formula">
                    f_o = f_e \\cdot \\frac{c - \\mathbf{n} \\cdot \\mathbf{v}_o}{c - \\mathbf{n} \\cdot \\mathbf{v}_f}
                </div>
                <div class="math-desc">
                    donde <strong>n</strong> es el vector unitario retardado desde la posición de emisión hacia la de recepción:
                </div>
                <div class="math-formula">
                    \\mathbf{n} = \\frac{\\mathbf{x}_o(t_r) - \\mathbf{x}_f(t_e)}{|\\mathbf{x}_o(t_r) - \\mathbf{x}_f(t_e)|}
                </div>
            </div>

            <div class="math-box">
                <div class="math-title">Sustitución Numérica en el Instante Actual:</div>
                <div class="math-substitution">
                    f_o = ${fe.toFixed(2)} \\text{ Hz} \\cdot \\frac{${c.toFixed(1)} - (${vo.toFixed(1)})}{${c.toFixed(1)} - (${vf.toFixed(1)})} 
                    = <strong>${foTheoVal} Hz</strong>
                </div>
                <div class="math-substitution" style="margin-top: 8px;">
                    Frecuencia Medida Empíricamente: f_{\\text{medida}} = \\frac{1}{\\Delta t_r} = <strong>${foMedVal} ${typeof state.lastMeasuredFreq === 'number' ? 'Hz' : ''}</strong>
                </div>
            </div>

            <div class="math-box">
                <div class="math-title">Longitudes de Onda Espaciales en el Medio:</div>
                <div class="math-grid-2">
                    <div>\\lambda_0 = \\frac{c}{f} = \\frac{${c.toFixed(0)}}{${fe.toFixed(1)}} = <strong>${(c/fe).toFixed(1)} m</strong></div>
                    <div>\\lambda_{\\text{delante}} = \\frac{c - v_f}{f} = <strong>${((c - vf)/fe).toFixed(1)} m</strong></div>
                    <div>\\lambda_{\\text{detrás}} = \\frac{c + v_f}{f} = <strong>${((c + vf)/fe).toFixed(1)} m</strong></div>
                    <div>Mach: M = \\frac{|v_f|}{c} = <strong>${state.M.toFixed(3)}</strong></div>
                </div>
            </div>

            <div class="regime-status-badge">
                ${regimeDesc}
            </div>
        `;

        // Renderizar con KaTeX si está disponible
        if (window.renderMathInElement) {
            try {
                window.renderMathInElement(mathContainer, {
                    delimiters: [
                        { left: '$$', right: '$$', display: true },
                        { left: '\\(', right: '\\)', display: false }
                    ]
                });
            } catch (e) {}
        }
    }

    /**
     * Vinculación de eventos de la interfaz de usuario.
     */
    bindEvents() {
        // Redimensionamiento de ventana
        window.addEventListener('resize', () => {
            this.renderer.resize();
        });

        // Modo de la aplicación: Exploración vs Laboratorio
        document.querySelectorAll('.mode-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.mode-tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.appMode = btn.getAttribute('data-mode');
                document.body.setAttribute('data-app-mode', this.appMode);
            });
        });

        // Pestañas laterales
        document.querySelectorAll('.sidebar-tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.sidebar-tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.sidebar-tab-pane').forEach(p => p.classList.remove('active'));

                btn.classList.add('active');
                const paneId = btn.getAttribute('data-pane');
                const pane = document.getElementById(paneId);
                if (pane) pane.classList.add('active');
            });
        });

        // Controles de simulación
        document.getElementById('btn-play').addEventListener('click', () => this.togglePlay());
        document.getElementById('btn-reset').addEventListener('click', () => this.reset());
        document.getElementById('btn-step-prev').addEventListener('click', () => this.stepBackward());
        document.getElementById('btn-step-next').addEventListener('click', () => this.stepForward());
        document.getElementById('btn-step-period-prev').addEventListener('click', () => this.stepPeriodBackward());
        document.getElementById('btn-step-period-next').addEventListener('click', () => this.stepPeriodForward());

        // Scrub slider de tiempo
        const timeSlider = document.getElementById('time-slider');
        timeSlider.addEventListener('input', (e) => {
            this.pause();
            this.seekToTime(parseFloat(e.target.value));
        });

        // Selectores de velocidad de reproducción
        document.querySelectorAll('.rate-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.rate-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.playbackRate = parseFloat(btn.getAttribute('data-rate'));
            });
        });

        // Parámetros físicos con vinculación bidireccional
        this.bindSliderAndNumeric('param-fe-slider', 'param-fe-num', (val) => {
            this.physics.updateParameters({ f_e: val });
            this.audio.setPitchScaleFactor(220 / val);
        });

        this.bindSliderAndNumeric('param-c-slider', 'param-c-num', (val) => {
            this.physics.updateParameters({ c: val });
        });

        this.bindSliderAndNumeric('param-vf-slider', 'param-vf-num', (val) => {
            this.physics.updateParameters({ v_f: { x: val, y: this.physics.v_f.y } });
        });

        this.bindSliderAndNumeric('param-vo-slider', 'param-vo-num', (val) => {
            this.physics.updateParameters({ v_o: { x: val, y: this.physics.v_o.y } });
        });

        // Posiciones iniciales
        document.getElementById('param-xf-num').addEventListener('change', (e) => {
            this.physics.updateParameters({ x_f0: { x: parseFloat(e.target.value) || 0, y: this.physics.x_f0.y } });
            this.reset();
        });
        document.getElementById('param-xo-num').addEventListener('change', (e) => {
            this.physics.updateParameters({ x_o0: { x: parseFloat(e.target.value) || 0, y: this.physics.x_o0.y } });
            this.reset();
        });

        // Duración
        document.getElementById('param-duration-num').addEventListener('change', (e) => {
            this.physics.updateParameters({ totalDuration: parseFloat(e.target.value) || 10 });
            this.syncInputsFromPhysics();
        });

        // Modo 2D
        const toggle2d = document.getElementById('toggle-2d');
        if (toggle2d) {
            toggle2d.addEventListener('change', (e) => {
                this.physics.updateParameters({ is2D: e.target.checked });
                this.reset();
            });
        }

        // Tipo de fuente (Punto, Ambulancia, Avión)
        const srcSelect = document.getElementById('source-type-select');
        if (srcSelect) {
            srcSelect.addEventListener('change', (e) => {
                this.renderer.sourceType = e.target.value;
            });
        }

        // Estilo de frentes
        const styleSelect = document.getElementById('wave-style-select');
        if (styleSelect) {
            styleSelect.addEventListener('change', (e) => {
                this.renderer.waveStyle = e.target.value;
            });
        }

        // Color de frentes
        const colorPicker = document.getElementById('wave-color-picker');
        if (colorPicker) {
            colorPicker.addEventListener('input', (e) => {
                this.renderer.waveColor = e.target.value;
            });
        }

        // Grosor de frentes
        const widthSlider = document.getElementById('wave-width-slider');
        if (widthSlider) {
            widthSlider.addEventListener('input', (e) => {
                this.renderer.waveLineWidth = parseFloat(e.target.value);
            });
        }

        // Atenuación visual
        const attenCheck = document.getElementById('toggle-attenuation');
        if (attenCheck) {
            attenCheck.addEventListener('change', (e) => {
                this.renderer.visualAttenuation = e.target.checked;
            });
        }

        // Barra de herramientas del Canvas
        document.getElementById('btn-zoom-in').addEventListener('click', () => {
            this.renderer.scale = Math.min(5.0, this.renderer.scale * 1.25);
        });
        document.getElementById('btn-zoom-out').addEventListener('click', () => {
            this.renderer.scale = Math.max(0.05, this.renderer.scale / 1.25);
        });
        document.getElementById('btn-fit-scene').addEventListener('click', () => {
            const state = this.physics.getStateAt(this.simTime);
            this.renderer.fitScene(state.posF, state.posO);
        });
        document.getElementById('btn-reset-view').addEventListener('click', () => {
            this.renderer.resetView();
        });

        // Seguimiento de fuente
        const followCheck = document.getElementById('toggle-follow-source');
        if (followCheck) {
            followCheck.addEventListener('change', (e) => {
                this.renderer.followSource = e.target.checked;
            });
        }

        // Herramienta de regla
        const rulerBtn = document.getElementById('btn-ruler-tool');
        if (rulerBtn) {
            rulerBtn.addEventListener('click', () => {
                this.renderer.measureToolActive = !this.renderer.measureToolActive;
                rulerBtn.classList.toggle('active', this.renderer.measureToolActive);
                if (!this.renderer.measureToolActive) {
                    this.renderer.measurePointA = null;
                    this.renderer.measurePointB = null;
                }
            });
        }

        // Audio controls
        const enableAudioBtn = document.getElementById('btn-enable-audio');
        if (enableAudioBtn) {
            enableAudioBtn.addEventListener('click', async () => {
                await this.audio.init();
                enableAudioBtn.innerHTML = '🔊 Audio Activado';
                enableAudioBtn.classList.add('btn-audio-active');
            });
        }

        const volumeSlider = document.getElementById('audio-volume-slider');
        if (volumeSlider) {
            volumeSlider.addEventListener('input', (e) => {
                this.audio.setVolume(parseFloat(e.target.value));
            });
        }

        const audioMuteBtn = document.getElementById('btn-audio-mute');
        if (audioMuteBtn) {
            audioMuteBtn.addEventListener('click', () => {
                const isMuted = this.audio.toggleMute();
                audioMuteBtn.textContent = isMuted ? '🔇 Desmutear' : '🔈 Silenciar';
            });
        }

        const audioModeSelect = document.getElementById('audio-mode-select');
        if (audioModeSelect) {
            audioModeSelect.addEventListener('change', (e) => {
                this.audio.setMode(e.target.value);
            });
        }

        // Tipo de gráfico
        document.querySelectorAll('.chart-type-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.chart-type-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.charts.setChartType(btn.getAttribute('data-chart'));
            });
        });

        // Exportación de datos CSV
        document.getElementById('btn-export-csv').addEventListener('click', () => {
            const csv = this.physics.generateCSV();
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `doppler_datos_${Date.now()}.csv`;
            a.click();
            URL.revokeObjectURL(url);
        });

        // Captura de simulación PNG
        document.getElementById('btn-export-png').addEventListener('click', () => {
            const url = this.canvas.toDataURL('image/png');
            const a = document.createElement('a');
            a.href = url;
            a.download = `simulacion_doppler_${Date.now()}.png`;
            a.click();
        });

        // Tema Claro / Oscuro
        const themeBtn = document.getElementById('btn-toggle-theme');
        if (themeBtn) {
            themeBtn.addEventListener('click', () => {
                const currentTheme = document.body.getAttribute('data-theme') || 'dark';
                const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
                document.body.setAttribute('data-theme', nextTheme);
                this.renderer.theme = nextTheme;
                this.charts.setTheme(nextTheme);
                themeBtn.textContent = nextTheme === 'dark' ? '☀️ Modo Claro' : '🌙 Modo Oscuro';
            });
        }

        // Interacción directa en el Canvas (Ratón y Touch)
        this.bindCanvasMouseAndTouch();

        // Atajos de teclado
        window.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
                return;
            }

            if (e.code === 'Space') {
                e.preventDefault();
                this.togglePlay();
            } else if (e.code === 'KeyR') {
                this.reset();
            } else if (e.code === 'ArrowRight') {
                if (e.shiftKey) this.stepPeriodForward();
                else this.stepForward();
            } else if (e.code === 'ArrowLeft') {
                if (e.shiftKey) this.stepPeriodBackward();
                else this.stepBackward();
            } else if (e.code === 'KeyM') {
                this.audio.toggleMute();
            } else if (e.code === 'KeyH') {
                this.renderer.resetView();
            } else if (e.code === 'KeyF') {
                const state = this.physics.getStateAt(this.simTime);
                this.renderer.fitScene(state.posF, state.posO);
            }
        });
    }

    bindSliderAndNumeric(sliderId, numId, callback) {
        const slider = document.getElementById(sliderId);
        const num = document.getElementById(numId);
        if (!slider || !num) return;

        slider.addEventListener('input', (e) => {
            const val = parseFloat(e.target.value);
            num.value = val;
            callback(val);
            this.syncInputsFromPhysics();
            this.updateMathPanel();
            this.updateHUD();
        });

        num.addEventListener('change', (e) => {
            const val = parseFloat(e.target.value);
            slider.value = val;
            callback(val);
            this.syncInputsFromPhysics();
            this.updateMathPanel();
            this.updateHUD();
        });
    }

    /**
     * Gestión de ratón, zoom centrado y arrastre de objetos o vista.
     */
    bindCanvasMouseAndTouch() {
        const c = this.canvas;

        // Zoom con rueda centrado en el cursor
        c.addEventListener('wheel', (e) => {
            e.preventDefault();
            const rect = c.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            const worldBefore = this.renderer.screenToWorld(mouseX, mouseY);
            const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
            this.renderer.scale = Math.max(0.05, Math.min(5.0, this.renderer.scale * factor));

            // Ajustar cámara para que el punto bajo el cursor no se mueva
            const worldAfter = this.renderer.screenToWorld(mouseX, mouseY);
            this.renderer.camX += (worldBefore.x - worldAfter.x);
            this.renderer.camY += (worldBefore.y - worldAfter.y);
        }, { passive: false });

        // Mousedown
        c.addEventListener('mousedown', (e) => {
            const rect = c.getBoundingClientRect();
            const mx = e.clientX - rect.left;
            const my = e.clientY - rect.top;
            const world = this.renderer.screenToWorld(mx, my);

            // Si la herramienta de regla está activa
            if (this.renderer.measureToolActive) {
                if (!this.renderer.measurePointA) {
                    this.renderer.measurePointA = { x: world.x, y: world.y };
                } else {
                    this.renderer.measurePointB = { x: world.x, y: world.y };
                }
                return;
            }

            // Comprobar si se hace clic en la fuente o en el observador (cuando está en pausa para recolocarlos)
            const state = this.physics.getStateAt(this.simTime);
            const distF = Math.hypot(world.x - state.posF.x, world.y - state.posF.y);
            const distO = Math.hypot(world.x - state.posO.x, world.y - state.posO.y);

            const grabThresholdMeters = 25 / this.renderer.scale;

            if (distF < grabThresholdMeters) {
                this.pause();
                this.draggedObject = 'source';
            } else if (distO < grabThresholdMeters) {
                this.pause();
                this.draggedObject = 'observer';
            } else if (e.button === 0 || e.button === 1 || e.button === 2) {
                this.draggedObject = 'pan';
                this.dragStartPos = { x: mx, y: my, camX: this.renderer.camX, camY: this.renderer.camY };
            }
        });

        // Mousemove
        c.addEventListener('mousemove', (e) => {
            const rect = c.getBoundingClientRect();
            const mx = e.clientX - rect.left;
            const my = e.clientY - rect.top;
            const world = this.renderer.screenToWorld(mx, my);

            // Actualizar segundo punto de regla si se está arrastrando
            if (this.renderer.measureToolActive && this.renderer.measurePointA && !this.renderer.measurePointB) {
                this.renderer.measurePointB = { x: world.x, y: world.y };
            }

            if (this.draggedObject === 'pan' && this.dragStartPos) {
                const dx = (mx - this.dragStartPos.x) / this.renderer.scale;
                const dy = (my - this.dragStartPos.y) / this.renderer.scale;
                this.renderer.camX = this.dragStartPos.camX - dx;
                this.renderer.camY = this.dragStartPos.camY + dy;
            } else if (this.draggedObject === 'source') {
                this.physics.updateParameters({
                    x_f0: { x: world.x, y: this.physics.is2D ? world.y : 0 }
                });
                this.reset();
            } else if (this.draggedObject === 'observer') {
                this.physics.updateParameters({
                    x_o0: { x: world.x, y: this.physics.is2D ? world.y : 0 }
                });
                this.reset();
            } else {
                // Inspección hover de frentes de onda
                const state = this.physics.getStateAt(this.simTime);
                let closestWf = null;
                let minDist = 15 / this.renderer.scale;

                for (const wf of state.activeWavefronts) {
                    const distToCenter = Math.hypot(world.x - wf.xc, world.y - wf.yc);
                    const diffToRadius = Math.abs(distToCenter - wf.r);
                    if (diffToRadius < minDist) {
                        minDist = diffToRadius;
                        closestWf = wf.id;
                    }
                }
                this.renderer.hoveredWavefrontId = closestWf;
            }
        });

        // Mouseup
        window.addEventListener('mouseup', () => {
            this.draggedObject = null;
            this.dragStartPos = null;
        });

        // Click para seleccionar frente de onda
        c.addEventListener('click', (e) => {
            if (this.renderer.hoveredWavefrontId !== null) {
                this.renderer.selectedWavefrontId = this.renderer.hoveredWavefrontId;
            } else {
                this.renderer.selectedWavefrontId = null;
            }
        });

        // Prevenir menú contextual para permitir pan con clic derecho
        c.addEventListener('contextmenu', (e) => e.preventDefault());
    }
}

// Iniciar aplicación al cargar el DOM
window.addEventListener('DOMContentLoaded', () => {
    window.dopplerApp = new DopplerApp();
});

