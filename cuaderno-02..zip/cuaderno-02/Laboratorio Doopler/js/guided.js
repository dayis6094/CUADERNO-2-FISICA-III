/**
 * guided.js - Sistema de Aprendizaje Guiado y Escenarios Experimentales
 * 
 * Implementa 8 escenarios prediseñados obligatorios con:
 * - Objetivo pedagógico.
 * - Parámetros prefijados con botón de carga inmediata.
 * - Pregunta de predicción previa a la simulación.
 * - Procedimiento experimental guiado paso a paso.
 * - Explicación científica de lo observado.
 * - Pregunta de comprobación y retroalimentación interactiva inmediata.
 */

const GUIDED_SCENARIOS = [
    {
        id: 'scenario_1',
        title: '1. Fuente y Observador en Reposo',
        badge: 'Fundamental',
        objective: 'Comprender la propagación estándar de ondas acústicas en un medio homogéneo sin movimiento relativo, verificando que la longitud de onda y la frecuencia observada coinciden exactamente con las emitidas.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 0.0, y: 0.0 },
            v_o: { x: 0.0, y: 0.0 },
            x_f0: { x: -170.0, y: 0.0 },
            x_o0: { x: 170.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 10.0,
            is2D: false,
            sourceType: 'ambulance'
        },
        prediction: {
            question: '¿Qué relación esperas encontrar entre la frecuencia emitida (f_e) y la recibida por el observador (f_o)?',
            options: [
                'La frecuencia observada será mayor debido a la distancia de separación.',
                'La frecuencia observada será exactamente igual a la emitida (f_o = f_e = 2 Hz).',
                'La frecuencia observada será menor porque la onda pierde energía al propagarse.'
            ],
            correctIndex: 1,
            feedbackCorrect: '¡Correcto! Como no hay movimiento respecto al medio ni relativo entre emisor y receptor, la tasa a la que se emiten las crestas es exactamente la tasa a la que se reciben.',
            feedbackIncorrect: 'Incorrecto. En acústica clásica en un medio en reposo sin movimiento relativo, la distancia solo introduce un retardo en el tiempo de vuelo, pero no altera la frecuencia de llegada.'
        },
        procedure: [
            '1. Haz clic en "Cargar Escenario".',
            '2. Inicia la simulación con el botón Play (o barra espaciadora).',
            '3. Observa cómo los frentes de onda se expanden en círculos concéntricos simétricos centrados en la fuente.',
            '4. Activa el audio en modo "Pulsos de llegada" para percibir el ritmo constante de recepción.'
        ],
        explanation: 'En reposo, la distancia entre crestas sucesivas es homogénea en todas las direcciones: λ = c / f = 340 / 2 = 170 m. El sonido emitido en t=0 tarda exactamente t_vuelo = 340 m / 340 m/s = 1.0 s en llegar al observador, tras lo cual cada cresta arriba cada T = 0.5 s, confirmando f_o = 2.0 Hz.',
        checkQuestion: {
            question: 'Si la separación inicial fuera de 680 m en vez de 340 m, ¿cambiaría la frecuencia observada f_o tras alcanzar el régimen estacionario?',
            options: [
                'No, la frecuencia observada sigue siendo 2 Hz; solo aumenta el tiempo de vuelo inicial a 2.0 s.',
                'Sí, la frecuencia caería a 1 Hz por recorrer mayor distancia.',
                'Sí, la frecuencia aumentaría.'
            ],
            correctIndex: 0,
            feedback: '¡Exacto! La separación influye en el tiempo de retardo inicial, pero los frentes siguen arribando con el mismo período T = 0.5 s.'
        }
    },
    {
        id: 'scenario_2',
        title: '2. Fuente que se Aproxima al Observador',
        badge: 'Compresión espacial',
        objective: 'Comprender cómo el movimiento de la fuente hacia el observador comprime espacialmente los frentes de onda en el sentido del avance, aumentando la frecuencia observada.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 170.0, y: 0.0 }, // 0.5 Mach
            v_o: { x: 0.0, y: 0.0 },
            x_f0: { x: -340.0, y: 0.0 },
            x_o0: { x: 170.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 5.0,
            is2D: false,
            sourceType: 'ambulance'
        },
        prediction: {
            question: 'Con la fuente viajando hacia el observador a v_f = 170 m/s (la mitad de c), ¿qué le ocurrirá a la longitud de onda delante y a la frecuencia observada?',
            options: [
                'La longitud de onda se duplica y la frecuencia observada se reduce a la mitad.',
                'La longitud de onda delante se reduce a la mitad (85 m) y la frecuencia observada se duplica a 4 Hz.',
                'La longitud de onda no cambia porque el sonido viaja siempre a 340 m/s.'
            ],
            correctIndex: 1,
            feedbackCorrect: '¡Brillante! Al viajar la fuente a v_f = c/2, persigue su propia onda: λ_delante = (c - v_f)/f = (340 - 170)/2 = 85 m. Dado que las ondas viajan por el medio a c, arriban al doble de frecuencia: f_o = f * c/(c - v_f) = 4.0 Hz.',
            feedbackIncorrect: 'Piénsalo así: entre cada emisión, la fuente se mueve 85 m más cerca del frente anterior antes de emitir el siguiente, apelotonando las crestas.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Observa la compresión de los frentes hacia la derecha (delante) y su dilatación hacia la izquierda (detrás).',
            '3. Revisa en el panel la cota verde "λ_delante = 85.0 m".',
            '4. Observa cómo el observador mide f_medida = 4.00 Hz en cada pulso de llegada.'
        ],
        explanation: 'La rapidez del sonido en el aire inmóvil sigue siendo rigurosamente 340 m/s. El aumento de frecuencia no se debe a que el sonido viaje más rápido, sino a que los frentes de onda están físicamente más juntos en el espacio (efecto Doppler de fuente emisora).',
        checkQuestion: {
            question: '¿Por qué la rapidez del sonido respecto al medio no es (340 + 170) = 510 m/s?',
            options: [
                'Porque una vez emitida en el medio, la onda se propaga según las propiedades elásticas del medio, sin conservar la inercia de la fuente.',
                'Porque el observador cancela la velocidad de la fuente.',
                'Es un error de la simulación, debería viajar a 510 m/s.'
            ],
            correctIndex: 0,
            feedback: '¡Impecable! Las ondas mecánicas acústicas no son proyectiles balísticos; su velocidad de propagación está determinada exclusivamente por el medio material.'
        }
    },
    {
        id: 'scenario_3',
        title: '3. Fuente que se Aleja del Observador',
        badge: 'Dilatación espacial',
        objective: 'Estudiar la dilatación de la longitud de onda detrás de una fuente emisora y la correspondiente disminución de la frecuencia observada (tono más grave).',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: -170.0, y: 0.0 }, // Alejándose hacia -x
            v_o: { x: 0.0, y: 0.0 },
            x_f0: { x: -100.0, y: 0.0 },
            x_o0: { x: 200.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 6.0,
            is2D: false,
            sourceType: 'ambulance'
        },
        prediction: {
            question: 'Si la fuente se aleja a 170 m/s, ¿cuál será la longitud de onda detrás de ella y la frecuencia observada?',
            options: [
                'λ = 255 m y f_o = 1.33 Hz.',
                'λ = 85 m y f_o = 4 Hz.',
                'λ = 170 m y f_o = 2 Hz.'
            ],
            correctIndex: 0,
            feedbackCorrect: '¡Exacto! λ_detrás = (c + v_f)/f = (340 + 170)/2 = 255 m. La frecuencia percibida es f_o = f * c / (c + v_f) = 2 * (340 / 510) = 1.333 Hz.',
            feedbackIncorrect: 'Al alejarse la fuente, cada nuevo frente se emite más lejos del observador, estirando la distancia entre crestas consecutivas.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Nota el amplio distanciamiento entre frentes que viajan hacia la derecha.',
            '3. Verifica en el panel gráfico la caída en la frecuencia medida a 1.33 Hz.',
            '4. Escucha con el modo tonal cómo el sonido es notablemente más grave que el original.'
        ],
        explanation: 'En el alejamiento, la fuente "huye" de su onda anterior en dirección contraria, dejando una distancia física mayor entre crestas consecutivas. El observador tarda más tiempo en ser alcanzado por la siguiente cresta.',
        checkQuestion: {
            question: '¿Qué ocurriría si la velocidad de alejamiento fuera muy grande, por ejemplo v_f = 2c (680 m/s)?',
            options: [
                'La frecuencia se vuelve cero de inmediato.',
                'La frecuencia observada sigue existiendo y vale f_o = 2 * (340 / 1020) = 0.67 Hz; el sonido sigue llegando pero muy espaciado.',
                'El sonido jamás llega al observador.'
            ],
            correctIndex: 1,
            feedback: '¡Correcto! Hacia atrás las ondas siempre viajan hacia el observador a rapidez c, independientemente de la velocidad con que la fuente se aleje en sentido contrario.'
        }
    },
    {
        id: 'scenario_4',
        title: '4. Observador que se Aproxima a Fuente en Reposo',
        badge: 'Recepción cinemática',
        objective: 'Comprender que el movimiento del observador NO cambia la longitud de onda en el medio, sino la rapidez relativa con la que intercepta los frentes de onda.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 0.0, y: 0.0 },
            v_o: { x: -170.0, y: 0.0 }, // Observador viajando hacia la izquierda
            x_f0: { x: -300.0, y: 0.0 },
            x_o0: { x: 300.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 4.0,
            is2D: false,
            sourceType: 'point'
        },
        prediction: {
            question: 'Al moverse el observador hacia la fuente en reposo a v_o = 170 m/s, ¿cambia la longitud de onda λ de los frentes dibujados en el aire?',
            options: [
                'Sí, las ondas se comprimen en el aire a la mitad.',
                'No, los frentes de onda en el aire conservan λ = 170 m; lo que cambia es que el observador "barre" más ondas por segundo.',
                'Las ondas se estiran.'
            ],
            correctIndex: 1,
            feedbackCorrect: '¡Magistral distinción física! La fuente está quieta, por lo que las ondas en el medio son perfectamente concéntricas con λ = 170 m. La mayor frecuencia se debe a que el observador se mueve al encuentro de las ondas a rapidez relativa (c + v_o) = 510 m/s.',
            feedbackIncorrect: 'Cuidado con la trampa conceptual: la fuente no se mueve, por lo que no puede comprimir las ondas en el medio.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Observa que los anillos en el medio son concéntricos y su separación espacial es constante (170 m).',
            '3. Fíjate en el sensor verde avanzando hacia la izquierda e interceptando los frentes a un ritmo acelerado.',
            '4. Comprueba la fórmula f_o = f * (c + v_o)/c = 2 * (510 / 340) = 3.0 Hz.'
        ],
        explanation: 'Este experimento demuestra la asimetría fundamental del efecto Doppler clásico: aunque tanto el movimiento de la fuente como el del observador pueden elevar la frecuencia observada, el mecanismo físico es distinto (compresión espacial en la fuente vs mayor rapidez de intercepción en el observador).',
        checkQuestion: {
            question: 'Compara: ¿por qué f_o = 4.0 Hz cuando la fuente se acerca a 170 m/s (Escenario 2), pero f_o = 3.0 Hz cuando el observador se acerca a 170 m/s?',
            options: [
                'Porque en el caso de la fuente la fórmula tiene (c - v_f) en el denominador (no lineal), mientras que para el observador está en el numerador (lineal).',
                'Es un error de redondeo; deberían ser iguales.',
                'Porque el sonido viaja más rápido en un caso que en el otro.'
            ],
            correctIndex: 0,
            feedback: '¡Exacto! El medio acústico rompe la simetría: las velocidades se miden respecto al aire, a diferencia de la relatividad especial donde no existe éter.'
        }
    },
    {
        id: 'scenario_5',
        title: '5. Observador que se Aleja de Fuente en Reposo',
        badge: 'Recepción retardada',
        objective: 'Analizar cómo un observador que se aleja de una fuente inmóvil recibe los frentes con menor frecuencia debido a su movimiento en la misma dirección de propagación.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 0.0, y: 0.0 },
            v_o: { x: 170.0, y: 0.0 }, // Observador alejándose hacia +x
            x_f0: { x: -200.0, y: 0.0 },
            x_o0: { x: 0.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 6.0,
            is2D: false,
            sourceType: 'point'
        },
        prediction: {
            question: 'Con el observador alejándose a 170 m/s, ¿cuál será la frecuencia observada f_o?',
            options: [
                'f_o = 2 * (340 - 170) / 340 = 1.0 Hz.',
                'f_o = 0 Hz.',
                'f_o = 1.33 Hz.'
            ],
            correctIndex: 0,
            feedbackCorrect: '¡Correcto! La rapidez relativa con la que la onda alcanza al observador es (c - v_o) = 340 - 170 = 170 m/s, la mitad de c. Por tanto, f_o = 1.0 Hz.',
            feedbackIncorrect: 'Aplica la fórmula escolar: f_o = f * (c - v_o) / c.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Observa cómo el observador "corre" delante de los frentes de onda.',
            '3. Mide el tiempo entre llegadas: Δt_r = 1.0 s en lugar del período original de 0.5 s.',
            '4. Confirma que f_medida = 1.0 Hz.'
        ],
        explanation: 'Como el observador se desplaza en el mismo sentido en que viaja la onda, cada frente tarda más tiempo en alcanzarlo y sobrepasarlo. Si el observador viajara a v_o = c (340 m/s), la onda nunca lo rebasaría y f_o sería 0.',
        checkQuestion: {
            question: '¿Qué sucedería si el observador se alejara a v_o > c (por ejemplo 400 m/s)?',
            options: [
                'Escucharía el sonido al revés con frecuencia negativa.',
                'El sonido jamás lo alcanzaría (las ondas viajan a 340 m/s y el observador a 400 m/s).',
                'Escucharía un estampido sónico.'
            ],
            correctIndex: 1,
            feedback: '¡Exacto! Si huyes más rápido que la rapidez con la que viaja la onda en el medio, ningún frente posterior puede alcanzarte jamás.'
        }
    },
    {
        id: 'scenario_6',
        title: '6. Ambos en Movimiento con Igual Velocidad',
        badge: 'Separación constante',
        objective: 'Demostrar que cuando fuente y observador viajan con la misma velocidad en la misma dirección y sentido, la frecuencia observada es exactamente igual a la emitida.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 100.0, y: 0.0 },
            v_o: { x: 100.0, y: 0.0 },
            x_f0: { x: -200.0, y: 0.0 },
            x_o0: { x: 150.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 6.0,
            is2D: false,
            sourceType: 'ambulance'
        },
        prediction: {
            question: 'Si tanto la fuente como el observador viajan a 100 m/s hacia la derecha manteniendo su distancia constante, ¿qué frecuencia medirá el observador?',
            options: [
                'Medirá una frecuencia más alta porque la fuente se mueve hacia él.',
                'Medirá exactamente 2.0 Hz: la compresión del frente emitido se cancela con el alejamiento del observador.',
                'Medirá una frecuencia más baja.'
            ],
            correctIndex: 1,
            feedbackCorrect: '¡Perfecto! Matemáticamente: f_o = f * (c - v_o)/(c - v_f). Como v_o = v_f = 100 m/s, el factor es (340 - 100)/(340 - 100) = 1, dando exactamente 2.0 Hz.',
            feedbackIncorrect: 'Observa que aunque la fuente comprime las ondas hacia adelante, el observador se aleja del frente a la misma velocidad.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Observa cómo ambos objetos se desplazan paralelamente manteniendo su distancia fija de 350 m.',
            '3. Revisa la gráfica de frecuencias: tanto f_e, f_teórica como f_medida se superponen en 2.00 Hz.',
            '4. Comprueba que el tiempo de vuelo entre cada emisión y recepción es idéntico para todos los frentes.'
        ],
        explanation: 'Este caso ilustra cómo el efecto de compresión de la fuente se cancela con la menor tasa de intercepción del observador en fuga. Si estuvieras dentro del vehículo o en un coche escolta a igual velocidad, no percibirías cambio de tono.',
        checkQuestion: {
            question: '¿Significa esto que las ondas en el aire no están comprimidas?',
            options: [
                'No, en el aire sí están comprimidas: λ = (340 - 100)/2 = 120 m. Pero el observador se mueve a 100 m/s y las cruza a una tasa compensada.',
                'Sí, las ondas en el aire tienen 170 m.',
                'No hay ondas.'
            ],
            correctIndex: 0,
            feedback: '¡Excelente perspicacia física! El medio físico registra la compresión real de la onda, pero el marco del observador cancela la variación de frecuencia.'
        }
    },
    {
        id: 'scenario_7',
        title: '7. Paso Lateral 2D (Observador Fuera del Eje)',
        badge: 'Doppler vectorial 2D',
        objective: 'Comprender el efecto Doppler bidimensional: la variación continua del tono acústico (de agudo a grave) a medida que el ángulo del vector unitario n cambia continuamente.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 170.0, y: 0.0 }, // Fuente viajando sobre el eje y = 100 m
            v_o: { x: 0.0, y: 0.0 },    // Observador fijo en (0, 0)
            x_f0: { x: -350.0, y: 100.0 },
            x_o0: { x: 0.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 5.0,
            is2D: true,
            sourceType: 'ambulance'
        },
        prediction: {
            question: 'Cuando la ambulancia pasa frente a ti por una calle lateral, ¿el tono cambia bruscamente o de manera continua y gradual?',
            options: [
                'Cambia instantáneamente en un salto brusco justo al cruzar la esquina.',
                'Cambia de manera suave y continua: es agudo en la aproximación lejana, disminuye al pasar cerca y se vuelve grave al alejarse.',
                'Permanece constante todo el tiempo.'
            ],
            correctIndex: 1,
            feedbackCorrect: '¡Exacto! Es el famoso sonido "¡ñiii-aaa-uuu-m!". La proyección n · v_f depende del coseno del ángulo retardado, el cual varía de forma continua de 1 a -1.',
            feedbackIncorrect: 'En 2D, el vector unitario n va rotando continuamente según la posición retardada de la fuente respecto al observador.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Observa el vector verde n apuntando desde cada punto de emisión hacia el observador.',
            '3. Mira la gráfica de frecuencia: verás una curva en forma de "S" invertida que desciende continuamente desde ~3.7 Hz hasta ~1.4 Hz.',
            '4. Activa el modo de audio "Comparación tonal" para escuchar el clásico deslizamiento de frecuencia.'
        ],
        explanation: 'En el punto de máxima aproximación (cuando la fuente está justo frente al observador), la velocidad es perpendicular al vector de posición (cos θ = 0), por lo que f_o coincide brevemente con la frecuencia emitida de 2.0 Hz.',
        checkQuestion: {
            question: '¿En qué instante el observador percibe exactamente la frecuencia emitida f_e = 2 Hz?',
            options: [
                'Cuando la onda que fue emitida en el punto de mínima distancia perpendicular alcanza al observador.',
                'Nunca, siempre es distinta.',
                'Solo al inicio de la simulación.'
            ],
            correctIndex: 0,
            feedback: '¡Correcto! Cuando la velocidad de la fuente es exactamente perpendicular a la línea de mira en el instante de emisión, n · v_f = 0 y f_o = f_e.'
        }
    },
    {
        id: 'scenario_8',
        title: '8. Régimen Sónico y Supersónico (Mach 1 y Mach 1.5)',
        badge: 'Barrera y Cono de Mach',
        objective: 'Estudiar la superposición extrema de frentes en la barrera del sonido (M=1) y la formación de la envolvente cónica de Mach en régimen supersónico (M > 1), con el fenómeno del estampido y la inversión temporal.',
        params: {
            f_e: 2.0,
            c: 340.0,
            v_f: { x: 510.0, y: 0.0 }, // Mach 1.5 (510 m/s)
            v_o: { x: 0.0, y: 0.0 },
            x_f0: { x: -400.0, y: 150.0 },
            x_o0: { x: 100.0, y: 0.0 },
            durationMode: 'fixed',
            totalDuration: 4.0,
            is2D: true,
            sourceType: 'jet'
        },
        prediction: {
            question: 'Para un jet viajando a Mach 1.5 (v_f = 510 m/s), ¿qué escucha el observador antes de que el cono de Mach lo alcance?',
            options: [
                'Escucha el sonido del avión con mucha anticipación.',
                'Absoluto silencio: el avión viaja más rápido que las ondas que emite, por lo que ninguna onda puede adelantarlo.',
                'Un tono muy agudo permanente.'
            ],
            correctIndex: 1,
            feedbackCorrect: '¡Fascinante y correcto! En la "zona de silencio" delante del cono de Mach, ninguna onda ha tenido tiempo de llegar. Solo al cruzar la envolvente de choque se recibe el estampido sónico repentino.',
            feedbackIncorrect: 'Recuerda: las ondas viajan a 340 m/s, pero el jet vuela a 510 m/s. Las ondas quedan confinadas dentro del cono detrás del jet.'
        },
        procedure: [
            '1. Carga el escenario y pulsa Play.',
            '2. Observa la envolvente roja del cono de Mach con ángulo μ = arcsin(1/1.5) = 41.8°.',
            '3. Fíjate en cómo los frentes se cruzan e interfieren en el interior del cono.',
            '4. Activa el audio: notarás silencio hasta que la línea roja del cono cruza el micrófono verde, disparando la sonificación del estampido.'
        ],
        explanation: 'En régimen supersónico, el observador situado dentro del cono recibe en cada instante ondas de DOS instantes distintos de emisión (inversión temporal: ondas emitidas más tarde llegan antes que las emitidas más temprano). La fórmula clásica ordinaria f_o = f * c/(c - v_f) diverge en M=1 dando una singularidad física que corresponde a la acumulación infinita de frentes en una onda de choque.',
        checkQuestion: {
            question: 'Si el jet aumenta su rapidez a Mach 2 (680 m/s), ¿el cono de Mach se hace más abierto o más afilado/cerrado?',
            options: [
                'Se hace más afilado: el semiángulo se reduce a μ = arcsin(1/2) = 30°.',
                'Se hace más ancho: μ aumenta a 60°.',
                'No cambia de ángulo.'
            ],
            correctIndex: 0,
            feedback: '¡Perfecto! A mayor número de Mach, el cono se vuelve cada vez más estrecho: sin μ = 1/M.'
        }
    }
];

class DopplerGuidedCurriculum {
    constructor(containerElement, onApplyScenario) {
        this.container = containerElement;
        this.onApplyScenario = onApplyScenario;
        this.currentScenarioIndex = 0;
        this.userAnswers = {}; // { scenarioId: { prediction: index, check: index } }
    }

    render() {
        if (!this.container) return;

        const sc = GUIDED_SCENARIOS[this.currentScenarioIndex];
        const answers = this.userAnswers[sc.id] || {};

        let navButtons = '';
        for (let i = 0; i < GUIDED_SCENARIOS.length; i++) {
            const isActive = i === this.currentScenarioIndex;
            navButtons += `
                <button class="scenario-tab-btn ${isActive ? 'active' : ''}" data-idx="${i}">
                    ${i + 1}
                </button>
            `;
        }

        this.container.innerHTML = `
            <div class="guided-header">
                <div class="scenario-badge">${sc.badge}</div>
                <h3 class="scenario-title">${sc.title}</h3>
                <div class="scenario-tabs-strip">
                    ${navButtons}
                </div>
            </div>

            <div class="guided-body">
                <div class="guided-section">
                    <h4>🎯 Objetivo Pedagógico</h4>
                    <p>${sc.objective}</p>
                    <button class="btn btn-primary btn-load-scenario" style="margin-top: 10px;">
                        📥 Cargar este Escenario en el Simulador
                    </button>
                </div>

                <div class="guided-section">
                    <h4>🔮 1. Pregunta de Predicción (Antes de simular)</h4>
                    <p class="question-text">${sc.prediction.question}</p>
                    <div class="options-group" id="pred-options">
                        ${sc.prediction.options.map((opt, i) => `
                            <button class="option-btn ${answers.prediction === i ? (i === sc.prediction.correctIndex ? 'correct' : 'incorrect') : ''}" data-type="pred" data-opt="${i}">
                                <strong>${String.fromCharCode(65 + i)}.</strong> ${opt}
                            </button>
                        `).join('')}
                    </div>
                    ${answers.prediction !== undefined ? `
                        <div class="feedback-box ${answers.prediction === sc.prediction.correctIndex ? 'feedback-good' : 'feedback-bad'}">
                            ${answers.prediction === sc.prediction.correctIndex ? sc.prediction.feedbackCorrect : sc.prediction.feedbackIncorrect}
                        </div>
                    ` : ''}
                </div>

                <div class="guided-section">
                    <h4>🔬 2. Procedimiento Experimental</h4>
                    <ul class="procedure-list">
                        ${sc.procedure.map(step => `<li>${step}</li>`).join('')}
                    </ul>
                </div>

                <div class="guided-section">
                    <h4>💡 3. Explicación Científica</h4>
                    <p>${sc.explanation}</p>
                </div>

                <div class="guided-section">
                    <h4>🧠 4. Comprobación de Concepto</h4>
                    <p class="question-text">${sc.checkQuestion.question}</p>
                    <div class="options-group" id="check-options">
                        ${sc.checkQuestion.options.map((opt, i) => `
                            <button class="option-btn ${answers.check === i ? (i === sc.checkQuestion.correctIndex ? 'correct' : 'incorrect') : ''}" data-type="check" data-opt="${i}">
                                <strong>${String.fromCharCode(65 + i)}.</strong> ${opt}
                            </button>
                        `).join('')}
                    </div>
                    ${answers.check !== undefined ? `
                        <div class="feedback-box ${answers.check === sc.checkQuestion.correctIndex ? 'feedback-good' : 'feedback-bad'}">
                            ${answers.check === sc.checkQuestion.correctIndex ? sc.checkQuestion.feedback : 'Vuelve a revisar la explicación física y vuelve a intentarlo.'}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        this.bindEvents();
    }

    bindEvents() {
        // Selector de pestaña de escenario
        this.container.querySelectorAll('.scenario-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(btn.getAttribute('data-idx'));
                this.currentScenarioIndex = idx;
                this.render();
            });
        });

        // Botón Cargar Escenario
        const loadBtn = this.container.querySelector('.btn-load-scenario');
        if (loadBtn) {
            loadBtn.addEventListener('click', () => {
                const sc = GUIDED_SCENARIOS[this.currentScenarioIndex];
                if (typeof this.onApplyScenario === 'function') {
                    this.onApplyScenario(sc.params);
                }
            });
        }

        // Opciones de respuesta
        this.container.querySelectorAll('.option-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const type = btn.getAttribute('data-type');
                const optIdx = parseInt(btn.getAttribute('data-opt'));
                const sc = GUIDED_SCENARIOS[this.currentScenarioIndex];

                if (!this.userAnswers[sc.id]) {
                    this.userAnswers[sc.id] = {};
                }

                if (type === 'pred') {
                    this.userAnswers[sc.id].prediction = optIdx;
                } else if (type === 'check') {
                    this.userAnswers[sc.id].check = optIdx;
                }

                this.render();
            });
        });
    }
}

if (typeof window !== 'undefined') {
    window.GUIDED_SCENARIOS = GUIDED_SCENARIOS;
    window.DopplerGuidedCurriculum = DopplerGuidedCurriculum;
}

