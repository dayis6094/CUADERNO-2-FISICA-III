/**
 * charts.js - Gráficas Científicas Sincronizadas en Tiempo Real
 * 
 * Implementa 4 gráficas sincronizadas con cursor de tiempo actual t:
 * 1. Posición vs Tiempo: x_f(t) y x_o(t).
 * 2. Distancia de separación: d(t) = |x_o(t) - x_f(t)|.
 * 3. Frecuencias: Emitida, Teórica f_o(t) y Medida experimental f_medida en recepciones.
 * 4. Diagrama Espacio-Temporal (t vs x) con conos de emisión y líneas de universo.
 * 
 * Rendimiento optimizado en Canvas 2D directo con descarga a PNG.
 */

class DopplerCharts {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.currentChart = 'frequency'; // 'position' | 'distance' | 'frequency' | 'spacetime'
        this.theme = 'dark';
    }

    setChartType(type) {
        this.currentChart = type;
    }

    setTheme(theme) {
        this.theme = theme;
    }

    render(simState, physicsEngine) {
        if (!this.ctx || !this.canvas) return;

        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.getBoundingClientRect();
        const w = Math.max(300, Math.floor(rect.width));
        const h = Math.max(180, Math.floor(rect.height));

        if (this.canvas.width !== w * dpr || this.canvas.height !== h * dpr) {
            this.canvas.width = w * dpr;
            this.canvas.height = h * dpr;
            this.ctx.resetTransform();
            this.ctx.scale(dpr, dpr);
        }

        const isDark = this.theme === 'dark';
        const bgColor = isDark ? '#0b1120' : '#ffffff';
        const axisColor = isDark ? '#334155' : '#cbd5e1';
        const textColor = isDark ? '#94a3b8' : '#64748b';
        const playheadColor = '#ef4444';

        // 1. Limpiar fondo
        this.ctx.fillStyle = bgColor;
        this.ctx.fillRect(0, 0, w, h);

        const margin = { top: 25, right: 30, bottom: 35, left: 55 };
        const plotW = w - margin.left - margin.right;
        const plotH = h - margin.top - margin.bottom;

        const totalT = physicsEngine.getDuration();
        const currentT = simState.t;

        // Selección de renderizado según tipo de gráfico
        if (this.currentChart === 'position') {
            this.drawPositionChart(margin, plotW, plotH, totalT, currentT, physicsEngine, textColor, axisColor, playheadColor);
        } else if (this.currentChart === 'distance') {
            this.drawDistanceChart(margin, plotW, plotH, totalT, currentT, physicsEngine, textColor, axisColor, playheadColor);
        } else if (this.currentChart === 'frequency') {
            this.drawFrequencyChart(margin, plotW, plotH, totalT, currentT, simState, physicsEngine, textColor, axisColor, playheadColor);
        } else if (this.currentChart === 'spacetime') {
            this.drawSpaceTimeChart(margin, plotW, plotH, totalT, currentT, physicsEngine, textColor, axisColor, playheadColor);
        }
    }

    /**
     * Gráfico 1: Posición x(t) de fuente y observador.
     */
    drawPositionChart(margin, plotW, plotH, totalT, currentT, physics, textColor, axisColor, playheadColor) {
        // Encontrar rango mínimo y máximo de x
        const samples = 100;
        let minX = Infinity;
        let maxX = -Infinity;

        for (let i = 0; i <= samples; i++) {
            const t = (i / samples) * totalT;
            const xf = physics.getSourcePosition(t).x;
            const xo = physics.getObserverPosition(t).x;
            minX = Math.min(minX, xf, xo);
            maxX = Math.max(maxX, xf, xo);
        }
        const span = Math.max(50, maxX - minX);
        minX -= span * 0.1;
        maxX += span * 0.1;

        const mapX = (t) => margin.left + (t / totalT) * plotW;
        const mapY = (val) => margin.top + plotH - ((val - minX) / (maxX - minX)) * plotH;

        this.drawAxes(margin, plotW, plotH, 'Tiempo t (s)', 'Posición x (m)', totalT, minX, maxX, textColor, axisColor);

        // Trayectoria Fuente (Rosa)
        this.ctx.beginPath();
        for (let i = 0; i <= samples; i++) {
            const t = (i / samples) * totalT;
            const xf = physics.getSourcePosition(t).x;
            const px = mapX(t);
            const py = mapY(xf);
            if (i === 0) this.ctx.moveTo(px, py);
            else this.ctx.lineTo(px, py);
        }
        this.ctx.strokeStyle = '#ec4899';
        this.ctx.lineWidth = 2.2;
        this.ctx.stroke();

        // Trayectoria Observador (Violeta)
        this.ctx.beginPath();
        for (let i = 0; i <= samples; i++) {
            const t = (i / samples) * totalT;
            const xo = physics.getObserverPosition(t).x;
            const px = mapX(t);
            const py = mapY(xo);
            if (i === 0) this.ctx.moveTo(px, py);
            else this.ctx.lineTo(px, py);
        }
        this.ctx.strokeStyle = '#8b5cf6';
        this.ctx.lineWidth = 2.2;
        this.ctx.stroke();

        // Leyenda
        this.drawLegend([
            { label: 'Fuente x_f(t)', color: '#ec4899' },
            { label: 'Observador x_o(t)', color: '#8b5cf6' }
        ], margin.left + 10, margin.top + 15);

        // Cursor de tiempo
        this.drawPlayhead(mapX(currentT), margin.top, plotH, playheadColor);
    }

    /**
     * Gráfico 2: Distancia de separación d(t).
     */
    drawDistanceChart(margin, plotW, plotH, totalT, currentT, physics, textColor, axisColor, playheadColor) {
        const samples = 100;
        let maxD = 0;
        for (let i = 0; i <= samples; i++) {
            const t = (i / samples) * totalT;
            const pf = physics.getSourcePosition(t);
            const po = physics.getObserverPosition(t);
            const d = Math.hypot(po.x - pf.x, po.y - pf.y);
            maxD = Math.max(maxD, d);
        }
        maxD = Math.max(50, maxD * 1.15);

        const mapX = (t) => margin.left + (t / totalT) * plotW;
        const mapY = (val) => margin.top + plotH - (val / maxD) * plotH;

        this.drawAxes(margin, plotW, plotH, 'Tiempo t (s)', 'Separación d (m)', totalT, 0, maxD, textColor, axisColor);

        // Curva de distancia
        this.ctx.beginPath();
        for (let i = 0; i <= samples; i++) {
            const t = (i / samples) * totalT;
            const pf = physics.getSourcePosition(t);
            const po = physics.getObserverPosition(t);
            const d = Math.hypot(po.x - pf.x, po.y - pf.y);
            const px = mapX(t);
            const py = mapY(d);
            if (i === 0) this.ctx.moveTo(px, py);
            else this.ctx.lineTo(px, py);
        }
        this.ctx.strokeStyle = '#06b6d4'; // Cian
        this.ctx.lineWidth = 2.2;
        this.ctx.stroke();

        this.drawLegend([
            { label: 'Distancia |x_o - x_f| (m)', color: '#06b6d4' }
        ], margin.left + 10, margin.top + 15);

        this.drawPlayhead(mapX(currentT), margin.top, plotH, playheadColor);
    }

    /**
     * Gráfico 3: Frecuencias teóricas y medidas experimentales por recepciones.
     */
    drawFrequencyChart(margin, plotW, plotH, totalT, currentT, simState, physics, textColor, axisColor, playheadColor) {
        const f_e = physics.f_e;
        let maxF = f_e * 2.5;

        // Evaluar rango de frecuencias teóricas y medidas
        for (const rec of physics.receptions) {
            if (rec.fo_theoretical && isFinite(rec.fo_theoretical)) {
                maxF = Math.max(maxF, rec.fo_theoretical * 1.25);
            }
            if (rec.measuredFreq && isFinite(rec.measuredFreq)) {
                maxF = Math.max(maxF, rec.measuredFreq * 1.25);
            }
        }
        maxF = Math.min(20 * f_e, maxF); // Limitar picos asintóticos

        const mapX = (t) => margin.left + (t / totalT) * plotW;
        const mapY = (f) => margin.top + plotH - (Math.max(0, f) / maxF) * plotH;

        this.drawAxes(margin, plotW, plotH, 'Tiempo t (s)', 'Frecuencia f (Hz)', totalT, 0, maxF, textColor, axisColor);

        // Línea constante: Frecuencia emitida f_e (gris discontinuo)
        this.ctx.save();
        this.ctx.setLineDash([4, 4]);
        this.ctx.strokeStyle = '#94a3b8';
        this.ctx.beginPath();
        const yFe = mapY(f_e);
        this.ctx.moveTo(margin.left, yFe);
        this.ctx.lineTo(margin.left + plotW, yFe);
        this.ctx.stroke();
        this.ctx.restore();

        // Curva Teórica f_o(t) evaluada en tiempos de llegada
        const validRecs = physics.receptions.filter(r => r.fo_theoretical && isFinite(r.fo_theoretical) && r.tr <= totalT);
        if (validRecs.length > 1) {
            this.ctx.beginPath();
            for (let i = 0; i < validRecs.length; i++) {
                const px = mapX(validRecs[i].tr);
                const py = mapY(validRecs[i].fo_theoretical);
                if (i === 0) this.ctx.moveTo(px, py);
                else this.ctx.lineTo(px, py);
            }
            this.ctx.strokeStyle = '#38bdf8'; // Celeste teórico
            this.ctx.lineWidth = 2.2;
            this.ctx.stroke();
        }

        // Puntos de Frecuencia Medida Empírica f_medida = 1 / Delta t_r (Puntos verdes)
        for (const rec of physics.receptions) {
            if (rec.measuredFreq && isFinite(rec.measuredFreq) && rec.tr <= totalT) {
                const px = mapX(rec.tr);
                const py = mapY(rec.measuredFreq);

                this.ctx.beginPath();
                this.ctx.arc(px, py, 4, 0, Math.PI * 2);
                this.ctx.fillStyle = (rec.tr <= currentT) ? '#10b981' : 'rgba(16, 185, 129, 0.3)';
                this.ctx.fill();
            }
        }

        this.drawLegend([
            { label: 'f_emitida (Hz)', color: '#94a3b8' },
            { label: 'f_o Teórica (Hz)', color: '#38bdf8' },
            { label: 'f_medida Experimental (Hz)', color: '#10b981' }
        ], margin.left + 10, margin.top + 15);

        this.drawPlayhead(mapX(currentT), margin.top, plotH, playheadColor);
    }

    /**
     * Gráfico 4: Diagrama Espacio-Temporal (x vs t).
     */
    drawSpaceTimeChart(margin, plotW, plotH, totalT, currentT, physics, textColor, axisColor, playheadColor) {
        let minX = Math.min(physics.x_f0.x, physics.x_o0.x) - 100;
        let maxX = Math.max(physics.x_f0.x, physics.x_o0.x) + 100;
        for (const wf of physics.wavefronts) {
            minX = Math.min(minX, wf.xc);
            maxX = Math.max(maxX, wf.xc);
        }
        const span = Math.max(100, maxX - minX);
        minX -= span * 0.1;
        maxX += span * 0.1;

        const mapX = (x) => margin.left + ((x - minX) / (maxX - minX)) * plotW;
        const mapT = (t) => margin.top + plotH - (t / totalT) * plotH;

        this.drawAxes(margin, plotW, plotH, 'Posición x (m)', 'Tiempo t (s)', maxX, 0, totalT, textColor, axisColor);

        // Rayos de emisión de ondas hacia el observador (rectas con pendiente c)
        this.ctx.save();
        this.ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
        this.ctx.lineWidth = 1;
        for (const wf of physics.wavefronts) {
            if (wf.tr && wf.tr <= totalT) {
                const startX = mapX(wf.xc);
                const startY = mapT(wf.te);
                const endX = mapX(physics.getObserverPosition(wf.tr).x);
                const endY = mapT(wf.tr);

                this.ctx.beginPath();
                this.ctx.moveTo(startX, startY);
                this.ctx.lineTo(endX, endY);
                this.ctx.stroke();
            }
        }
        this.ctx.restore();

        // Línea de universo de la fuente
        this.ctx.beginPath();
        for (let i = 0; i <= 60; i++) {
            const t = (i / 60) * totalT;
            const xf = physics.getSourcePosition(t).x;
            const px = mapX(xf);
            const py = mapT(t);
            if (i === 0) this.ctx.moveTo(px, py);
            else this.ctx.lineTo(px, py);
        }
        this.ctx.strokeStyle = '#ec4899';
        this.ctx.lineWidth = 2.2;
        this.ctx.stroke();

        // Línea de universo del observador
        this.ctx.beginPath();
        for (let i = 0; i <= 60; i++) {
            const t = (i / 60) * totalT;
            const xo = physics.getObserverPosition(t).x;
            const px = mapX(xo);
            const py = mapT(t);
            if (i === 0) this.ctx.moveTo(px, py);
            else this.ctx.lineTo(px, py);
        }
        this.ctx.strokeStyle = '#8b5cf6';
        this.ctx.lineWidth = 2.2;
        this.ctx.stroke();

        // Línea horizontal del instante actual
        const curY = mapT(currentT);
        this.ctx.save();
        this.ctx.strokeStyle = playheadColor;
        this.ctx.lineWidth = 1.5;
        this.ctx.beginPath();
        this.ctx.moveTo(margin.left, curY);
        this.ctx.lineTo(margin.left + plotW, curY);
        this.ctx.stroke();
        this.ctx.restore();

        this.drawLegend([
            { label: 'Universo Fuente', color: '#ec4899' },
            { label: 'Universo Observador', color: '#8b5cf6' },
            { label: 'Propagación Sonido (c)', color: '#38bdf8' }
        ], margin.left + 10, margin.top + 15);
    }

    /**
     * Dibuja los ejes coordenados y marcas numéricas.
     */
    drawAxes(margin, plotW, plotH, xLabel, yLabel, xMax, yMin, yMax, textColor, axisColor) {
        this.ctx.save();
        this.ctx.strokeStyle = axisColor;
        this.ctx.fillStyle = textColor;
        this.ctx.lineWidth = 1;
        this.ctx.font = '10px Inter, system-ui, sans-serif';

        // Marco del plot
        this.ctx.strokeRect(margin.left, margin.top, plotW, plotH);

        // Marcas en eje X
        for (let i = 0; i <= 5; i++) {
            const fraction = i / 5;
            const x = margin.left + fraction * plotW;
            const val = (fraction * xMax).toFixed(1);

            this.ctx.beginPath();
            this.ctx.moveTo(x, margin.top + plotH);
            this.ctx.lineTo(x, margin.top + plotH + 4);
            this.ctx.stroke();
            this.ctx.textAlign = 'center';
            this.ctx.fillText(val, x, margin.top + plotH + 15);
        }

        // Marcas en eje Y
        for (let i = 0; i <= 4; i++) {
            const fraction = i / 4;
            const y = margin.top + plotH - fraction * plotH;
            const val = (yMin + fraction * (yMax - yMin)).toFixed(0);

            this.ctx.beginPath();
            this.ctx.moveTo(margin.left - 4, y);
            this.ctx.lineTo(margin.left, y);
            this.ctx.stroke();
            this.ctx.textAlign = 'right';
            this.ctx.fillText(val, margin.left - 7, y + 3);
        }

        // Etiquetas de ejes
        this.ctx.font = 'bold 11px Inter, system-ui, sans-serif';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(xLabel, margin.left + plotW / 2, margin.top + plotH + 30);

        this.ctx.save();
        this.ctx.translate(15, margin.top + plotH / 2);
        this.ctx.rotate(-Math.PI / 2);
        this.ctx.fillText(yLabel, 0, 0);
        this.ctx.restore();

        this.ctx.restore();
    }

    /**
     * Dibuja la barra de cursor temporal vertical (playhead).
     */
    drawPlayhead(x, topY, height, color) {
        this.ctx.save();
        this.ctx.strokeStyle = color;
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.moveTo(x, topY);
        this.ctx.lineTo(x, topY + height);
        this.ctx.stroke();
        this.ctx.restore();
    }

    /**
     * Dibuja la leyenda en la parte superior.
     */
    drawLegend(items, startX, startY) {
        this.ctx.save();
        let curX = startX;
        this.ctx.font = '11px Inter, system-ui, sans-serif';
        this.ctx.textAlign = 'left';

        for (const item of items) {
            this.ctx.fillStyle = item.color;
            this.ctx.fillRect(curX, startY - 8, 10, 10);
            this.ctx.fillStyle = this.theme === 'dark' ? '#f1f5f9' : '#1e293b';
            this.ctx.fillText(item.label, curX + 14, startY);
            curX += this.ctx.measureText(item.label).width + 30;
        }
        this.ctx.restore();
    }

    /**
     * Exporta el canvas del gráfico a imagen PNG.
     */
    exportPNG() {
        return this.canvas.toDataURL('image/png');
    }
}

if (typeof window !== 'undefined') {
    window.DopplerCharts = DopplerCharts;
}

