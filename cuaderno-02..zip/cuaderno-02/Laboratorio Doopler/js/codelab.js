/**
 * codelab.js - Laboratorio de Programación Educativa
 * 
 * Permite a estudiantes y docentes programar trayectorias personalizadas para
 * la fuente y el observador mediante una API segura y documentada.
 * 
 * Incluye:
 * - Presets educativos (MAS oscilatorio, aceleración constante MRUA, órbita circular 2D).
 * - Entorno de ejecución en sandbox seguro con validación estricta y captura de errores.
 * - Numeración de líneas y resaltado.
 */

const CODELAB_PRESETS = {
    harmonic: {
        name: 'Oscilador Armónico Simple (MAS)',
        desc: 'La fuente oscila periódicamente con amplitud de 150 m y frecuencia angular ω = 1.0 rad/s.',
        code: `// Movimiento Armónico Simple de la fuente
// Parámetros de oscilación:
const A = 150;     // Amplitud en metros
const omega = 1.0; // Frecuencia angular en rad/s

function posF(t) {
    return { x: A * Math.sin(omega * t), y: 0 };
}

function velF(t) {
    return { x: A * omega * Math.cos(omega * t), y: 0 };
}

function posO(t) {
    return { x: 250, y: 0 }; // Observador estático en x = 250 m
}

function velO(t) {
    return { x: 0, y: 0 };
}
`
    },
    accelerated: {
        name: 'Movimiento Uniformemente Acelerado (MRUA)',
        desc: 'La fuente parte del reposo y acelera a a = 40 m/s², cruzando la barrera del sonido.',
        code: `// Movimiento Acelerado: cruce de subsónico a supersónico
const a = 40.0; // Aceleración en m/s²
const x0 = -300;

function posF(t) {
    return { x: x0 + 0.5 * a * t * t, y: 0 };
}

function velF(t) {
    return { x: a * t, y: 0 };
}

function posO(t) {
    return { x: 300, y: 0 };
}

function velO(t) {
    return { x: 0, y: 0 };
}
`
    },
    circular: {
        name: 'Órbita Circular 2D',
        desc: 'La fuente gira en una circunferencia de radio R = 150 m con velocidad constante.',
        code: `// Órbita circular 2D de la fuente
const R = 150;     // Radio en metros
const omega = 0.8; // Frecuencia angular rad/s

function posF(t) {
    return {
        x: R * Math.cos(omega * t),
        y: R * Math.sin(omega * t)
    };
}

function velF(t) {
    return {
        x: -R * omega * Math.sin(omega * t),
        y: R * omega * Math.cos(omega * t)
    };
}

function posO(t) {
    return { x: 320, y: 0 }; // Observador exterior
}

function velO(t) {
    return { x: 0, y: 0 };
}
`
    }
};

class DopplerCodeLab {
    constructor(containerElement, onApplyTrajectory) {
        this.container = containerElement;
        this.onApplyTrajectory = onApplyTrajectory;
        this.currentCode = CODELAB_PRESETS.harmonic.code;
    }

    render() {
        if (!this.container) return;

        this.container.innerHTML = `
            <div class="codelab-panel">
                <div class="codelab-toolbar">
                    <label for="preset-select"><strong>Plantillas de Trayectoria:</strong></label>
                    <select id="preset-select" class="form-select">
                        <option value="harmonic">Oscilador Armónico Simple (MAS)</option>
                        <option value="accelerated">Movimiento Acelerado (MRUA a Mach 1)</option>
                        <option value="circular">Órbita Circular 2D</option>
                    </select>
                    <button id="btn-run-code" class="btn btn-primary">
                        ▶ Ejecutar en la Simulación
                    </button>
                    <button id="btn-reset-code" class="btn btn-secondary">
                        ↺ Restaurar Código Estándar
                    </button>
                </div>

                <div class="codelab-editor-container">
                    <textarea id="code-editor" class="codelab-textarea" spellcheck="false">${this.currentCode}</textarea>
                </div>

                <div id="codelab-console" class="codelab-console">
                    <span class="console-prompt">info:</span> Listo para compilar. Define posF(t), velF(t), posO(t) y velO(t).
                </div>

                <div class="codelab-docs">
                    <h5>📖 Documentación de la API de Trayectorias:</h5>
                    <p>Debes definir cuatro funciones que reciban el tiempo <code>t</code> (en segundos) y retornen coordenadas <code>{ x, y }</code> en metros y velocidades en m/s:</p>
                    <ul>
                        <li><code>posF(t)</code>: Posición de la fuente <code>{ x: metros, y: metros }</code>.</li>
                        <li><code>velF(t)</code>: Velocidad vectorial de la fuente <code>{ x: m/s, y: m/s }</code>.</li>
                        <li><code>posO(t)</code>: Posición del observador <code>{ x: metros, y: metros }</code>.</li>
                        <li><code>velO(t)</code>: Velocidad vectorial del observador <code>{ x: m/s, y: m/s }</code>.</li>
                    </ul>
                </div>
            </div>
        `;

        this.bindEvents();
    }

    bindEvents() {
        const select = this.container.querySelector('#preset-select');
        const textarea = this.container.querySelector('#code-editor');
        const runBtn = this.container.querySelector('#btn-run-code');
        const resetBtn = this.container.querySelector('#btn-reset-code');
        const consoleEl = this.container.querySelector('#codelab-console');

        select.addEventListener('change', (e) => {
            const key = e.target.value;
            if (CODELAB_PRESETS[key]) {
                textarea.value = CODELAB_PRESETS[key].code;
                this.currentCode = textarea.value;
                this.log('Plantilla cargada: ' + CODELAB_PRESETS[key].name, 'info');
            }
        });

        runBtn.addEventListener('click', () => {
            const code = textarea.value;
            this.currentCode = code;
            this.executeUserCode(code);
        });

        resetBtn.addEventListener('click', () => {
            if (typeof this.onApplyTrajectory === 'function') {
                this.onApplyTrajectory(null); // Restaurar MRU estándar
            }
            this.log('Trayectoria personalizada desactivada. Se restauró el modelo MRU estándar.', 'info');
        });
    }

    log(message, type = 'info') {
        const consoleEl = this.container.querySelector('#codelab-console');
        if (consoleEl) {
            consoleEl.className = 'codelab-console console-' + type;
            consoleEl.innerHTML = `<span class="console-prompt">${type}:</span> ${message}`;
        }
    }

    /**
     * Valida y evalúa el código del usuario de manera segura en un ámbito cerrado.
     */
    executeUserCode(userCode) {
        try {
            // Empaquetar código en una función constructora aislada
            const wrappedCode = `
                "use strict";
                ${userCode}
                return {
                    posF: typeof posF === 'function' ? posF : null,
                    velF: typeof velF === 'function' ? velF : null,
                    posO: typeof posO === 'function' ? posO : null,
                    velO: typeof velO === 'function' ? velO : null
                };
            `;

            const builder = new Function(wrappedCode);
            const trajectoryObj = builder();

            if (!trajectoryObj.posF || !trajectoryObj.velF || !trajectoryObj.posO || !trajectoryObj.velO) {
                throw new Error('Falta definir una o más funciones requeridas: posF(t), velF(t), posO(t), velO(t).');
            }

            // Probar las funciones en t = 0 y t = 1 para verificar retorno numérico válido
            for (const testT of [0.0, 1.0, 2.5]) {
                const pf = trajectoryObj.posF(testT);
                const vf = trajectoryObj.velF(testT);
                const po = trajectoryObj.posO(testT);
                const vo = trajectoryObj.velO(testT);

                if (!pf || typeof pf.x !== 'number' || typeof pf.y !== 'number' || isNaN(pf.x) || isNaN(pf.y)) {
                    throw new Error(`posF(${testT}) no retornó coordenadas numéricas válidas {x, y}.`);
                }
                if (!vf || typeof vf.x !== 'number' || typeof vf.y !== 'number' || isNaN(vf.x) || isNaN(vf.y)) {
                    throw new Error(`velF(${testT}) no retornó componentes de velocidad válidas {x, y}.`);
                }
                if (!po || typeof po.x !== 'number' || typeof po.y !== 'number' || isNaN(po.x) || isNaN(po.y)) {
                    throw new Error(`posO(${testT}) no retornó coordenadas numéricas válidas {x, y}.`);
                }
                if (!vo || typeof vo.x !== 'number' || typeof vo.y !== 'number' || isNaN(vo.x) || isNaN(vo.y)) {
                    throw new Error(`velO(${testT}) no retornó componentes de velocidad válidas {x, y}.`);
                }
            }

            // Si pasa las pruebas, aplicar al motor físico
            if (typeof this.onApplyTrajectory === 'function') {
                this.onApplyTrajectory(trajectoryObj);
            }

            this.log('✓ Trayectoria compilada y aplicada exitosamente a la simulación.', 'success');

        } catch (err) {
            this.log('Error de compilación o ejecución: ' + err.message, 'error');
        }
    }
}

if (typeof window !== 'undefined') {
    window.DopplerCodeLab = DopplerCodeLab;
}

