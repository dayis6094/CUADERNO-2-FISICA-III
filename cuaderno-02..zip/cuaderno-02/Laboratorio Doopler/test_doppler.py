#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_doppler.py
Suite de verificación científica independiente para el Efecto Doppler Acústico.
Verifica:
1. Valores teóricos colineales obligatorios (c=340 m/s, f=1000 Hz, v=34 m/s).
2. Modelo vectorial bidimensional 2D general con vector unitario de retardo n.
3. Tiempo de vuelo causal exacto (|x_o(t_r) - x_c| = c*(t_r - t_e)).
4. Geometría del cono de Mach (semiángulo mu = arcsin(1/M) para M=2 -> 30°).
5. Medición empírica por llegadas sucesivas f_medida = 1 / (t_{r,n+1} - t_{r,n}).
6. Determinismo temporal e independencia del framerate.
"""

import math
import sys
import unittest


class DopplerPhysicsEngine:
    """Implementación de referencia en Python del modelo físico acústico."""

    @staticmethod
    def theoretical_frequency_collinear(f_e, c, v_f, v_o, approaching_source=True, approaching_obs=True):
        """
        Fórmula escolar colineal:
        f_o = f_e * (c +- v_o) / (c -+ v_f)
        v_f, v_o como magnitudes positivas con banderas de dirección.
        """
        num = c + v_o if approaching_obs else c - v_o
        den = c - v_f if approaching_source else c + v_f
        if abs(den) < 1e-12:
            return float('inf')
        return f_e * (num / den)

    @staticmethod
    def theoretical_frequency_vectorial(f_e, c, x_f_e, v_f_e, x_o_r, v_o_r):
        """
        Fórmula Doppler vectorial general:
        f_o = f_e * (c - n · v_o) / (c - n · v_f)
        donde n = (x_o(t_r) - x_f(t_e)) / |x_o(t_r) - x_f(t_e)|
        """
        # x_f_e = (xf, yf), x_o_r = (xo, yo)
        dx = x_o_r[0] - x_f_e[0]
        dy = x_o_r[1] - x_f_e[1]
        dist = math.hypot(dx, dy)
        if dist < 1e-12:
            raise ValueError("Distancia nula entre fuente y observador en eventos retardados.")
        
        nx = dx / dist
        ny = dy / dist

        n_dot_vf = nx * v_f_e[0] + ny * v_f_e[1]
        n_dot_vo = nx * v_o_r[0] + ny * v_o_r[1]

        den = c - n_dot_vf
        num = c - n_dot_vo

        if abs(den) < 1e-9:
            return float('inf')
        return f_e * (num / den)

    @staticmethod
    def calculate_reception_time_mru(x_c, t_e, x_o_0, v_o, c):
        """
        Resuelve exactamente: |x_o(0) + v_o * t_r - x_c| = c * (t_r - t_e) con t_r >= t_e.
        Ecuación cuadrática: (|v_o|^2 - c^2) t_r^2 + 2 (d0 · v_o + c^2 t_e) t_r + (|d0|^2 - c^2 t_e^2) = 0
        donde d0 = x_o(0) - x_c.
        """
        d0_x = x_o_0[0] - x_c[0]
        d0_y = x_o_0[1] - x_c[1]
        d0_sq = d0_x**2 + d0_y**2
        vo_sq = v_o[0]**2 + v_o[1]**2
        d0_dot_vo = d0_x * v_o[0] + d0_y * v_o[1]

        A = vo_sq - c**2
        B = 2.0 * (d0_dot_vo + (c**2) * t_e)
        C = d0_sq - (c**2) * (t_e**2)

        if abs(A) < 1e-9:
            # Caso vo = c (degenerado lineal)
            if abs(B) < 1e-9:
                return None
            t_r = -C / B
            return t_r if t_r >= t_e - 1e-9 else None

        disc = B**2 - 4.0 * A * C
        if disc < -1e-9:
            return None  # No hay intersección física
        disc = max(0.0, disc)
        sqrt_disc = math.sqrt(disc)

        # Dos raíces
        t1 = (-B - sqrt_disc) / (2.0 * A)
        t2 = (-B + sqrt_disc) / (2.0 * A)

        # Seleccionar la raíz causal válida más temprana t_r >= t_e
        valid = []
        for t_cand in (t1, t2):
            if t_cand >= t_e - 1e-9:
                # Verificar condición de propagación hacia adelante
                pos_x = x_o_0[0] + v_o[0] * t_cand
                pos_y = x_o_0[1] + v_o[1] * t_cand
                dist = math.hypot(pos_x - x_c[0], pos_y - x_c[1])
                dt = t_cand - t_e
                if abs(dist - c * dt) < 1e-6:
                    valid.append(t_cand)

        if not valid:
            return None
        return min(valid)

    @staticmethod
    def mach_half_angle_deg(M):
        """Semiángulo del cono de Mach: mu = arcsin(1/M) en grados para M >= 1."""
        if M < 1.0:
            return None
        return math.degrees(math.asin(1.0 / M))


class TestDopplerPhysics(unittest.TestCase):
    """Casos de prueba obligatorios según la especificación."""

    def setUp(self):
        self.c = 340.0       # m/s
        self.f_e = 1000.0    # Hz
        self.delta_v = 34.0  # m/s

    def test_case_1_both_at_rest(self):
        """Caso 1: Ambos inmóviles -> 1000 Hz."""
        fo = DopplerPhysicsEngine.theoretical_frequency_collinear(
            self.f_e, self.c, v_f=0.0, v_o=0.0
        )
        self.assertAlmostEqual(fo, 1000.0, places=6)

    def test_case_2_source_approaching(self):
        """Caso 2: Fuente que se aproxima a 34 m/s -> 1111.111111... Hz."""
        fo = DopplerPhysicsEngine.theoretical_frequency_collinear(
            self.f_e, self.c, v_f=self.delta_v, v_o=0.0,
            approaching_source=True, approaching_obs=True
        )
        expected = 1000.0 * (340.0 / 306.0)  # 10000 / 9 = 1111.111111...
        self.assertAlmostEqual(fo, expected, places=6)
        self.assertAlmostEqual(fo, 1111.1111111, places=5)

    def test_case_3_source_receding(self):
        """Caso 3: Fuente que se aleja a 34 m/s -> 909.090909... Hz."""
        fo = DopplerPhysicsEngine.theoretical_frequency_collinear(
            self.f_e, self.c, v_f=self.delta_v, v_o=0.0,
            approaching_source=False, approaching_obs=True
        )
        expected = 1000.0 * (340.0 / 374.0)  # 10000 / 11 = 909.090909...
        self.assertAlmostEqual(fo, expected, places=6)
        self.assertAlmostEqual(fo, 909.0909091, places=5)

    def test_case_4_observer_approaching(self):
        """Caso 4: Observador que se aproxima a fuente inmóvil a 34 m/s -> 1100 Hz."""
        fo = DopplerPhysicsEngine.theoretical_frequency_collinear(
            self.f_e, self.c, v_f=0.0, v_o=self.delta_v,
            approaching_source=True, approaching_obs=True
        )
        expected = 1000.0 * ((340.0 + 34.0) / 340.0)  # 1100.0
        self.assertAlmostEqual(fo, expected, places=6)
        self.assertAlmostEqual(fo, 1100.0, places=6)

    def test_case_5_observer_receding(self):
        """Caso 5: Observador que se aleja a fuente inmóvil a 34 m/s -> 900 Hz."""
        fo = DopplerPhysicsEngine.theoretical_frequency_collinear(
            self.f_e, self.c, v_f=0.0, v_o=self.delta_v,
            approaching_source=True, approaching_obs=False
        )
        expected = 1000.0 * ((340.0 - 34.0) / 340.0)  # 900.0
        self.assertAlmostEqual(fo, expected, places=6)
        self.assertAlmostEqual(fo, 900.0, places=6)

    def test_case_6_both_moving_same_velocity(self):
        """Caso 6: Ambos con igual velocidad constante y separación fija en subsónico -> 1000 Hz."""
        # Fuente persigue a observador o ambos viajan en la misma dirección
        # Fuente se aproxima a observador a 34 m/s, observador se aleja a 34 m/s:
        # fo = fe * (c - 34) / (c - 34) = fe
        fo = DopplerPhysicsEngine.theoretical_frequency_collinear(
            self.f_e, self.c, v_f=self.delta_v, v_o=self.delta_v,
            approaching_source=True, approaching_obs=False
        )
        self.assertAlmostEqual(fo, 1000.0, places=6)

    def test_time_of_flight_exact(self):
        """Verifica: Una emisión a 340 m de un observador fijo llega después de 1 s."""
        x_c = (0.0, 0.0)
        t_e = 0.0
        x_o_0 = (340.0, 0.0)
        v_o = (0.0, 0.0)
        t_r = DopplerPhysicsEngine.calculate_reception_time_mru(x_c, t_e, x_o_0, v_o, self.c)
        self.assertIsNotNone(t_r)
        self.assertAlmostEqual(t_r, 1.0, places=9)

    def test_mach_2_half_angle(self):
        """Verifica: Para Mach 2, el semiángulo de Mach es 30°."""
        mu = DopplerPhysicsEngine.mach_half_angle_deg(2.0)
        self.assertAlmostEqual(mu, 30.0, places=6)

    def test_vectorial_matches_collinear(self):
        """Verifica que el modelo 2D vectorial reproduzca los casos 1D exactamente."""
        # Fuente en x=0 moviéndose hacia +x con vf=34, obs en x=500 fijo
        # Vector retardado apunta de (0,0) a (500,0) -> n = (1, 0)
        f_vec = DopplerPhysicsEngine.theoretical_frequency_vectorial(
            f_e=self.f_e, c=self.c,
            x_f_e=(0.0, 0.0), v_f_e=(34.0, 0.0),
            x_o_r=(500.0, 0.0), v_o_r=(0.0, 0.0)
        )
        self.assertAlmostEqual(f_vec, 10000.0 / 9.0, places=6)

    def test_successive_arrival_independent_measurement(self):
        """
        Verifica que la medición empírica independiente f_medida = 1 / (t_{r,n+1} - t_{r,n})
        coincida exactamente con la predicción teórica para fuente que se aproxima.
        """
        v_f = 34.0
        x_f_0 = 0.0
        x_o = 1000.0
        t_e_0 = 0.0
        t_e_1 = 1.0 / self.f_e  # 0.001 s

        # Posiciones de emisión:
        x_c_0 = (x_f_0 + v_f * t_e_0, 0.0)
        x_c_1 = (x_f_0 + v_f * t_e_1, 0.0)

        t_r_0 = DopplerPhysicsEngine.calculate_reception_time_mru(x_c_0, t_e_0, (x_o, 0.0), (0.0, 0.0), self.c)
        t_r_1 = DopplerPhysicsEngine.calculate_reception_time_mru(x_c_1, t_e_1, (x_o, 0.0), (0.0, 0.0), self.c)

        delta_t_r = t_r_1 - t_r_0
        f_measured = 1.0 / delta_t_r
        f_expected = 1000.0 * (340.0 / (340.0 - 34.0))

        self.assertAlmostEqual(f_measured, f_expected, places=6)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestDopplerPhysics)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)

