# Manual de Usuario y Fundamentos Didácticos
## Simulador Avanzado del Efecto Doppler Acústico
**Asignatura:** Física III — Ondas y Acústica  
**Idioma y Configuración Regional:** Español (`es-CO`)  
**Compatibilidad:** Computador de escritorio, computadores portátiles, tabletas y teléfonos celulares.

---

### 1. Resumen Ejecutivo y Declaración de Referencia

Este simulador es una herramienta educativa y científica de alta precisión diseñada para explorar y comprender el **Efecto Doppler Acústico** en un medio homogéneo e inmóvil.

> **Aviso de transparencia sobre el archivo de referencia:**  
> De acuerdo con la instrucción explícita del punto 1 de la especificación: el archivo `EfectoDoppler.html` no se encontraba presente en el espacio de trabajo local al momento del desarrollo. Por tanto, esta aplicación fue implementada desde cero siguiendo rigurosamente todas las directrices matemáticas, físicas, pedagógicas y de diseño establecidas en la especificación, sin trasladar errores de versiones previas.

---

### 2. Cómo Abrir y Ejecutar la Aplicación

La aplicación es **100% estática, autónoma y no requiere servidores backend ni instalación de paquetes adicionales**.

#### Método 1: Apertura directa en el navegador
1. Haz doble clic en el archivo `index.html` (o clic derecho > *Abrir con* > Google Chrome, Microsoft Edge, Mozilla Firefox o Safari).
2. La aplicación cargará inmediatamente en pantalla completa con el experimento inicial preparado.

#### Método 2: Servidor local (opcional)
Si deseas ejecutarlo mediante un servidor web local:
```bash
# Con Python 3:
python -m http.server 8000

# Luego abre en tu navegador:
http://localhost:8000
```

---

### 3. Modelo Físico y Ecuaciones

El modelo se fundamenta en la acústica clásica en un fluido homogéneo e isótropo en reposo respecto al sistema de coordenadas del laboratorio.

#### 3.1. Emisión y Geometría de Frentes de Onda
- **Frecuencia emitida:** $f_e$ (en Hz), con período $T = 1 / f_e$.
- **Instantes de emisión:** Para $n = 0, 1, 2, \dots$:
  $$t_{e,n} = \frac{n}{f_e}$$
- **Centro del frente de onda:** El sonido se transmite a través del medio circundante. Una vez emitido, el centro del frente permanece **completamente fijo en el medio**:
  $$\mathbf{x}_{c,n} = \mathbf{x}_f(t_{e,n})$$
  *(El frente no se arrastra con la fuente).*
- **Radio de propagación:** Para cualquier instante posterior $t \ge t_{e,n}$:
  $$r_n(t) = c \, (t - t_{e,n})$$

#### 3.2. Detección Analítica de Recepción
Un frente de onda $n$ alcanza al observador en el instante $t_{r,n}$ cuando la distancia euclidiana entre el observador y el centro de emisión coincide con el radio expandido de la onda:
$$\left| \mathbf{x}_o(t_{r,n}) - \mathbf{x}_{c,n} \right| = c \, (t_{r,n} - t_{e,n}) \qquad (t_{r,n} \ge t_{e,n})$$

Para movimiento rectilíneo uniforme (MRU), esta condición se resuelve **analíticamente** mediante la raíz de la ecuación cuadrática:
$$(|\mathbf{v}_o|^2 - c^2) t_r^2 + 2 \left( (\mathbf{x}_{o0} - \mathbf{x}_{c,n}) \cdot \mathbf{v}_o + c^2 t_e \right) t_r + \left( |\mathbf{x}_{o0} - \mathbf{x}_{c,n}|^2 - c^2 t_e^2 \right) = 0$$
Esto garantiza que las llegadas no se pierdan ante cambios de zoom, fluctuaciones de cuadros por segundo o altas velocidades.

#### 3.3. Frecuencia Observada Teórica y Medida Empírica
- **Frecuencia teórica Doppler vectorial general:**
  $$f_o = f_e \, \frac{c - \mathbf{n} \cdot \mathbf{v}_o(t_r)}{c - \mathbf{n} \cdot \mathbf{v}_f(t_e)}$$
  donde $\mathbf{n}$ es el vector unitario retardado:
  $$\mathbf{n} = \frac{\mathbf{x}_o(t_r) - \mathbf{x}_f(t_e)}{\left| \mathbf{x}_o(t_r) - \mathbf{x}_f(t_e) \right|}$$
- **Fórmulas escolares colineales (eje $x$):**
  - Fuente que se acerca a observador fijo: $f_o = f_e \frac{c}{c - v_f}$
  - Fuente que se aleja de observador fijo: $f_o = f_e \frac{c}{c + v_f}$
  - Observador que se acerca a fuente fija: $f_o = f_e \frac{c + v_o}{c}$
  - Observador que se aleja de fuente fija: $f_o = f_e \frac{c - v_o}{c}$
- **Medición empírica independiente:**
  Calculada a partir de los instantes de cruce sucesivos de las ondas por el observador:
  $$f_{\text{medida}} = \frac{1}{t_{r,n+1} - t_{r,n}}$$
  Antes de registrar dos llegadas consecutivas, el sistema muestra «Esperando 2 llegadas».

#### 3.4. Longitudes de Onda Espaciales en el Medio
- Longitud de onda en reposo: $\lambda_0 = \frac{c}{f_e}$
- Delante de la fuente (en avance hacia $+x$): $\lambda_{\text{delante}} = \frac{c - v_f}{f_e}$
- Detrás de la fuente: $\lambda_{\text{detrás}} = \frac{c + v_f}{f_e}$

#### 3.5. Régimen Sónico y Cono de Mach
- **Número de Mach:** $M = \frac{|\mathbf{v}_f|}{c}$
- **Semiángulo del cono de Mach ($M > 1$):**
  $$\mu = \arcsin\left(\frac{1}{M}\right)$$
  Para $M = 2$, $\mu = \arcsin(0.5) = 30^\circ$.
- **Sonificación del estampido:** Se produce **únicamente cuando el frente de la envolvente cónica cruza físicamente la posición del observador**, no por el simple hecho de que la fuente supere Mach 1.

---

### 4. Guía de Interfaz y Uso Didáctico

#### 4.1. Modos de Navegación
- **Modo Exploración:** Interfaz despejada enfocada en los conceptos clave: manipulación directa, observación de ondas, botones grandes y explicaciones claras.
- **Modo Laboratorio:** Despliega todas las herramientas analíticas: vectores de velocidad, diagramas espacio-temporales, fórmulas paso a paso, herramienta de regla métrica interactiva y exportación de datos a CSV.

#### 4.2. Atajos de Teclado
| Tecla | Función |
| :--- | :--- |
| **Espacio** | Reproducir / Pausar la simulación |
| **R** | Reiniciar al tiempo $t = 0$ |
| **Flecha Derecha (→)** | Avanzar un paso temporal ($\Delta t = \frac{1}{100 f}$) |
| **Flecha Izquierda (←)** | Retroceder un paso temporal ($-\Delta t$) |
| **Shift + Flecha Derecha** | Avanzar un período completo ($+T$) |
| **Shift + Flecha Izquierda** | Retroceder un período completo ($-T$) |
| **M** | Silenciar / Desilenciar audio |
| **H** | Restaurar vista original de cámara |
| **F** | Ajustar cámara a la escena activa (Fit) |

#### 4.3. Herramientas Interactivas en el Canvas
- **Rueda del ratón:** Zoom continuo centrado en el cursor.
- **Arrastre con clic derecho / clic central:** Desplazamiento panorámico (Pan).
- **Arrastre de la Fuente u Observador:** En estado de pausa, puedes arrastrar con el cursor directamente la fuente o el micrófono para reubicar sus posiciones iniciales.
- **Regla Métrica (📏):** Activa el botón de regla en la barra flotante. Haz clic en el punto A y luego en el punto B para medir distancias exactas en metros.
- **Inspección de Frentes de Onda:** Pasa el cursor sobre cualquier frente para ver su identificador $n$, instante de emisión $t_e$, centro de coordenadas $\mathbf{x}_c$, radio actual y tiempo previsto de llegada.

#### 4.4. Audio y Sonificación (Web Audio API)
Por razones de seguridad y diseño de los navegadores web modernos, el audio requiere una pulsación voluntaria del botón **«Activar Audio»**.
- **Modo Pulsos de Llegada:** Genera un chasquido suave (envolvente exponencial sin artefactos de clic) en el momento exacto en que cada cresta alcanza al observador.
- **Modo Comparación Tonal:** Genera un tono sintetizado continuo escalado con una transposición didáctica visible ($f_{\text{audio}} = f \times 220$), permitiendo escuchar claramente el deslizamiento Doppler acústico.
- **Pausa y retroceso:** Silencian y cancelan instantáneamente cualquier sonido en curso.

---

### 5. Los 8 Escenarios Didácticos Guiados

La pestaña **«Aprendizaje»** incorpora 8 escenarios preconfigurados:
1. **Fuente y observador en reposo:** Base de comparación ($f_o = f_e = 2\text{ Hz}$, $\lambda = 170\text{ m}$).
2. **Fuente que se aproxima:** Compresión de frentes hacia adelante ($\lambda_{\text{delante}} = 85\text{ m}$, $f_o = 4\text{ Hz}$).
3. **Fuente que se aleja:** Dilatación de frentes ($\lambda_{\text{detrás}} = 255\text{ m}$, $f_o = 1.33\text{ Hz}$).
4. **Observador que se aproxima a fuente en reposo:** Frentes en el aire intactos ($\lambda = 170\text{ m}$), pero intercepción a mayor rapidez relativa ($f_o = 3\text{ Hz}$). Demuestra la asimetría clásica con el Escenario 2.
5. **Observador que se aleja:** Menor tasa de intercepción ($f_o = 1\text{ Hz}$).
6. **Ambos en movimiento con igual velocidad y separación constante:** Compensación cinemática exacta ($f_o = 2\text{ Hz}$).
7. **Paso lateral 2D (observador fuera del eje):** Variación continua del tono (sonido de sirena al pasar la esquina).
8. **Régimen sónico y supersónico ($M=1$ y $M=1.5$):** Cono de Mach, zona de silencio previa y estampido al cruce.

---

### 6. Laboratorio de Código (Codelab)

En el Modo Laboratorio, la pestaña **«Codelab»** permite ingresar código JavaScript para crear trayectorias personalizadas:
- **MAS:** Movimiento armónico simple de la fuente.
- **MRUA:** Aceleración uniforme cruzando la barrera del sonido.
- **Circular 2D:** Órbita circular de la fuente.

El código se ejecuta en un sandbox que evalúa previamente el retorno en $t=0, 1, 2.5\text{ s}$ para garantizar que no existan valores nulos, infinitos o errores que comprometan la aplicación.

---

### 7. Verificación Científica Automatizada

El proyecto incluye dos niveles de verificación científica:

#### 7.1. Verificador en la Interfaz Web (Pestaña «Pruebas»)
Ejecuta 10 pruebas unitarias con tolerancias numéricas de $10^{-4}$ directamente en el motor JavaScript.

#### 7.2. Suite Científica Independiente en Python (`test_doppler.py`)
Para ejecutar las pruebas en terminal:
```bash
python test_doppler.py
```
**Resultados verificados:**
- $c = 340\text{ m/s}, f = 1000\text{ Hz}$:
  - Ambos en reposo $\implies 1000.0000\text{ Hz}$.
  - Fuente se aproxima a $34\text{ m/s} \implies 1111.1111\text{ Hz}$.
  - Fuente se aleja a $34\text{ m/s} \implies 909.0909\text{ Hz}$.
  - Observador se aproxima a $34\text{ m/s} \implies 1100.0000\text{ Hz}$.
  - Observador se aleja a $34\text{ m/s} \implies 900.0000\text{ Hz}$.
  - Ambos a $34\text{ m/s} \implies 1000.0000\text{ Hz}$.
- Tiempo de vuelo exacto: Emisión a $340\text{ m}$ con $c = 340\text{ m/s} \implies 1.000000\text{ s}$.
- Mach 2: $\mu = \arcsin(0.5) = 30.0000^\circ$.
- Medición empírica independiente por cruces: coincide analíticamente con error $< 0.001\%$.

---

### 8. Límites del Modelo Físico

1. **Medio estacionario:** Se asume un medio sin viento. Si existiera viento, $c$ se sumaría vectorialmente con la velocidad del viento.
2. **Propagación lineal clásica:** No aplica para velocidades comparables a la luz ($v \sim c_{\text{luz}}$), en cuyo caso debe emplearse la fórmula relativista con el factor de dilatación temporal de Lorentz $\gamma = 1/\sqrt{1 - v^2/c^2}$.
3. **Ondas de choque:** La simulación modela la geometría cinemática de los frentes de Mach. La presión real no lineal requeriría resolver las ecuaciones de Navier-Stokes con las condiciones de salto de Rankine-Hugoniot.

