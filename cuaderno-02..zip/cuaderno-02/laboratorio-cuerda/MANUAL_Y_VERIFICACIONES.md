# Física III · Laboratorio 07 — Simulación de la cuerda tensa

Versión estática, en español. Es parte del **Cuaderno 02: Movimiento Ondulatorio**.

## 1. Cómo abrir

1. Descomprime `Biblioteca_Fisica_III_Laboratorios.zip` conservando todas las carpetas.
2. Abre `CUADERNO/index.html` (biblioteca) en Chrome, Edge, Firefox o Safari moderno.
3. Selecciona **Movimiento Ondulatorio → Laboratorio 07: Simulación de la cuerda tensa → Abrir laboratorio de cuerda tensa**.
4. También puedes abrir directamente `CUADERNO/cuaderno-02/laboratorio-cuerda/index.html`.

El núcleo físico, gráficas y exportación son archivos locales HTML/CSS/JavaScript. No precisan Internet ni un servidor. No se necesita Python ni Node.js para usar el laboratorio. El navegador debe admitir Canvas, JavaScript y, para el sonido, Web Audio. El laboratorio Doppler y los contenidos previos se conservan.

## 2. Primer experimento

Aparece una cuerda de 1,2 m, tensión 80 N, densidad lineal 0,012 kg/m, desplazamiento inicial 8 mm, ambos extremos fijos y amortiguamiento γ = 0,12 s⁻¹. La rapidez teórica es **81,6497 m/s** y la frecuencia fundamental es **34,0207 Hz**.

- Pulsa **Reproducir**. La velocidad inicial de reproducción es **0,05×**, necesaria para visualizar una onda que cruza la cuerda en unos 0,0147 s físicos.
- Usa **+ 1/100 T** para avanzar en incrementos de 1/100 del período fundamental o **+ 1 T** para saltar un ciclo.
- Mueve la **sonda** con el deslizador o pulsando un punto sobre el gráfico de la cuerda. Esto cambia dónde se mide, pero no altera el fenómeno.
- Desliza la línea de tiempo para ir directamente a otro instante. El estado se calcula de nuevo; no se acumula un error temporal a partir de animaciones anteriores.
- Modifica tensión, densidad, longitud, amplitud, amortiguamiento, extremos y excitación. Pulsa **Aplicar cambios y reiniciar** para iniciar un nuevo experimento reproducible.
- Selecciona las pestañas **Osciloscopio**, **Energía** y **Espectro modal**.
- En **Prácticas**, selecciona un escenario, formula tu predicción, observa y responde la pregunta con retroalimentación.

## 3. Modelo físico: qué significan las mediciones

La cuerda es homogénea, flexible y tiene tensión uniforme. El desplazamiento transversal pequeño se aproxima mediante:

    μ y_tt + 2 μ γ y_t = Fₜ y_xx + F₀ sin(2π fₑ t) δ(x − x₀)

Aquí `μ` es masa por unidad de longitud (kg/m), `Fₜ` tensión (N), `γ` amortiguamiento (s⁻¹), `F₀` amplitud de fuerza (N, solo bajo excitación continua) y `x₀` posición de excitación (m). La rapidez de propagación **v = √(Fₜ/μ)** en m/s.

El motor desarrolla la solución como una **suma de 48 modos normales**; proyecta las formas iniciales mediante integración numérica y resuelve analíticamente la evolución temporal de cada modo con amortiguamiento y, cuando procede, excitación armónica. No usa pasos temporales discretos para evolucionar el estado. Por tanto, no sufre un problema de inestabilidad CFL ni confunde el tiempo simulado con la velocidad de reproducción. Sin embargo, la expansión finita suaviza los detalles bruscos de un pulso o un punteo.

Las fronteras se distinguen así:

| Frontera | Condición en extremos | Frecuencias naturales no nulas |
|---|---|---|
| Fijo–fijo | y(0,t)=y(L,t)=0 | fₙ = n·v/(2L), n≥1 |
| Fijo–libre | y(0,t)=0, yₓ(L,t)=0 | fₙ = (n−1/2)·v/(2L), n≥1 |
| Libre–fijo | yₓ(0,t)=0, y(L,t)=0 | fₙ = (n−1/2)·v/(2L), n≥1 |
| Libre–libre | yₓ(0,t)=yₓ(L,t)=0 | fₙ = n·v/(2L), n≥1; existe un modo rígido f=0 |

La energía modal mostrada equivale a la integral de energía mecánica para la solución truncada:

    E = ½ ∫₀ᴸ [ μ(y_t)² + Fₜ(y_x)² ] dx

En ausencia de fuerza externa y amortiguamiento, el modelo conserva la energía modal dentro de precisión numérica de máquina. La energía cinética y potencial **pueden intercambiarse** aunque su suma permanezca constante.

La **escala vertical es independiente** de la horizontal; es una representación ampliada de milímetros, no una foto a escala. La curva representa desplazamiento, no presión sonora. La **estela** muestra estados anteriores de la misma cuerda y no nuevas cuerdas físicas. La sonda indica un punto material fijo en x.

## 4. Diez actividades preparadas

| Práctica | Variable de interés | Resultado que debes comprobar |
|---|---|---|
| 01. Punteo triangular | Desplazamiento inicial | Nacen perturbaciones que viajan hacia ambos extremos |
| 02. Reflexión fija | Fijo–fijo | El pulso reflejado se invierte |
| 03. Reflexión libre | Fijo–libre | El pulso reflejado mantiene el signo |
| 04. Fundamental | Modo 1 | Dos nodos y un vientre en frontera fija–fija |
| 05. Tercer armónico | Modo 3 | Cuatro nodos, tres vientres, f₃=3f₁ |
| 06. Cuadruplicar la tensión | Fₜ: 40 → 160 N | v se duplica |
| 07. Mayor densidad | μ: 0,012 → 0,048 kg/m | v se reduce a la mitad |
| 08. Resonancia | Fuerza a f₁ | Transferencia eficaz de energía, limitada por el amortiguamiento |
| 09. Desafinación | Fuerza a 44 Hz | Menor respuesta que cerca de una resonancia comparable |
| 10. Amortiguamiento | γ: 2 vs. 0 | Energía decreciente frente a energía conservada |

**Sugerencia didáctica:** emplea primero 01–05 para visualizar propagación y nodos; luego 06–07 para confrontar las unidades y la fórmula de rapidez; finalmente 08–10 para resonancia y balance de energía.

## 5. Audio, CSV y PNG

El botón **Escuchar muestra** crea en el navegador un fragmento de 2,5 s **a partir del desplazamiento calculado en la sonda**. Se activa solo al pulsar, usa una envolvente suave de inicio/final, y se detiene con **■**. Si el fundamental está por debajo de 120 Hz, se aplica una escala temporal hasta 8× **indicada explícitamente** para que el sonido sea audible. Esta sonificación no resuelve radiación acústica, caja de resonancia ni características tímbricas instrumentales, ni es una reproducción en tiempo real de todo el experimento. Al reiniciar, pausar o buscar otro instante se cancela el audio activo.

- **Datos CSV:** genera de 1.001 a 20.001 muestras espaciadas uniformemente a lo largo de la duración, en formato separado por `;`, con unidades en el encabezado. Incluye tiempo, posición de la sonda, desplazamiento, velocidad transversal y energía cinética, potencial y total. Su densidad se adapta a la frecuencia fundamental, con un límite de tamaño de archivo: puede no resolver armónicos altos cuando se utiliza el máximo de modos o frecuencias muy elevadas.
- **Imagen PNG:** exporta captura de la escena, gráfica y parámetros utilizados.

## 6. Verificaciones realizadas

**JavaScript (`node js/test_physics.js`): 38 comprobaciones con resultado OK.**

- `Fₜ=80 N`, `μ=0,012 kg/m`, `L=1,2 m`: `v=81,649658... m/s`; `f₁=34,020690... Hz`.
- `f₃=3f₁` para fijo–fijo; n=3 tiene nodos en 0, 0,4, 0,8 y 1,2 m.
- Al pasar de 40 N a 160 N, v y f₁ se duplican. Al pasar de 0,012 a 0,048 kg/m, v se reduce a la mitad.
- Para fijo–libre, f₁=v/(4L). Para libre–libre hay modo de frecuencia cero.
- Conservación de energía modal sin amortiguamiento a varios instantes; pérdida de energía con γ>0; arranque del sistema forzado desde reposo.
- Verificación por señales de pulso de inversión de signo en extremo fijo y conservación de signo en extremo libre.
- Reconstrucción determinista del estado y valores finitos en las muestras verificadas.

**Python independiente (`python js/test_independiente.py`): resultado OK.** Se contrastó la solución con fórmulas derivadas aparte para rapidez, frecuencia, doce coeficientes de Fourier de un punteo triangular, energía elástica integral (con tolerancia del 1,5 % para truncamiento modal), y posición temporal del tercer armónico.

**Interfaz:** verificación automatizada en Chromium con tamaños 1600×960, 900×1100 y 390×844. Sin errores JavaScript detectados ni desbordamiento horizontal. Se ejercitaron inicio/pausa, diez escenarios en el selector, aplicar/reiniciar, navegación temporal, cambios de sonda, tres gráficas, exportaciones CSV y PNG, modo oscuro y Web Audio mediante interacción del usuario. El enlace del nuevo laboratorio figura en el capítulo 19/26 del Cuaderno 02. Las verificaciones del sonido se limitaron a su inicialización y control en navegador automatizado, no a pruebas perceptuales con altavoces reales.

## 7. Funciones no implementadas y límites

No es un modelo completo de una cuerda real con rigidez, disipación dependiente de la frecuencia, tensiones no uniformes, no linealidad, modos tridimensionales, acoplamiento con el aire o acústica de instrumentos. No incorpora adquisición por micrófono real, osciloscopio físico, mediciones de esfuerzo o simulación de una cuerda no homogénea. El gráfico de energía y el espectro modal describen **la solución matemática truncada**. Las curvas afiladas pueden mostrar oscilaciones de aproximación por truncamiento; las grandes amplitudes pueden violar las hipótesis de pendientes pequeñas (la interfaz emite una advertencia).

Las pruebas de navegador no sustituyen una evaluación manual de accesibilidad y audio en todos los modelos de teléfono y tableta. No se incluye editor de código ni integración con dispositivos de laboratorio, pues no son necesarios para los experimentos principales.
