'use strict';
const assert=require('node:assert/strict'),P=require('./physics.js');let tests=0;
function close(a,b,rtol=1e-7,atol=1e-9){assert.ok(Math.abs(a-b)<=atol+rtol*Math.abs(b),`Se esperaba ${b}, se obtuvo ${a}`);tests++;}
let p=P.createModel({tension:80,mu:.012,length:1.2,damping:0});
close(p.speed,Math.sqrt(80/.012));close(p.frequency1,Math.sqrt(80/.012)/2.4);
close(p.modes[2].frequency,3*p.frequency1);close(p.snapshot(0).ys[0],0,1e-6,1e-5);
for(const t of [0.01,.1,1,4,15])close(p.snapshot(t).energy.total,p.snapshot(0).energy.total,1e-10);
let p4=P.createModel({tension:4*40,mu:.012,length:1.2,damping:0});const p40=P.createModel({tension:40,mu:.012,length:1.2});close(p4.speed,2*p40.speed);close(p4.frequency1,2*p40.frequency1);
let ph=P.createModel({tension:80,mu:.048,length:1.2});close(ph.speed,p.speed/2);
const harmonic=P.createModel({excitation:'harmonic',harmonic:3,damping:0});for(const x of [0,.4,.8,1.2])close(harmonic.sample(.012,x).y,0,1e-4,1e-9);
close(harmonic.modes[2].q0,.008);close(harmonic.modes[1].q0,0);
const fixedFree=P.createModel({boundary:'fixed-free',damping:0});close(fixedFree.frequency1,Math.sqrt(80/.012)/(4*1.2));close(fixedFree.snapshot(0).ys[0],0,1e-4,2e-5);
const freeFixed=P.createModel({boundary:'free-fixed',damping:0});close(freeFixed.frequency1,fixedFree.frequency1);
close(freeFixed.snapshot(0).ys.at(-1),0,1e-4,2e-5);
const freeFree=P.createModel({boundary:'free-free',damping:0});close(freeFree.frequency1,Math.sqrt(80/.012)/(2*1.2));close(freeFree.modes[0].frequency,0);
const damped=P.createModel({damping:2,excitation:'pluck'});assert.ok(damped.snapshot(1).energy.total<damped.snapshot(0).energy.total);tests++;
// Driven harmonic modes do not have artificial energy at t=0.
const driven=P.createModel({excitation:'drive',driveFreq:34.02069087199,damping:.7,position:.5});close(driven.snapshot(0).energy.total,0,1e-6,1e-9);
const t0=driven.sample(.451,.35).y,t1=driven.sample(.451,.35).y;close(t0,t1,1e-14);
for(const t of [0,0.01,.3,1,4,10]){let z=driven.snapshot(t);assert.ok(Number.isFinite(z.energy.total));assert.ok(z.ys.every(Number.isFinite));tests++;}
// Evaluate exactly at arbitrary frame times / backward seeking.
close(p.snapshot(.451).probe.y,p.snapshot(.451).probe.y,1e-13);close(p.snapshot(2.31).probe.y,p.sampleAtProbe(2.31).y,1e-13);
// Check a right-moving gaussian pulse and its two possible reflected signs.
const c0=Math.sqrt(80/.012),L=1.2,p0=.28,atIn=(.7-p0)*L/c0,atOut=((1-p0)+(1-.7))*L/c0;
const px=P.createModel({excitation:'pulse',position:p0,boundary:'fixed-fixed',damping:0,modeCount:96});
const pf=P.createModel({excitation:'pulse',position:p0,boundary:'fixed-free',damping:0,modeCount:96});
assert.ok(px.sample(atIn,.7*L).y>0.001,'El pulso incidente debe ser positivo');tests++;
assert.ok(px.sample(atOut,.7*L).y < -0.0008,'Reflexión fija invierte signo');tests++;
assert.ok(pf.sample(atOut,.7*L).y > 0.0008,'Reflexión libre conserva signo');tests++;
console.log(`OK · ${tests} verificaciones científicas y numéricas`);
