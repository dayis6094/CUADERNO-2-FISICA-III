"""Verificación independiente en Python del motor modal JavaScript.
Sin importar el motor, obtiene series analíticas desde ecuaciones de la cuerda.
Ejecutar: python js/test_independiente.py (requiere Node.js y Python 3).
"""
import json, math, subprocess, pathlib
root=pathlib.Path(__file__).parent
script=r'''
const P=require('./physics.js');
const a=P.createModel({length:1.2,tension:80,mu:.012,damping:0,excitation:'pluck',position:.35,amplitude:.008});
const h=P.createModel({length:1.2,tension:80,mu:.012,damping:0,excitation:'harmonic',harmonic:3,amplitude:.009});
console.log(JSON.stringify({speed:a.speed, f1:a.frequency1, pluck:a.modes.slice(0,12).map(x=>x.q0),
    E:a.snapshot(0).energy.total, sampled:h.sample(.111,.5).y,
    mode3:h.modes[2].frequency}));
'''
data=json.loads(subprocess.check_output(['node','-e',script],cwd=root,text=True))
L=1.2;T=80;mu=.012;A=.008;p=.35
expected_speed=math.sqrt(T/mu)
assert math.isclose(data['speed'],expected_speed,rel_tol=1e-12)
assert math.isclose(data['f1'],expected_speed/(2*L),rel_tol=1e-12)
expected_coeff=[(2*A/(math.pi*n)**2/p/(1-p))*math.sin(math.pi*n*p) for n in range(1,13)]
for n,(observed,expected) in enumerate(zip(data['pluck'],expected_coeff),start=1):
    assert math.isclose(observed,expected,rel_tol=0.0003,abs_tol=2e-9),(n,observed,expected)
expected_energy=T*A*A/(2*L*p*(1-p))
assert abs(data['E']-expected_energy)/expected_energy < .015, (data['E'],expected_energy)
expected_y=.009*math.sin(3*math.pi*.5/L)*math.cos(3*math.pi*expected_speed*.111/L)
assert math.isclose(data['sampled'],expected_y,rel_tol=1e-10,abs_tol=1e-12)
assert math.isclose(data['mode3'],3*data['f1'],rel_tol=1e-12)
print('OK · Python independiente: rapidez, frecuencia, 12 coeficientes Fourier, energía integral, modo 3 y vibración temporal')
