/* Laboratorio de cuerda tensa · interfaz/visualización. Renderizar NO modifica el modelo. */
(()=>{'use strict';
const P=window.StringLabPhysics;if(!P){document.body.textContent='No se pudo cargar el motor de simulación.';return;}
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],fmt=(n,d=2)=>Number.isFinite(n)?Number(n).toLocaleString('es-CO',{minimumFractionDigits:d,maximumFractionDigits:d}):'—';
const num=(n,d=2)=>fmt(n,d);
const scenarios={
 plucked:{title:'Dos ondas nacen de un punteo',objective:'Identificar cómo una deformación inicial se reparte en componentes que viajan hacia los dos extremos.',question:'¿El material avanza con la onda o oscila alrededor del equilibrio?',steps:'Pulsa «Reproducir». Sigue un punto marcado por la sonda y luego pausa antes y después de una reflexión.',answer:'Los puntos de la cuerda se desplazan transversalmente; lo que viaja por la cuerda es la perturbación y la energía. La rapidez de propagación depende de Fₜ y μ, no del tamaño de A.',quiz:'¿Qué ocurre si solo duplicas la amplitud del punteo en el modelo lineal?',options:['La rapidez se duplica','La rapidez no cambia','La masa lineal se duplica'],correct:1,why:'La rapidez v = √(Fₜ/μ) no depende de A en la aproximación lineal.',config:{excitation:'pluck',boundary:'fixed-fixed',tension:80,mu:.012,damping:.12,position:.35,amplitude:.008,duration:6}},
 'reflection-fixed':{title:'Eco invertido: extremo fijo',objective:'Verificar que en una frontera fija la reflexión cambia el signo del desplazamiento.',question:'¿El pulso que regresa tiene el mismo signo que el que llegó?',steps:'Observa el pulso que sale del 28 % hacia el extremo derecho; pausa cerca del retorno. Puedes usar «+1/100 T» para ver instantes próximos.',answer:'En el extremo fijo y=0. La combinación de onda incidente y reflejada obliga a una inversión de fase de π: un pulso positivo regresa negativo.',quiz:'En una reflexión en extremo fijo, el pulso reflejado…',options:['Se invierte de signo','Conserva el mismo signo','Duplica la rapidez'],correct:0,why:'El extremo fijo es un nodo; se refleja con cambio de signo.',config:{excitation:'pulse',boundary:'fixed-fixed',position:.28,amplitude:.012,damping:0,duration:1.5}},
 'reflection-free':{title:'Eco no invertido: extremo libre',objective:'Distinguir la condición de pendiente cero del extremo libre y su efecto en la onda reflejada.',question:'¿Un pulso positivo regresa positivo desde un extremo libre?',steps:'Observa el pulso hasta el extremo derecho libre; contrasta el signo con la práctica anterior.',answer:'En el extremo libre la fuerza transversal se anula, por lo que ∂y/∂x=0. El pulso se refleja sin invertir el desplazamiento.',quiz:'En un extremo ideal libre, se cumple…',options:['y = 0 siempre','∂y/∂x = 0','v = 0 en toda la cuerda'],correct:1,why:'La frontera libre impone pendiente transversal nula.',config:{excitation:'pulse',boundary:'fixed-free',position:.28,amplitude:.012,damping:0,duration:1.5}},
 fundamental:{title:'Una cuerda, un vientre',objective:'Reconocer la frecuencia fundamental de una cuerda fija en ambos extremos.',question:'¿Cuántos nodos y vientres tendrá el primer modo?',steps:'Activa «Nodos», reproduce y comprueba qué partes permanecen inmóviles. Compara el período observado en el osciloscopio con T₁.',answer:'El primer modo presenta nodos en x=0 y x=L y un vientre en L/2. Su longitud de onda es 2L y f₁=v/(2L).',quiz:'En el modo fundamental fijo–fijo hay…',options:['Dos nodos en los extremos','Un nodo en el centro','Tres vientres'],correct:0,why:'Los dos extremos fijos son nodos del primer modo.',config:{excitation:'harmonic',harmonic:1,boundary:'fixed-fixed',damping:0,amplitude:.009,duration:1.2}},
 third:{title:'Tercer armónico: tres vientres',objective:'Relacionar el número de modo con la cantidad de nodos y la frecuencia natural.',question:'Si n=3, ¿cuántos nodos hay contando ambos extremos?',steps:'Activa «Nodos». Mueve la sonda primero a un vientre y luego cerca de x=L/3: compara la señal de oscilación.',answer:'Para n=3 hay cuatro nodos (0,L/3,2L/3,L), tres vientres y f₃=3f₁, siempre que ambos extremos estén fijos.',quiz:'El tercer armónico de una cuerda fija–fija tiene…',options:['3 nodos y 4 vientres','4 nodos y 3 vientres','2 nodos y 3 vientres'],correct:1,why:'El modo n tiene n+1 nodos y n vientres.',config:{excitation:'harmonic',harmonic:3,boundary:'fixed-fixed',damping:0,amplitude:.009,duration:1}},
 tension4:{title:'Cuadruplicar la tensión',objective:'Comprobar experimentalmente la raíz cuadrada de la tensión en la rapidez de onda.',question:'Si pasamos de 40 N a 160 N, ¿la rapidez será 2× o 4×?',steps:'Lee la rapidez con 160 N y luego cambia a 40 N y aplica. Contrasta ambas cifras y la frecuencia f₁.',answer:'v∝√Fₜ. Una tensión cuatro veces mayor produce una rapidez y frecuencias naturales dos veces mayores, manteniendo μ y L.',quiz:'Si Fₜ se multiplica por 4 sin cambiar μ, entonces v…',options:['Se duplica','Se cuadruplica','Se reduce a la mitad'],correct:0,why:'√4=2. La relación no es lineal con la tensión.',config:{excitation:'pluck',boundary:'fixed-fixed',tension:160,mu:.012,damping:.1,duration:3}},
 heavier:{title:'Mayor densidad, onda más lenta',objective:'Analizar la influencia de la masa por metro sobre la velocidad.',question:'Al aumentar μ cuatro veces, ¿qué ocurre con el tiempo de tránsito?',steps:'Observa el tiempo L/v con μ=0,048 kg/m y compáralo con μ=0,012 kg/m, sin cambiar Fₜ.',answer:'Al cuadruplicar μ, la velocidad se divide por 2 y el tiempo para recorrer la cuerda se duplica.',quiz:'Si μ se multiplica por 4, la rapidez…',options:['Se duplica','Se reduce a la mitad','Permanece igual'],correct:1,why:'v∝1/√μ.',config:{excitation:'pluck',boundary:'fixed-fixed',tension:80,mu:.048,damping:.1,duration:4}},
 resonance:{title:'Resonancia: energía acumulada',objective:'Contrastar respuesta de un sistema forzado con un modo propio.',question:'¿Qué sucede cuando la frecuencia externa coincide con f₁ y la amortiguación es débil?',steps:'Mira la gráfica «Energía», activa reproducción y observa el crecimiento. Cambia a una frecuencia distinta y compara.',answer:'Una fuerza armónica cercana a una frecuencia natural puede transferir energía eficientemente. El crecimiento se limita por amortiguamiento y por los supuestos del modelo.',quiz:'En resonancia con amortiguamiento muy débil, la respuesta…',options:['Tiende a crecer significativamente','Siempre desaparece','Hace aumentar la velocidad v'],correct:0,why:'La excitación aporta energía; la velocidad de propagación no cambia.',config:{excitation:'drive',boundary:'fixed-fixed',tension:80,mu:.012,damping:.7,force:.018,position:.5,driveFreq:34.02069087199,duration:4}},
 'off-resonance':{title:'Excitación desafinada',objective:'Comparar transferencia de energía a frecuencias alejadas de los modos propios.',question:'¿La misma fuerza genera igual amplitud si se aplica entre resonancias?',steps:'Observa la energía con la excitación a 44 Hz y compárala con la práctica 08, manteniendo fuerza y amortiguamiento.',answer:'Lejos de las frecuencias naturales la respuesta estacionaria suele ser menor; con varios modos y transitorios puede oscilar. La energía depende de las condiciones de la fuerza y del tiempo.',quiz:'¿La fuerza externa siempre produce resonancia?',options:['Sí, a cualquier frecuencia','Solo si el valor de la tensión es cero','No; depende de la frecuencia de excitación'],correct:2,why:'La resonancia ocurre cerca de frecuencias propias del sistema.',config:{excitation:'drive',boundary:'fixed-fixed',tension:80,mu:.012,damping:.7,force:.018,position:.5,driveFreq:44,duration:4}},
 damping:{title:'Cuando la energía se disipa',objective:'Relacionar amortiguamiento lineal con disminución de energía mecánica.',question:'¿En ausencia de fuerza externa y con γ>0, la energía puede aumentar por sí sola?',steps:'Selecciona la gráfica «Energía»; reproduce y luego repite estableciendo γ=0. Compara la curva total.',answer:'El término 2μγ yₜ extrae energía de las vibraciones. Sin fuerza externa, la energía total decae; con γ=0 se conserva en el modelo ideal.',quiz:'Con amortiguamiento positivo y sin fuerza externa, E(t)…',options:['Aumenta siempre','Disminuye o permanece constante','No depende del tiempo'],correct:1,why:'La disipación convierte energía mecánica en otras formas no modeladas.',config:{excitation:'pluck',boundary:'fixed-fixed',damping:2,amplitude:.010,duration:3}}
};
const keys=['length','tension','mu','damping','amplitude','position','harmonic','driveFreq','force','duration'];
let pending={...P.DEFAULTS},model=P.createModel(pending),time=0,running=false,lastTime=0,raf=0,chartType='osc',showNodes=false,showTrail=false,vertical=0.012,markers=[],currentScenario='plucked',themeDark=false;
let audioCtx=null,audioSource=null,audioPlaying=false,toastTimer=0;
const cvs=$('#string-canvas'),chart=$('#chart-canvas'),seek=$('#seek');
function toast(message){const e=$('#toast');e.textContent=message;e.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.hidden=true,3400);}
function setParam(key,v){const value=Number(v);if(!Number.isFinite(value))return;
 const lo=+$('#v-'+key).min,hi=+$('#v-'+key).max,s=+($('#v-'+key).dataset.scale||1);
 pending[key]=Math.min(hi,Math.max(lo,value))/s;
 const display=pending[key]*s;
 const n=$('#v-'+key),r=$(`[data-range="${key}"]`);if(n&&document.activeElement!==n)n.value=String(+display.toFixed(6));if(r)r.value=String(display);
 $('#pending-message').classList.add('warning');$('#pending-message').textContent='Hay cambios sin aplicar. Los resultados corresponden al experimento anterior.';
}
function syncControls(){for(const k of keys){const inp=$('#v-'+k),range=$(`[data-range="${k}"]`),scale=+(inp?.dataset.scale||1);if(inp)inp.value=String(+(pending[k]*scale).toFixed(6));if(range)range.value=String(pending[k]*scale);}
 $('#excitation').value=pending.excitation;$('#boundary').value=pending.boundary;toggleConditional();}
function toggleConditional(){const ex=$('#excitation').value;$$('.is-conditional').forEach(e=>e.hidden=e.dataset.show!==ex);}
function stopAudio(){if(audioSource){try{audioSource.onended=null;audioSource.stop();}catch{}try{audioSource.disconnect();}catch{}audioSource=null;}audioPlaying=false;$('#listen').disabled=false;$('#stop-audio').disabled=true;}
function stop(){running=false;lastTime=0;$('#play').textContent='▶ Reproducir';$('#state-badge').textContent='En pausa';$('#state-badge').classList.remove('running');stopAudio();}
function apply(shouldToast=false){stop();pending=P.normalize(pending);model=P.createModel(pending);time=0;markers=[];syncControls();seek.max=String(pending.duration);seek.step=String(Math.min(.01,1/(model.frequency1*100)));seek.value='0';
 let peak=pending.amplitude;for(let i=0;i<=38;i++)peak=Math.max(peak,model.snapshot(pending.duration*i/38,111).maxAbs);
 vertical=Math.max(.001,peak*1.43);
 $('#pending-message').classList.remove('warning');$('#pending-message').textContent='Configuración aplicada. Puedes comenzar el experimento.';
 $('#metric-speed').textContent=`${fmt(model.speed,2)} m/s`;$('#metric-f1').textContent=`${fmt(model.frequency1,2)} Hz`;$('#metric-period').textContent=`${fmt(1/model.frequency1,4)} s`;
 $('#res-speed').textContent=`${fmt(model.speed,3)} m/s`;$('#res-fund').textContent=`${fmt(model.frequency1,3)} Hz`;
 $('#res-lambda').textContent=`${fmt(model.speed/model.frequency1,3)} m`;
 $('#res-mass').textContent=`${fmt(pending.mu*pending.length,4)} kg`;
 $('#res-transit').textContent=`${fmt(pending.length/model.speed,4)} s`;
 $('#res-E0').textContent=`${fmt(model.snapshot(0).energy.total,5)} J`;
 $('#res-drive').textContent=pending.excitation==='drive'?`${fmt(pending.driveFreq,2)} Hz`:'No aplica';
 $('#axis-explain').textContent=`eje x: 0 → ${fmt(pending.length,2)} m`;
 $('#mag-explain').textContent=`escala y: ± ${fmt(vertical*1000,1)} mm`;
 const bnames={'fixed-fixed':'fijo — fijo','fixed-free':'fijo — libre','free-fixed':'libre — fijo','free-free':'libre — libre'};
 $('#drive-notice').textContent=`Fronteras: ${bnames[pending.boundary]}`;
 $('#canvas-tip').textContent=pending.excitation==='drive'?'Una fuerza sinusoidal aporta energía en la posición x₀. Compara la frecuencia externa con los modos naturales.':pending.excitation==='harmonic'?'Observa los nodos y vientres. La forma seleccionada es un modo propio que vibra en el tiempo.':'Reproduce la cuerda. Las partículas oscilan transversalmente; la perturbación se propaga longitudinalmente.';
 render();if(shouldToast)toast('Experimento aplicado. Se reinició el tiempo físico.');
}
function goTo(t){time=Math.max(0,Math.min(model.config.duration,t));seek.value=String(time);render();}
function play(){if(running){stop();render();return;}if(time>=model.config.duration-1e-10)time=0;running=true;lastTime=0;$('#play').textContent='Ⅱ Pausar';$('#state-badge').textContent='En ejecución';$('#state-badge').classList.add('running');raf=requestAnimationFrame(frame);}
function frame(stamp){if(!running)return;if(lastTime){const dt=Math.min((stamp-lastTime)/1000,.12)*Number($('#playback').value);time=Math.min(model.config.duration,time+dt);}lastTime=stamp;render();if(time>=model.config.duration){stop();render();toast('Final del experimento. Reinicia o cambia los parámetros.');return;}raf=requestAnimationFrame(frame);}
function dimensions(canvas){const r=canvas.getBoundingClientRect(),dpr=Math.min(2.5,window.devicePixelRatio||1),w=Math.max(20,r.width),h=Math.max(20,r.height);const pw=Math.round(w*dpr),ph=Math.round(h*dpr);
 if(canvas.width!==pw||canvas.height!==ph){canvas.width=pw;canvas.height=ph;}
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);return {ctx,w,h};}
function rounded(ctx,x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
function scene(){const {ctx,w,h}=dimensions(cvs);ctx.clearRect(0,0,w,h);
 const bg=ctx.createLinearGradient(0,0,w,h);bg.addColorStop(0,'#0e2633');bg.addColorStop(1,'#174454');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
 const left=40,right=w-29,top=44,bottom=h-47,W=right-left,H=bottom-top,cy=(top+bottom)/2,scale=H/(2*vertical),L=model.config.length;
 const xpx=x=>left+W*x/L,ypx=y=>cy-scale*y;
 // Physical grid with mm axis and meters axis.
 ctx.save();ctx.strokeStyle='#34576a';ctx.lineWidth=1;ctx.font='10px DM Sans, sans-serif';ctx.textAlign='center';ctx.fillStyle='#a0bac2';
 for(let j=0;j<=8;j++){const x=left+W*j/8;ctx.beginPath();ctx.moveTo(x,top);ctx.lineTo(x,bottom);ctx.stroke();ctx.fillText(fmt(j*L/8,2),x,h-24);}
 for(let j=-3;j<=3;j++){const y=cy+(H/6)*j;ctx.beginPath();ctx.setLineDash(j===0?[6,5]:[2,7]);ctx.strokeStyle=j===0?'#6a9299':'#34576a';ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();ctx.fillStyle='#98b8c1';ctx.textAlign='right';ctx.fillText(fmt(-j*vertical*1000/3,1),left-8,y+3);}
 ctx.setLineDash([]);ctx.font='bold 10px DM Sans,sans-serif';ctx.textAlign='left';ctx.fillStyle='#8ccdc8';ctx.fillText('y (mm)',7,top-17);ctx.fillText('x (m)',right-23,h-9);
 const s=model.snapshot(time,191),xstep=W/(s.ys.length-1);
 // Transparent history strips to visualize propagation, never changes physical state.
 if(showTrail){for(let d=5;d>=1;d--){const ts=Math.max(0,time-d/(model.frequency1*6)),snap=model.snapshot(ts,191);ctx.beginPath();for(let j=0;j<snap.ys.length;j++){const px=left+j*xstep,py=ypx(snap.ys[j]);if(j===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.strokeStyle=`rgba(72,209,198,${(6-d)*.065})`;ctx.lineWidth=1.3;ctx.stroke();}}
 // A reference chord at zero displacement.
 ctx.strokeStyle='#abbec149';ctx.setLineDash([4,5]);ctx.beginPath();ctx.moveTo(left,cy);ctx.lineTo(right,cy);ctx.stroke();ctx.setLineDash([]);
 if(showNodes){const nodes=model.predictedNodePositions();for(let i=0;i<nodes.length;i++){const x=xpx(nodes[i]);ctx.strokeStyle='#ffb77d90';ctx.setLineDash([3,5]);ctx.beginPath();ctx.moveTo(x,top+7);ctx.lineTo(x,bottom);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#fcb88f';ctx.beginPath();ctx.arc(x,cy,3.5,0,Math.PI*2);ctx.fill();if(i!==0&&i!==nodes.length-1){ctx.font='bold 9px DM Sans';ctx.fillText('N',x+4,cy-9);}}}
 // central string path and physical sampled points.
 ctx.shadowColor='#27ddc67a';ctx.shadowBlur=11;ctx.lineWidth=3.4;ctx.lineJoin='round';ctx.lineCap='round';ctx.strokeStyle='#53e4cf';ctx.beginPath();s.ys.forEach((y,j)=>{const x=left+j*xstep,py=ypx(y);if(j===0)ctx.moveTo(x,py);else ctx.lineTo(x,py);});ctx.stroke();ctx.shadowBlur=0;
 ctx.fillStyle='#b2fff0';for(let i=1;i<14;i++){const j=Math.round(i*(s.ys.length-1)/14),x=left+j*xstep;ctx.beginPath();ctx.arc(x,ypx(s.ys[j]),1.9,0,Math.PI*2);ctx.fill();}
 // Boundary fixtures. A free end is drawn as an unblocked ring.
 const boundary=model.config.boundary;
 for(const [x,fixed] of [[left,boundary.startsWith('fixed')],[right,boundary.endsWith('fixed')]]){
  const y=ypx(s.ys[x===left?0:s.ys.length-1]);ctx.fillStyle=fixed?'#b3d3d9':'#153b49';ctx.strokeStyle=fixed?'#8cbdc4':'#ffb87b';ctx.lineWidth=2;
  if(fixed){ctx.fillRect(x-6,cy-17,12,34);ctx.strokeStyle='#0c2633';for(let j=-1;j<=1;j++){ctx.beginPath();ctx.moveTo(x-6,cy+j*9);ctx.lineTo(x+6,cy+j*9-7);ctx.stroke();}}
  else{ctx.beginPath();ctx.arc(x,y,7,0,TAU);ctx.fill();ctx.stroke();}
 }
 // excitation location (small vertical guide).
 if(model.config.excitation==='drive'){
  const x=xpx(model.config.position*L),y=ypx(model.sample(time,model.config.position*L).y);ctx.strokeStyle='#fec187';ctx.lineWidth=1.3;ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(x,top+3);ctx.lineTo(x,bottom);ctx.stroke();ctx.setLineDash([]);
  ctx.fillStyle='#f8bc79';ctx.beginPath();ctx.moveTo(x,y-18);ctx.lineTo(x-5,y-29);ctx.lineTo(x+5,y-29);ctx.closePath();ctx.fill();ctx.font='bold 10px DM Sans';ctx.fillText('F(t)',x+8,top+22);
 }
 const probeX=xpx(model.config.probe*L),probeY=ypx(s.probe.y);
 ctx.setLineDash([5,5]);ctx.lineWidth=1.1;ctx.strokeStyle='#ffc397a0';ctx.beginPath();ctx.moveTo(probeX,top);ctx.lineTo(probeX,bottom);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='#ffb481';ctx.shadowColor='#ff97598c';ctx.shadowBlur=10;ctx.beginPath();ctx.arc(probeX,probeY,6,0,TAU);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(probeX,probeY,2,0,TAU);ctx.fill();
 ctx.fillStyle='#f7c59c';ctx.font='bold 10px DM Sans';ctx.textAlign=probeX<right-73?'left':'right';ctx.fillText('SONDA',probeX+(probeX<right-73?10:-11),Math.max(top+17,Math.min(bottom-8,probeY-16)));
 // physical rulers for a quick constant information anchor.
 ctx.font='9px DM Sans';ctx.fillStyle='#86aab4';ctx.textAlign='left';ctx.fillText('Tensión uniforme · medio ideal',left,top-15);ctx.restore();
 return s;
}
const TAU=2*Math.PI;
function chartPlot(){const {ctx,w,h}=dimensions(chart),dark=document.body.classList.contains('dark');ctx.clearRect(0,0,w,h);ctx.fillStyle=dark?'#173641':'#f7faf9';ctx.fillRect(0,0,w,h);
 const L=48,R=15,T=29,B=36,pw=w-L-R,ph=h-T-B;
 const ink=dark?'#b8d3d8':'#647f87',grid=dark?'#315561':'#dce9e9',main=dark?'#67efdc':'#098d82',orange='#e49b69';
 ctx.font='10px DM Sans, sans-serif';ctx.strokeStyle=grid;ctx.fillStyle=ink;ctx.lineWidth=1;
 function axes(xmin,xmax,ymin,ymax,title,yunit,xunit){
  ctx.font='bold 11px DM Sans';ctx.textAlign='left';ctx.fillText(title,L,T-13);ctx.font='9px DM Sans';
  for(let j=0;j<=4;j++){const xx=L+pw*j/4,yy=T+ph*j/4;ctx.strokeStyle=grid;ctx.beginPath();ctx.moveTo(xx,T);ctx.lineTo(xx,T+ph);ctx.moveTo(L,yy);ctx.lineTo(L+pw,yy);ctx.stroke();ctx.fillStyle=ink;ctx.textAlign='center';ctx.fillText(fmt(xmin+(xmax-xmin)*j/4,xunit==='Hz'?0:2),xx,h-13);ctx.textAlign='right';ctx.fillText(fmt(ymax-(ymax-ymin)*j/4,yunit==='mJ'?2:yunit==='mm'?1:1),L-6,yy+3);}
  ctx.font='9px DM Sans';ctx.textAlign='right';ctx.fillText(xunit,w-15,h-4);ctx.textAlign='left';ctx.fillText(yunit,6,13);
  const mapX=x=>L+(x-xmin)/(xmax-xmin)*pw,mapY=y=>T+(ymax-y)/(ymax-ymin)*ph;return {mapX,mapY};
 }
 function line(data,color,width=2.2){ctx.beginPath();for(let j=0;j<data.length;j++){const [xx,yy]=data[j];if(j===0)ctx.moveTo(xx,yy);else ctx.lineTo(xx,yy);}ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineJoin='round';ctx.stroke();}
 const dur=model.config.duration;
 if(chartType==='osc'){
  const visible=Math.min(dur,Math.max(.035,Math.min(dur,6/model.frequency1))),start=Math.max(0,Math.min(dur-visible,time-visible*.37)),end=start+visible;
  const vals=[];let max=.00005;for(let j=0;j<=225;j++){const t=start+visible*j/225,y=model.sampleAtProbe(t).y;max=Math.max(max,Math.abs(y));vals.push([t,y]);}
  const a=axes(start,end,-max*1200,max*1200,'Desplazamiento de la sonda · ventana ~6 T₁','mm','s');line(vals.map(([t,y])=>[a.mapX(t),a.mapY(y*1000)]),main);
  const xt=a.mapX(time);ctx.strokeStyle=orange;ctx.lineWidth=1.5;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(xt,T);ctx.lineTo(xt,T+ph);ctx.stroke();ctx.setLineDash([]);
  ctx.fillStyle=orange;ctx.beginPath();ctx.arc(xt,a.mapY(model.sampleAtProbe(time).y*1000),4,0,TAU);ctx.fill();
 } else if(chartType==='energy'){
  const vals=[],n=215;let max=1e-9;
  for(let j=0;j<=n;j++){const t=dur*j/n,e=model.energy(model.coefficients(t));vals.push([t,e]);max=Math.max(max,e.total);}
  max*=1.13;const a=axes(0,dur,0,max*1000,'Balance de energía modal','mJ','s');
  line(vals.map(([t,e])=>[a.mapX(t),a.mapY(e.total*1000)]),main,2.5);
  line(vals.map(([t,e])=>[a.mapX(t),a.mapY(e.kinetic*1000)]),'#e9a16e',1.5);
  line(vals.map(([t,e])=>[a.mapX(t),a.mapY(e.potential*1000)]),'#6898d2',1.5);
  ctx.textAlign='left';ctx.font='bold 9px DM Sans';ctx.fillStyle=main;ctx.fillText('— Total',L+10,T+12);ctx.fillStyle=orange;ctx.fillText('— Cinética',L+74,T+12);ctx.fillStyle='#6898d2';ctx.fillText('— Potencial',L+150,T+12);
  ctx.setLineDash([4,3]);ctx.strokeStyle=orange;ctx.beginPath();ctx.moveTo(a.mapX(time),T);ctx.lineTo(a.mapX(time),T+ph);ctx.stroke();ctx.setLineDash([]);
 } else {
  const mods=model.modes.filter(m=>m.frequency>1e-6).slice(0,12),coef=model.coefficients(time),bars=mods.map(m=>({f:m.frequency,q:Math.abs(coef[model.modes.indexOf(m)][0])*1000}));
  const max=Math.max(.001,...bars.map(b=>b.q))*1.25;
  const a=axes(0,13,0,max,'Contribución de los primeros 12 modos','mm','n');
  const bw=pw/18;for(let i=0;i<bars.length;i++){const b=bars[i],cx=a.mapX(i+1),hh=Math.max(1,T+ph-a.mapY(b.q));const gr=ctx.createLinearGradient(0,T+ph-hh,0,T+ph);gr.addColorStop(0,'#5be6d4');gr.addColorStop(1,'#149b8e');ctx.fillStyle=gr;rounded(ctx,cx-bw/2,T+ph-hh,bw,hh,3);ctx.fill();ctx.font='9px DM Sans';ctx.textAlign='center';ctx.fillStyle=ink;ctx.fillText(''+(i+1),cx,h-12);}
  ctx.font='9px DM Sans';ctx.textAlign='right';ctx.fillStyle=ink;ctx.fillText('Frecuencias de los modos: '+fmt(model.frequency1,1)+' Hz y múltiplos según frontera',w-14,T+11);
 }
}
function render(){const s=scene();chartPlot();
 $('#clock').textContent=fmt(time,3);$('#time-display').textContent=`${fmt(time,3)} / ${fmt(model.config.duration,3)} s`;seek.value=String(time);
 $('#metric-energy').textContent=`${fmt(s.energy.total,4)} J`;
 $('#probe-position').textContent=`x = ${fmt(model.config.probe*model.config.length,2)} m (${fmt(model.config.probe*100,0)} %)`;
 $('#probe-y').textContent=`${fmt(s.probe.y*1000,2)} mm`;$('#probe-v').textContent=`${fmt(s.probe.vy,3)} m/s`;
 $('#energy-k').textContent=`${fmt(s.energy.kinetic*1000,2)} mJ`;$('#energy-u').textContent=`${fmt(s.energy.potential*1000,2)} mJ`;
 $('#res-max').textContent=`${fmt(s.maxAbs*1000,3)} mm`;$('#res-Et').textContent=`${fmt(s.energy.total,5)} J`;
 const risk=s.maxAbs>model.config.length*.05||vertical/1.43>model.config.length*.05;$('#model-caution').hidden=!risk;
 $('#energy-comment').textContent=model.config.excitation==='drive'?'Incluye trabajo de fuerza externa':model.config.damping===0?'Conservación ideal':'Amortiguación lineal';
}
function selectScenario(id){const s=scenarios[id];if(!s)return;currentScenario=id;pending={...P.DEFAULTS,...s.config};
 if(pending.excitation==='drive'&&id==='resonance'){const tmp=P.createModel(pending);pending.driveFreq=tmp.frequency1;}
 $('#scenario-title').textContent=s.title;$('#scenario-objective').textContent=s.objective;$('#scenario-question').textContent=s.question;$('#scenario-steps').textContent=s.steps;$('#scenario-answer').textContent=s.answer;
 $('#quiz-question').textContent=s.quiz;$('#quiz-options').innerHTML=s.options.map((o,i)=>`<label><input type="radio" name="scenario-q" value="${i}"> ${o}</label>`).join('');$('#quiz-result').textContent='';$('.answer-panel').open=false;
 showNodes=id==='fundamental'||id==='third';$('#toggle-nodes').setAttribute('aria-pressed',String(showNodes));
 chartType=id==='damping'||id==='resonance'||id==='off-resonance'?'energy':'osc';updateChartTabs();apply();}
function updateChartTabs(){$$('[data-chart]').forEach(e=>e.setAttribute('aria-selected',String(e.dataset.chart===chartType)));}
function choosePane(id){$$('[data-pane]').forEach(e=>e.setAttribute('aria-selected',String(e.dataset.pane===id)));$$('.tab-content').forEach(e=>e.hidden=e.id!==`pane-${id}`);}
function saveBlob(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function exportCSV(){const n=Math.min(20000,Math.max(1000,Math.ceil(model.config.duration*model.frequency1*40))),rows=['tiempo_s;posicion_sonda_m;desplazamiento_sonda_m;velocidad_y_sonda_m_s;energia_cinetica_J;energia_potencial_J;energia_total_J'];
 for(let i=0;i<=n;i++){const t=model.config.duration*i/n,p=model.sampleAtProbe(t),en=model.energy(model.coefficients(t));rows.push([t,model.config.probe*model.config.length,p.y,p.vy,en.kinetic,en.potential,en.total].map(v=>Number(v).toFixed(9)).join(';'));}
 const preface=['# Laboratorio de cuerda tensa · física III',`# Tension_N=${model.config.tension}; mu_kg_m=${model.config.mu}; longitud_m=${model.config.length}; frontera=${model.config.boundary}; excitacion=${model.config.excitation}; gamma_s-1=${model.config.damping}; modos=${model.config.modeCount}`];
 saveBlob(new Blob(['\ufeff'+[...preface,...rows].join('\r\n')],{type:'text/csv;charset=utf-8'}),'laboratorio_cuerda_mediciones.csv');toast(`Datos físicos exportados en CSV (${n+1} instantes).`);}
function exportPNG(){const c=document.createElement('canvas'),w=1400;c.width=w;c.height=1190;const ctx=c.getContext('2d');ctx.fillStyle='#f1f6f7';ctx.fillRect(0,0,w,c.height);ctx.fillStyle='#102a37';ctx.fillRect(0,0,w,140);ctx.fillStyle='#62e9d2';ctx.font='bold 23px DM Sans, sans-serif';ctx.fillText('FÍSICA III   /   LABORATORIO 07',52,47);ctx.fillStyle='white';ctx.font='bold 46px DM Sans, sans-serif';ctx.fillText('Simulación de cuerda tensa',52,103);
 ctx.fillStyle='#183e4b';ctx.font='20px DM Sans';ctx.fillText(`Fₜ = ${fmt(model.config.tension)} N   •   μ = ${fmt(model.config.mu,4)} kg/m   •   L = ${fmt(model.config.length,2)} m`,48,185);
 ctx.fillText(`v = ${fmt(model.speed,2)} m/s   •   f₁ = ${fmt(model.frequency1,2)} Hz   •   t = ${fmt(time,3)} s`,48,215);
 ctx.drawImage(cvs,48,255,1304,650);ctx.drawImage(chart,48,923,1304,210);
 ctx.fillStyle='#476d76';ctx.font='14px DM Sans';ctx.fillText('Modelo modal de cuerda ideal · Desplazamientos transversales con escala vertical independiente',48,1164);
 c.toBlob(blob=>blob&&saveBlob(blob,'laboratorio_cuerda_instante.png'),'image/png');toast('Imagen de la simulación exportada.');}
async function listen(){stopAudio();const AC=window.AudioContext||window.webkitAudioContext;if(!AC){toast('Este navegador no dispone de Web Audio.');return;}
 try{audioCtx=audioCtx||new AC();await audioCtx.resume();const sr=22050,N=Math.round(sr*2.5),buffer=audioCtx.createBuffer(1,N,sr),data=buffer.getChannelData(0);
 const freq=model.frequency1,scale=Math.min(8,Math.max(1,120/Math.max(freq,1))),start=time;let max=1e-8,mean=0;
 for(let i=0;i<N;i++){const physicalTime=start+(i/sr)*scale,y=model.sampleAtProbe(physicalTime).y;data[i]=y;max=Math.max(max,Math.abs(y));mean+=y;}mean/=N;
 max=0;for(let i=0;i<N;i++){data[i]-=mean;max=Math.max(max,Math.abs(data[i]));}
 const mult=.26/(max||1);for(let i=0;i<N;i++){const edge=Math.min(1,i/(sr*.045),(N-i-1)/(sr*.11));data[i]=Math.tanh((data[i]*mult))*Math.max(0,edge);}
 const src=audioCtx.createBufferSource(),gain=audioCtx.createGain();gain.gain.value=.45;src.buffer=buffer;src.connect(gain);gain.connect(audioCtx.destination);audioSource=src;
 src.onended=()=>{audioPlaying=false;$('#listen').disabled=false;$('#stop-audio').disabled=true;$('#audio-status').textContent='Muestra finalizada. Audio apagado.';audioSource=null;};
 src.start();audioPlaying=true;$('#listen').disabled=true;$('#stop-audio').disabled=false;
 $('#audio-status').textContent=scale>1.01?`Muestra calculada de la sonda · escala temporal ${fmt(scale,2)}× para audibilidad (frecuencias también ×${fmt(scale,2)}).`:'Muestra calculada de la sonda · escala 1×, frecuencia sin transposición.';
 }catch(e){console.warn('No se pudo producir el audio',e);stopAudio();toast('No se pudo reproducir audio en este dispositivo.');}}
function initialize(){
 for(const k of keys){const e=$('#v-'+k),r=$(`[data-range="${k}"]`);e.addEventListener('change',()=>setParam(k,e.value));r.addEventListener('input',()=>{e.value=r.value;setParam(k,r.value);});}
 for(const k of ['excitation','boundary'])$('#'+k).addEventListener('change',e=>{pending[k]=e.target.value;toggleConditional();$('#pending-message').classList.add('warning');$('#pending-message').textContent='Cambio pendiente. Aplica para iniciar un experimento nuevo.';});
 $('#apply-btn').addEventListener('click',()=>apply(true));$('#play').addEventListener('click',play);$('#reset').addEventListener('click',()=>{stop();goTo(0);});
 $('#step').addEventListener('click',()=>{stop();goTo(time+1/(model.frequency1*100));});$('#period').addEventListener('click',()=>{stop();goTo(time+1/model.frequency1);});
 seek.addEventListener('input',e=>{stop();goTo(+e.target.value);});
 $('#probe').addEventListener('input',e=>{pending.probe=Number(e.target.value)/100;model=P.createModel({...model.config,probe:pending.probe});stopAudio();render();});
 $('#reset-probe').addEventListener('click',()=>{$('#probe').value='72';pending.probe=.72;model=P.createModel({...model.config,probe:pending.probe});stopAudio();render();});
 $('#toggle-nodes').addEventListener('click',()=>{showNodes=!showNodes;$('#toggle-nodes').setAttribute('aria-pressed',String(showNodes));if(showNodes&&!model.predictedNodePositions().length)toast('Los nodos previstos se muestran para modos propios en una cuerda fijo–fijo.');render();});
 $('#toggle-trail').addEventListener('click',()=>{showTrail=!showTrail;$('#toggle-trail').setAttribute('aria-pressed',String(showTrail));render();});
 // Pointer placement of probe without moving the physical string.
 cvs.addEventListener('pointerdown',e=>{const r=cvs.getBoundingClientRect(),x=(e.clientX-r.left),p=Math.max(.03,Math.min(.97,(x-40)/(r.width-69)));$('#probe').value=String(Math.round(p*100));pending.probe=p;model=P.createModel({...model.config,probe:pending.probe});stopAudio();render();});
 $$('[data-chart]').forEach(e=>e.addEventListener('click',()=>{chartType=e.dataset.chart;updateChartTabs();render();}));
 $$('[data-pane]').forEach(e=>e.addEventListener('click',()=>choosePane(e.dataset.pane)));
 $('#scenario').addEventListener('change',e=>selectScenario(e.target.value));
 $('#check-answer').addEventListener('click',()=>{const choice=$('input[name="scenario-q"]:checked'),s=scenarios[currentScenario],el=$('#quiz-result');if(!choice){el.textContent='Selecciona una opción antes de comprobar.';return;}const good=+choice.value===s.correct;el.textContent=(good?'✓ Correcto. ':'✗ Revisa la predicción. ')+s.why;el.style.color=good?'#0f8371':'#bf6d44';});
 $('#export-csv').addEventListener('click',exportCSV);$('#export-png').addEventListener('click',exportPNG);
 $('#listen').addEventListener('click',listen);$('#stop-audio').addEventListener('click',()=>{stopAudio();$('#audio-status').textContent='Audio detenido.';});
 $('#theme-toggle').addEventListener('click',()=>{themeDark=!themeDark;document.body.classList.toggle('dark',themeDark);$('#theme-toggle').setAttribute('aria-pressed',String(themeDark));render();});
 $('#fullscreen-btn').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(e){toast('Tu navegador no permitió pantalla completa.');}});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&running){stop();render();}});
 window.addEventListener('resize',render);
 document.addEventListener('keydown',e=>{const tgt=e.target;if(['INPUT','SELECT','TEXTAREA','BUTTON'].includes(tgt.tagName)||e.ctrlKey||e.altKey||e.metaKey)return;if(e.code==='Space'){e.preventDefault();play();}if(e.key==='ArrowRight'){stop();goTo(time+1/(model.frequency1*100));}if(e.key==='ArrowLeft'){stop();goTo(time-1/(model.frequency1*100));}});
 // The animation clock can advance t; the physics is recomputed directly from that time. No cumulative numerical integration.
 selectScenario('plucked');
}
initialize();
})();
