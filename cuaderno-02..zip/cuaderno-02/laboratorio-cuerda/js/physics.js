/* Laboratorio de cuerda tensa · núcleo físico sin dependencias ni reloj.
 * Solución por expansión modal truncada de μ y_tt + 2μγ y_t = T y_xx + F(t)δ(x-xd).
 * La representación no resuelve no-linealidad, dispersión, rigidez ni el aire.
 */
(function(root){
'use strict';
const PI=Math.PI,TAU=2*PI;
const DEFAULTS=Object.freeze({length:1.2,tension:80,mu:0.012,damping:0.12,amplitude:0.008,position:0.35,probe:0.72,harmonic:1,driveFreq:34.02,force:0.024,duration:6,modeCount:48,boundary:'fixed-fixed',excitation:'pluck'});
const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
function normalize(p={}){
 const c={...DEFAULTS,...p};
 const limits={length:[0.4,5],tension:[5,200],mu:[0.002,0.08],damping:[0,7],amplitude:[0.0005,0.025],position:[0.08,0.92],probe:[0.03,0.97],harmonic:[1,8],driveFreq:[0.5,250],force:[0.0001,0.12],duration:[0.5,20],modeCount:[12,96]};
 for(const [key,[lo,hi]] of Object.entries(limits)){const num=Number(c[key]);c[key]=clamp(Number.isFinite(num)?num:DEFAULTS[key],lo,hi);}
 c.harmonic=Math.round(c.harmonic);c.modeCount=Math.round(c.modeCount);
 if(!['fixed-fixed','fixed-free','free-fixed','free-free'].includes(c.boundary))c.boundary='fixed-fixed';
 if(!['pluck','pulse','strike','harmonic','drive'].includes(c.excitation))c.excitation='pluck';
 return c;
}
function modeMeta(i,boundary,L,c){
 let m,k,type,norm;
 if(boundary==='fixed-fixed'){m=i+1;k=m*PI/L;type='sin';norm=L/2;}
 else if(boundary==='fixed-free'){m=i+0.5;k=m*PI/L;type='sin';norm=L/2;}
 else if(boundary==='free-fixed'){m=i+0.5;k=m*PI/L;type='cos';norm=L/2;}
 else{m=i;k=m*PI/L;type='cos';norm=i===0?L:L/2;}
 return {id:i+1,k,omega:c*k,frequency:c*k/TAU,type,norm,modalNumber:m};
}
function basis(m,x){return m.type==='sin'?Math.sin(m.k*x):Math.cos(m.k*x);}
function profile(c,x,speed){
 const z=x/c.length,p=c.position,a=c.amplitude;
 if(c.excitation==='harmonic')return {y:0,v:0}; // coefficients set exactly in the selected eigenmode below
 if(c.excitation==='pluck')return {y:a*(z<=p?z/p:(1-z)/(1-p)),v:0};
 if(c.excitation==='pulse')return {y:a*Math.exp(-0.5*((z-p)/0.045)**2),v:0};
 if(c.excitation==='strike')return {y:0,v:(4*a*speed/c.length)*Math.exp(-0.5*((z-p)/0.05)**2)};
 return {y:0,v:0};
}
function homogeneous(q0,v0,w,g,t){
 if(w===0&&g===0)return [q0+v0*t,v0];
 const d=w*w-g*g;
 if(d>1e-10){const wd=Math.sqrt(d),s=Math.sin(wd*t),co=Math.cos(wd*t),B=(v0+g*q0)/wd,e=Math.exp(-g*t),z=q0*co+B*s;
   return [e*z,e*(-g*z-q0*wd*s+B*wd*co)];}
 if(d < -1e-10){const r=Math.sqrt(-d),r1=-g+r,r2=-g-r,A=(v0-r2*q0)/(r1-r2),B=q0-A,u=A*Math.exp(r1*t),v=B*Math.exp(r2*t);return [u+v,r1*u+r2*v];}
 const b=v0+g*q0,e=Math.exp(-g*t);return [e*(q0+b*t),e*(b-g*(q0+b*t))];
}
function modalAt(mode,t,c,Omega){
 if(c.excitation!=='drive')return homogeneous(mode.q0,mode.v0,mode.omega,c.damping,t);
 const b=mode.forcing,w=mode.omega,g=c.damping;
 if(b===0)return [0,0];
 // Sin rozamiento y exactamente en resonancia: solución forzada secular con arranque en reposo.
 if(g<1e-12&&Math.abs(w-Omega)<1e-9&&w>0){
  return [b/(2*w*w)*Math.sin(w*t)-b*t/(2*w)*Math.cos(w*t),b*t*0.5*Math.sin(w*t)];
 }
 const K=w*w-Omega*Omega,D=2*g*Omega,den=K*K+D*D;
 if(den<=0)return [0,0];
 const ps=b*K/den,pc=-b*D/den;
 const [qh,vh]=homogeneous(-pc,-ps*Omega,w,g,t);
 const s=Math.sin(Omega*t),co=Math.cos(Omega*t);
 return [qh+ps*s+pc*co,vh+Omega*(ps*co-pc*s)];
}
function createModel(parameters={}){
 const c=normalize(parameters);
 const waveSpeed=Math.sqrt(c.tension/c.mu),L=c.length;
 const modes=Array.from({length:c.modeCount},(_,i)=>modeMeta(i,c.boundary,L,waveSpeed));
 const driveX=L*c.position;
 // Trapezoidal quadrature for Fourier coefficients, independently from the modal time solution.
 const Q=768,dx=L/Q;
 for(const m of modes){
  let ySum=0,vSum=0;
  if(c.excitation!=='drive'){
   for(let j=0;j<=Q;j++){
    const x=j*dx,z=profile(c,x,waveSpeed),fac=(j===0||j===Q)?0.5:1,phi=basis(m,x);
    ySum+=fac*z.y*phi;vSum+=fac*z.v*phi;
   }
  }
  m.q0=c.excitation==='harmonic'?(m.id===(c.boundary==='free-free'?c.harmonic+1:c.harmonic)?c.amplitude:0):ySum*dx/m.norm;m.v0=vSum*dx/m.norm;
  m.forcing=c.excitation==='drive'?c.force*basis(m,driveX)/(c.mu*m.norm):0;
 }
 const Omega=TAU*c.driveFreq;
 function coefficients(t){const tt=Math.max(0,Number(t)||0);return modes.map(m=>modalAt(m,tt,c,Omega));}
 function evaluateAt(x,coeff){let y=0,vy=0,slope=0;const xx=clamp(x,0,L);
  for(let i=0;i<modes.length;i++){const m=modes[i],[q,v]=coeff[i],px=basis(m,xx);y+=q*px;vy+=v*px;slope+=q*m.k*(m.type==='sin'?Math.cos(m.k*xx):-Math.sin(m.k*xx));}
  return {y,vy,slope};
 }
 function energy(coeff){let kinetic=0,potential=0;for(let i=0;i<modes.length;i++){const m=modes[i],q=coeff[i][0],vel=coeff[i][1],mass=c.mu*m.norm;kinetic+=.5*mass*vel*vel;potential+=.5*mass*m.omega*m.omega*q*q;}
  return {kinetic,potential,total:kinetic+potential};
 }
 function snapshot(t,samples=171){const tt=clamp(Number(t)||0,0,c.duration),coef=coefficients(tt),n=Math.max(2,Math.min(600,Math.floor(samples))),ys=new Float64Array(n),vys=new Float64Array(n);
  let maxAbs=0;for(let j=0;j<n;j++){const z=evaluateAt(L*j/(n-1),coef);ys[j]=z.y;vys[j]=z.vy;maxAbs=Math.max(maxAbs,Math.abs(z.y));}
  const p=evaluateAt(c.probe*L,coef),en=energy(coef);
  return {t:tt,ys,vys,maxAbs,probe:p,energy:en,coefficients:coef};
 }
 function fundamental(){const a=modes.find(m=>m.frequency>1e-10);return a?a.frequency:0;}
 function predictedNodePositions(){if(c.boundary!=='fixed-fixed'||c.excitation!=='harmonic')return [];
  return Array.from({length:c.harmonic+1},(_,i)=>L*i/c.harmonic);
 }
 return {config:c,speed:waveSpeed,impedance:Math.sqrt(c.tension*c.mu),modes,omegaDrive:Omega,frequency1:fundamental(),coefficients,evaluateAt,snapshot,energy,predictedNodePositions,
  sample(t,x){return evaluateAt(x,coefficients(t));},
  sampleAtProbe(t){return evaluateAt(c.probe*L,coefficients(t));},
  physicsDescription:'Solución modal truncada de μ y_tt + 2 μ γ y_t = T y_xx + F(t)δ(x−x_d).'};
}
const api={DEFAULTS,normalize,createModel,modeMeta,homogeneous,modalAt};
if(typeof module!=='undefined'&&module.exports)module.exports=api;
root.StringLabPhysics=api;
})(typeof window!=='undefined'?window:globalThis);
