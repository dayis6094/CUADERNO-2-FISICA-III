# Laboratorio del efecto Doppler — Física III

## Cómo iniciar

1. Descomprime **Biblioteca_Fisica_III_Doppler.zip** en una carpeta del computador.
2. Abre **CUADERNO/index.html** con Chrome, Edge o Firefox. En la biblioteca, elige **Movimiento ondulatorio**.
3. En la página 18 del cuaderno, «Laboratorio 06 · El efecto Doppler», pulsa **Abrir laboratorio Doppler a pantalla completa**.
4. Acceso directo opcional: **CUADERNO/cuaderno-02/laboratorio-doppler/index.html**.
5. El simulador funciona sin servidor ni conexión para calcular, visualizar y exportar datos; la descarga opcional de MathJax requiere conexión. Si falla, la ecuación sigue legible en texto.

## Uso breve

- **Exploración:** selecciona uno de los 9 escenarios, predice, inicia/pausa, y compara frecuencia emitida, teórica, medida y número de frentes recibidos.
- **Laboratorio:** activa «Laboratorio» para editar posiciones, consultar cinco gráficos, inspeccionar frentes, ver ecuaciones y leer la tabla de eventos.
- **Cambios físicos:** modifica los deslizadores y/o campos numéricos; pulsa **Aplicar y reiniciar**. Los cambios no alteran ondas ya emitidas. Los escenarios también reinician.
- **Tiempo:** usa buscar instante, avanzar +Δt, avanzar +T, reiniciar y velocidades de reproducción 0,25× / 0,5× / 1× / 2×. La subdivisión manual admite 20 / 50 / 100 / 200 pasos por período.
- **Vista:** rueda del ratón o pinza para acercar, arrastrar fondo para desplazar, ±, ajustar escena, restaurar vista y «Seguir fuente». Activa medición y traza una línea para medir distancias.
- **Objetos:** con la reproducción pausada, arrastra el emisor o el micrófono para recolocarlos y reiniciar de forma explícita. Con geometría 2D, también se pueden mover verticalmente.
- **Historia de un frente:** haz clic en un anillo; se abre el panel Inspeccionar y aparecen te, centro, radio, llegada y predicción.
- **Audio:** está desactivado de forma predeterminada. Actívalo expresamente. «Pulsos de llegada» reproduce avisos de 660 Hz por evento; «Comparación tonal» permite escuchar, por separado, tonos emitido y recibido usando escala **1 Hz visual = 220 Hz audible**. No se pretende que un frente de 2 Hz sea un tono audible.
- **Exportaciones:** en nivel Laboratorio, pulsa **Exportar CSV** para guardar el historial de emisiones y recepciones, o **Imagen PNG** para guardar la escena actual.

## Modelo de física y matemáticas

- Medio homogéneo, estacionario, rapidez acústica c constante. Trayectorias de velocidad vectorial constante: fuente xf(t) = xf0 + vf·t; observador xo(t) = xo0 + vo·t.
- Emisiones: primera en t=0; siguientes en te,n=n/f, con período T=1/f.
- Frentes circulares centrados en **xf(te)**; centros inmóviles después de la emisión, radio c(t−te).
- Recepción: solución de **|xo(tr) − xf(te)| = c(tr−te)**, con tr≥te; cuadrática resuelta en cada frente, independiente del renderizador.
- En rama retardada regular: **fo = fe (c−n·vo)/(c−n·vf)**, siendo n el vector unitario desde la fuente en emisión hasta el observador en recepción.
- Medición independiente: **f_medida=1/(tr,n+1−tr,n)** para recepciones consecutivas no simultáneas. La predicción instantánea de señal continua y la medición discreta pueden diferir durante transitorios.
- Para movimiento rectilíneo subsónico sobre +x: **λ delante=(c−vf,x)/f**, **λ detrás=(c+vf,x)/f**. En general λ₀=c/f solo describe la fuente estacionaria. El movimiento del observador altera el ritmo de recepción, no la longitud de onda ya propagada.
- Número de Mach **M=|vf|/c**. Para M>1, la sección bidimensional de la envolvente de Mach tiene semiángulo **μ=asin(1/M)**. Frecuencias firmadas de ramas invertidas no se convierten a positivas mediante valor absoluto.

## Nueve actividades incluidas

1. Fuente y observador quietos.
2. Fuente que se aproxima.
3. Fuente que se aleja.
4. Observador que se aproxima.
5. Observador que se aleja.
6. Ambos a igual velocidad y con distancia constante.
7. Paso lateral en 2D.
8. Fuente en Mach 1.
9. Fuente supersónica Mach 2.

Cada escenario incorpora objetivo, predicción, instrucciones, explicación y pregunta comprobable con retroalimentación.

## Verificaciones realizadas

Pruebas programáticas en Node.js y contraste independiente en Python (c=340 m/s, f=1000 Hz; error relativo máximo en los casos numéricos inferior a 1e−9):

| Caso | Frecuencia esperada y comprobada |
|---|---:|
| Ambos en reposo | 1000 Hz |
| Fuente hacia observador a 34 m/s | 1111,111111… Hz |
| Fuente se aleja a 34 m/s | 909,090909… Hz |
| Observador se aproxima a 34 m/s | 1100 Hz |
| Observador se aleja a 34 m/s | 900 Hz |
| Ambos a +34 m/s, separación constante | 1000 Hz |

También comprobado: primer tiempo de vuelo de 340 m a 340 m/s = 1 s; Mach 2 = 30°; no eventos duplicados; todos los eventos incluidos con saltos temporales; reconstrucción determinista; conservación del centro de frente; inversión del orden de llegadas supersónicas; ausencia de resultados no finitos en el caso sónico analizado; mismo conjunto de eventos a 30, 60 y 144 FPS.

Interfaz comprobada en Chromium mediante pruebas de interacción automatizadas en tamaños 1600×980, 920×1050 y 390×844, sin errores JavaScript ni desbordamiento horizontal. La automatización usó HTML y recursos locales inyectados en una página de prueba, debido a restricciones del navegador de pruebas para acceder a rutas `file://` y `http://` en este entorno. No equivale a una verificación exhaustiva en equipos móviles reales.

Repetir pruebas con Node (opcional): `node js/test_physics.js`.
Repetir contraste independiente con Python+Node (opcional): `python js/test_independiente.py`.

## Límites y funciones no implementadas

- La simulación acústica es **geométrica**: no resuelve campo de presión, intensidad, amplitud de ondas de choque, reflexión, absorción, viento ni dispersión. La atenuación visual opcional es solo gráfica.
- El cono de Mach se muestra como sección en 2D de una geometría ideal tridimensional. No se infiere un estampido audible por el mero hecho de superar Mach 1.
- El modelo supone trayectorias uniformes y observador **subsónico**; evita ramas con denominadores singulares y no convierte frecuencias negativas en sonidos positivos. No se incorporan aceleraciones arbitrarias ni múltiples cambios de condiciones mientras se propagan ondas antiguas.
- No se integra MathLive ni Monaco Editor ni código Python ejecutable dentro del navegador: no son imprescindibles para estas prácticas y se evitó una superficie de código arbitrario. Python se usa de forma independiente para validar los resultados.
- Las fuentes avanzadas (automóvil, avión) son iconos esquemáticos, no modelos acústicos de motores; el audio tonal es una sonificación con factor 220 y no un sonido original físicamente emitido a 2 Hz.
- No se pudieron comprobar aquí el comportamiento del audio en sistemas reales con altavoces, dispositivos táctiles físicos, todas las variantes de navegador ni la disponibilidad del CDN externo de MathJax. Las funciones fundamentales no lo necesitan.
