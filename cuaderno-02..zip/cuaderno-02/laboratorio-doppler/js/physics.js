/* DopplerPhysics — motor de propagación acústica clásico en 2D, sin DOM.
 * Todas las coordenadas en metros; tiempos en segundos; velocidades en m/s.
 * La primera emisión ocurre en t=0. Una onda emitida conserva su centro.
 * API CommonJS/UMD para pruebas independientes y uso sin conexión.
 */
(function(root,factory){const obj=factory();if(typeof module==='object'&&module.exports)module.exports=obj;root.DopplerPhysics=obj;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const EPS=1e-9;
const v=(x=0,y=0)=>({x:Number(x),y:Number(y)});
const add=(a,b)=>v(a.x+b.x,a.y+b.y);
const sub=(a,b)=>v(a.x-b.x,a.y-b.y);
const mul=(a,k)=>v(a.x*k,a.y*k);
const dot=(a,b)=>a.x*b.x+a.y*b.y;
const norm=a=>Math.hypot(a.x,a.y);
const at=(p,vel,t)=>add(p,mul(vel,t));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function duration(q){return q.durationMode==='periods'?q.periods/q.f:q.duration;}
function validate(q){
 if(!Number.isFinite(q.f)||q.f<=0||!Number.isFinite(q.c)||q.c<=0)throw Error('Frecuencia y rapidez deben ser positivas.');
 if(!(norm(q.vo)<q.c))throw Error('El observador debe moverse más lento que el sonido.');
 if(![q.source,q.observer,q.vs,q.vo].every(p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)))throw Error('Las posiciones y velocidades deben ser finitas.');
 if(!Number.isFinite(duration(q))||duration(q)<=0||duration(q)>120)throw Error('La duración debe estar entre 0 y 120 s.');
 if(q.f*duration(q)>5000)throw Error('Demasiados frentes para este experimento.');
 return true;
}
/* Resuelve A t² + B t + C = 0 con tolerancias relativas y evita cancelación. */
function nonnegativeRoots(A,B,C){
 const scale=Math.max(1,Math.abs(A),Math.abs(B),Math.abs(C));
 if(Math.abs(A)<1e-13*scale){if(Math.abs(B)<1e-13*scale)return Math.abs(C)<1e-13*scale?[0]:[];const t=-C/B;return t>=-EPS?[Math.max(0,t)]:[];}
 const disc=B*B-4*A*C;
 if(disc< -1e-11*(B*B+Math.abs(4*A*C)+1))return [];
 const d=Math.sqrt(Math.max(0,disc));
 const q=-.5*(B+(B>=0?d:-d));
 const roots=q===0?[-B/(2*A)]:[q/A,C/q];
 return roots.filter(x=>Number.isFinite(x)&&x>=-EPS).map(x=>Math.max(0,x)).sort((a,b)=>a-b).filter((x,i,a)=>i===0||Math.abs(x-a[i-1])>1e-8*Math.max(1,x));
}
/* Recepción: |o(te)+vo*tau - s(te)|=c*tau, tau>=0.
 * Única solución si |vo|<c. Independiente de la posición al dibujar.
 */
function receiveTime(cfg,te){
 const d=sub(at(cfg.observer,cfg.vo,te),at(cfg.source,cfg.vs,te));
 if(norm(d)<1e-10)return te;
 const roots=nonnegativeRoots(dot(cfg.vo,cfg.vo)-cfg.c*cfg.c,2*dot(d,cfg.vo),dot(d,d));
 const tau=roots[roots.length-1];
 return tau===undefined?null:te+tau;
}
function waveAt(cfg,n){
 const te=n/cfg.f;
 const center=at(cfg.source,cfg.vs,te);
 const tr=receiveTime(cfg,te);
 return {id:n,te,center,sourceVelocity:v(cfg.vs.x,cfg.vs.y),c:cfg.c,f:cfg.f,tr};
}
function predictionForWave(cfg,w){
 if(w.tr===null||w.tr===undefined)return {kind:'none',value:null};
 const receivePos=at(cfg.observer,cfg.vo,w.tr);
 const direction=sub(receivePos,w.center),len=norm(direction);
 if(len<1e-12)return {kind:'coincident',value:null,n:null};
 const n=mul(direction,1/len);
 const numerator=cfg.c-dot(n,cfg.vo),denominator=cfg.c-dot(n,w.sourceVelocity);
 if(Math.abs(denominator)<=1e-9*cfg.c)return {kind:'singular',value:null,n,numerator,denominator};
 const value=w.f*numerator/denominator;
 return {kind:denominator<0?'inverted':'regular',value,n,numerator,denominator};
}
/* Tiempos retardados t_e de la onda continua que llega en t.
 * Resolver el retardo, en lugar de usar la dirección entre posiciones actuales.
 */
function retardedBranches(cfg,t){
 const ds=sub(at(cfg.observer,cfg.vo,t),at(cfg.source,cfg.vs,t));
 const lagRoots=nonnegativeRoots(dot(cfg.vs,cfg.vs)-cfg.c*cfg.c,2*dot(ds,cfg.vs),dot(ds,ds));
 return lagRoots.map(tau=>({tau,te:t-tau})).filter(x=>x.te>=-EPS&&x.te<=t+EPS).map(x=>{
  const te=clamp(x.te,0,t),emission=at(cfg.source,cfg.vs,te),arrival=at(cfg.observer,cfg.vo,t);
  const d=sub(arrival,emission),len=norm(d);
  if(len<=1e-10)return {...x,te,kind:'coincident',value:null,n:null};
  const n=mul(d,1/len),num=cfg.c-dot(n,cfg.vo),den=cfg.c-dot(n,cfg.vs);
  if(Math.abs(den)<1e-9*cfg.c)return {...x,te,n,kind:'singular',value:null,num,den};
  return {...x,te,n,num,den,kind:den<0?'inverted':'regular',value:cfg.f*num/den};
 }).sort((a,b)=>a.te-b.te);
}
function build(cfg){
 validate(cfg);
 const total=duration(cfg),waves=[];
 const count=Math.floor(total*cfg.f+1e-9);
 for(let n=0;n<=count;n++)waves.push(waveAt(cfg,n));
 const receptions=waves.filter(w=>w.tr!==null&&w.tr<=total+EPS).slice().sort((a,b)=>a.tr-b.tr||a.id-b.id);
 const intervals=receptions.map((w,i)=>{
  const previous=i>0?receptions[i-1]:null;
  const dt=previous?w.tr-previous.tr:null;
  const predicted=predictionForWave(cfg,w);
  return {...w,interval:dt,measured:dt!==null&&dt>1e-7?1/dt:null,predicted};
 });
 return {total,waves,receptions:intervals};
}
function stateAt(cfg,model,time){
 const t=clamp(time,0,model.total);
 const waves=model.waves.filter(w=>w.te<=t+EPS);
 const received=model.receptions.filter(w=>w.tr<=t+EPS);
 const latest=received[received.length-1]||null;
 const branches=retardedBranches(cfg,t);
 const regular=branches.length===1&&branches[0].kind==='regular'?branches[0]:null;
 return {t,waves,received,latest,branches,regular,source:at(cfg.source,cfg.vs,t),observer:at(cfg.observer,cfg.vo,t),separation:norm(sub(at(cfg.observer,cfg.vo,t),at(cfg.source,cfg.vs,t)))};
}
function inWindow(model,from,to){return model.receptions.filter(w=>w.tr>from+EPS&&w.tr<=to+EPS);}
function mach(cfg){const M=norm(cfg.vs)/cfg.c;return {M,mu:M>1?Math.asin(1/M):null};}
function wavelengths(cfg){return {rest:cfg.c/cfg.f,ahead:(cfg.c-cfg.vs.x)/cfg.f,behind:(cfg.c+cfg.vs.x)/cfg.f};}
return {v,add,sub,mul,dot,norm,at,clamp,duration,validate,nonnegativeRoots,receiveTime,waveAt,predictionForWave,retardedBranches,build,stateAt,inWindow,mach,wavelengths};
});
