"""Verificación científica independiente en Python de tiempos, frecuencias y ángulo de Mach.
Ejecutar: python js/test_independiente.py (requiere Node.js para contrastar el motor)."""
import json
import math
import subprocess
from pathlib import Path

script = Path(__file__).with_name('physics.js')
node = r'''
const P=require(process.argv[1]);
const rows=[[0,0],[34,0],[-34,0],[0,-34],[0,34],[34,34]].map(([vs,vo])=>{
const cfg={c:340,f:1000,source:P.v(0,0),observer:P.v(340,0),vs:P.v(vs,0),vo:P.v(vo,0)};
return {vs,vo,tr0:P.receiveTime(cfg,0),tr1:P.receiveTime(cfg,.001)};
});
console.log(JSON.stringify(rows));
'''
raw = subprocess.check_output(['node', '-e', node, str(script)], text=True)
rows = json.loads(raw)
for row in rows:
    vf, vo = row['vs'], row['vo']
    # Cálculo geométrico independiente en 1D, válido sin cruzar objetos.
    tr0 = 340 / (340 - vo)
    tr1 = 0.001 + (340 + (vo - vf) * .001) / (340 - vo)
    theoretical_freq = 1000 * (340 - vo) / (340 - vf)
    assert math.isclose(row['tr0'], tr0, abs_tol=1e-10)
    assert math.isclose(row['tr1'], tr1, abs_tol=1e-10)
    assert math.isclose(1/(row['tr1'] - row['tr0']), theoretical_freq, rel_tol=1e-9)
    print(f"OK vf={vf:>4} m/s, vo={vo:>4} m/s, f={theoretical_freq:.9f} Hz")
assert math.isclose(math.degrees(math.asin(1/2)), 30, abs_tol=1e-12)
print('OK Mach 2: 30 grados, pruebas Python independientes correctas.')
