'use strict';
const assert=require('node:assert/strict');
const P=require('./physics.js');
const approx=(actual,expected,tol=1e-7)=>assert.ok(Math.abs(actual-expected)<=tol*Math.max(1,Math.abs(expected)),`${actual} != ${expected}`);
function config(vs=0,vo=0,d=340,f=1000){return {c:340,f,source:P.v(0,0),observer:P.v(d,0),vs:P.v(vs,0),vo:P.v(vo,0),duration:10,durationMode:'fixed',periods:20};}
const cases=[['Todo en reposo',0,0,1000],['Fuente aproximándose',34,0,1000*340/306],['Fuente alejándose',-34,0,1000*340/374],['Observador aproximándose',0,-34,1100],['Observador alejándose',0,34,900],['Ambos igual velocidad',34,34,1000]];
for(const [name,vs,vo,expected] of cases){const q=config(vs,vo);const first=P.waveAt(q,0),second=P.waveAt(q,1);const dt=second.tr-first.tr;approx(1/dt,expected,4e-10);approx(P.predictionForWave(q,first).value,expected,4e-10);console.log('✓',name,expected.toFixed(9));}
approx(P.receiveTime(config(0,0,340),0),1,1e-10);
approx(P.mach(config(680,0)).mu*180/Math.PI,30,1e-10);
const q=config(34,0,340,2);const m=P.build(q);let previous=0,events=[];for(const now of [0.04,0.1,0.51,1.23,3.5,7.7,10]){events.push(...P.inWindow(m,previous,now));previous=now;}
assert.equal(events.length,m.receptions.length);assert.equal(new Set(events.map(w=>w.id)).size,events.length); // slow frames cannot lose events
approx(P.stateAt(q,m,2).source.x,68);assert.equal(P.stateAt(q,m,0).received.length,0);
const original=m.receptions.map(r=>r.tr);assert.deepEqual(P.build(q).receptions.map(r=>r.tr),original); // deterministic seek/reset
const supers=config(680,0,680,2);supers.duration=6;const sm=P.build(supers);assert.ok(sm.receptions.length>0);assert.ok(sm.receptions.some((e,i)=>i&&e.id<sm.receptions[i-1].id));
for(const r of sm.receptions)assert.ok(Number.isFinite(r.tr)&&r.tr>=r.te);
const col=config(340,0,680,2);col.duration=6;const sonic=P.build(col);assert.ok(sonic.receptions.every(r=>Number.isFinite(r.tr)));
console.log('✓ Tiempo de vuelo 1s, Mach 2=30°, eventos sin duplicar, búsqueda determinista, cambio de orden supersónico, casos degenerados.');
// Independencia de tasa de cuadros: se observan exactamente los mismos eventos.
for(const fps of [30,60,144]){
 let old=0,seen=[];
 const ticks=Math.round(q.duration*fps);
 for(let n=1;n<=ticks;n++){
  const now=n/ticks*q.duration;
  seen.push(...P.inWindow(m,old,now).map(e=>e.id));old=now;
 }
 assert.deepEqual(seen,m.receptions.map(e=>e.id));
 console.log(`✓ Simulación por eventos sin dependencia de ${fps} cuadros/s`);
}
// Los anillos históricos no se mueven al cambiar el tiempo ni al desplazar la cámara.
const anchor=m.waves[2].center;
const snapshotA=P.stateAt(q,m,1).waves[2].center;
const snapshotB=P.stateAt(q,m,8).waves[2].center;
assert.deepEqual(anchor,snapshotA);assert.deepEqual(anchor,snapshotB);
console.log('✓ Centro de emisión inmutable, pausa y zoom sin dependencia de cámara.');
