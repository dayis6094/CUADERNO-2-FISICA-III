/* Laboratorio Doppler · interfaz, Canvas, gráficas, Web Audio y exportación.
   La física reside exclusivamente en physics.js; renderizar no genera eventos. */
(() => {
'use strict';
const P=window.DopplerPhysics;
if(!P){document.body.insertAdjacentHTML('afterbegin','<p role="alert">No se pudo cargar el motor físico.</p>');return;}
const $=(id)=>document.getElementById(id), $$=(sel)=>[...document.querySelectorAll(sel)];
const fmt=(n,d=2)=>Number.isFinite(n)?Number(n).toLocaleString('es-CO',{minimumFractionDigits:d,maximumFractionDigits:d}):'—';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const minmax=(x,a,b)=>Math.max(a,Math.min(b,x));
const INITIAL={f:2,c:340,vsx:0,vsy:0,vox:0,voy:0,sx:-170,sy:0,ox:170,oy:0,duration:10,periods:20,durationMode:'fixed',geometry:'1d'};
const lessons={
 still:{name:'Un punto de partida',objective:'Observar que un medio inmóvil transmite frentes periódicos sin cambiar su separación.',question:'Si se emiten 2 frentes por segundo, ¿qué frecuencia recibe un observador quieto después del primer segundo de vuelo?',procedure:'Reproduce hasta t = 3 s y cuenta cuántos anillos alcanzan el micrófono cada segundo.',why:'Al estar quietos, la fuente emite y el observador recibe un frente cada 0,5 s, después del retraso inicial de 1 s. Su frecuencia es 2 Hz.',answer:'same',values:{}},
 'source-towards':{name:'El emisor se acerca',objective:'Relacionar la compresión del espacio entre anillos con el aumento de frecuencia recibido.',question:'¿Llegarán los frentes más seguidos que cuando la fuente estaba quieta?',procedure:'Observa los frentes delante y detrás. Compara f medida con f teórica después de varias llegadas.',why:'Para la fuente que se acerca a 34 m/s, fₒ = 2·340/(340−34) ≈ 2,222 Hz. La rapidez del sonido sigue siendo 340 m/s.',answer:'increase',values:{vsx:34}},
 'source-away':{name:'El emisor se aleja',objective:'Identificar la dilatación de longitudes de onda detrás de la fuente.',question:'¿Cada cuánto llegan los frentes si la fuente se aleja?',procedure:'Cuenta los eventos y compara el período observado con 0,5 s.',why:'Una fuente que se aleja a 34 m/s genera detrás λ=(340+34)/2=187 m y fₒ≈1,818 Hz.',answer:'decrease',values:{vsx:-34}},
 'observer-towards':{name:'El micrófono se aproxima',objective:'Distinguir el Doppler debido al movimiento del observador del debido a la fuente.',question:'¿Aumentan las llegadas aunque los anillos sigan separados 170 m?',procedure:'Fija la vista y sigue el micrófono; compara el intervalo entre llegadas.',why:'El observador se mueve contra los frentes: fₒ = 2(340+34)/340 = 2,2 Hz. La separación espacial de frentes no cambia.',answer:'increase',values:{vox:-34}},
 'observer-away':{name:'El micrófono se aleja',objective:'Comprender que un observador móvil puede recibir menos frentes sin alterar λ.',question:'¿Qué ocurre con el ritmo de recepción si el observador huye de los frentes?',procedure:'Observa cómo cambia Δt entre recepciones; contrasta con λ₀.',why:'fₒ = 2(340−34)/340 = 1,8 Hz. La longitud de onda en el medio sigue siendo 170 m.',answer:'decrease',values:{vox:34}},
 together:{name:'Ambos a igual velocidad',objective:'Comprobar la frecuencia cuando fuente y observador mantienen la distancia.',question:'Si se desplazan a +34 m/s juntos, ¿se conserva la frecuencia medida?',procedure:'Observa la distancia y la frecuencia. Distingue la separación entre objetos de la separación de los frentes.',why:'La distancia se mantiene y el factor (c−34)/(c−34) vale 1, por lo que fₒ=f=2 Hz; el tiempo de vuelo inicial difiere de 1 s.',answer:'same',values:{vsx:34,vox:34}},
 lateral:{name:'Una fuente pasa de lado',objective:'Explorar que la dirección retardada importa al calcular el Doppler bidimensional.',question:'Al pasar lateralmente, ¿la frecuencia recibida es siempre la misma?',procedure:'Observa los vectores y la gráfica de frecuencia antes y después del punto de aproximación.',why:'La proyección n·vf cambia de signo conforme la fuente pasa. La frecuencia de recepción sube durante la aproximación y baja después; la dirección correcta usa posiciones de emisión y recepción.',answer:'vary',values:{geometry:'2d',sx:-340,sy:130,ox:0,oy:0,vsx:80,duration:10}},
 sonic:{name:'El límite Mach 1',objective:'Reconocer que el régimen sónico requiere un tratamiento distinto de la fórmula escolar.',question:'Cuando la fuente viaja a c en la dirección del observador, ¿tiene sentido una frecuencia audible infinita?',procedure:'Observa la concentración geométrica delante de la fuente y abre Eventos.',why:'En el límite sónico pueden coincidir frentes y aparecer una singularidad formal. No se interpreta como frecuencia audible infinita; solo se dibuja geometría de emisión y llegada.',answer:'branches',values:{sx:-680,ox:0,vsx:340,duration:6}},
 supersonic:{name:'Más rápido que el sonido',objective:'Visualizar Mach 2, la envolvente y el orden de recepciones no necesariamente igual al de emisión.',question:'¿Podría recibir primero una emisión posterior y después una anterior?',procedure:'Mueve el tiempo y consulta Eventos. Busca los rayos de la envolvente con μ=30°.',why:'Con M=2 se forma una sección del cono de Mach de 30°. Hay ramas retardadas, inversión y acumulaciones de recepción. El dibujo no calcula presiones ni intensidad del choque.',answer:'branches',values:{sx:-680,ox:0,vsx:680,duration:6}}
};
let pending={...INITIAL},cfg=null,model=null,t=0,playing=false,lastFrame=null,rate=1,level='explore',selectedId=null,activeTab='graph',currentScenario='still';
let showGrid=true,showVectors=true,followSource=false,measureMode=false;
let waveStyle={color:'#2687b5',width:2,dash:'solid',fade:false},sourceIcon='point',audioCtx=null,activeAudio=[],audioEnabled=false;
let timelineVersion=0,flashUntil=0,toastTimer=0,tabRenderAt=0,drag=null;
const scene=$('scene'),ctx=scene.getContext('2d'),plot=$('plot'),pctx=plot.getContext('2d');
const cam={cx:0,cy:0,scale:1,width:1,height:1};
const pointerMap=new Map();
function makeCfg(data){const q={f:Number(data.f),c:Number(data.c),vs:P.v(+data.vsx,data.geometry==='2d'?+data.vsy:0),vo:P.v(+data.vox,data.geometry==='2d'?+data.voy:0),source:P.v(+data.sx,data.geometry==='2d'?+data.sy:0),observer:P.v(+data.ox,data.geometry==='2d'?+data.oy:0),durationMode:data.durationMode,duration:+data.duration,periods:+data.periods};P.validate(q);if(q.f<.5||q.f>5||q.c<100||q.c>500)throw Error('Dominio visual: f entre 0,5 y 5 Hz; c entre 100 y 500 m/s.');if(P.norm(q.vs)>2*q.c+1e-8)throw Error('La rapidez de la fuente debe ser ≤ 2c.');if(P.norm(q.vo)>.8*q.c+1e-8)throw Error('La rapidez del observador debe ser ≤ 0,8c.');if(q.durationMode==='fixed'&&(q.duration<1||q.duration>60))throw Error('La duración fija debe estar entre 1 y 60 s.');if(q.durationMode==='periods'&&(q.periods<1||q.periods>50))throw Error('Selecciona de 1 a 50 períodos.');return q;}
function alertToast(text){const el=$('toast');el.textContent=text;el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),3000);}
function setDirty(flag){$('pending-msg').classList.toggle('dirty',flag);$('pending-msg').textContent=flag?'Cambios pendientes · Aplicar para reiniciar':'Parámetros actuales aplicados';}
function initRanges(){const c=Math.max(100,Number(pending.c)||340);const max=(k,min,max)=>{const ranges=$$(`input[data-kind="range"][data-key="${k}"]`);ranges.forEach(e=>{e.min=String(min);e.max=String(max);});const numbers=$$(`input[data-kind="number"][data-key="${k}"]`);numbers.forEach(e=>{e.min=String(min);e.max=String(max);});};max('vsx',-2*c,2*c);max('vsy',-2*c,2*c);max('vox',-.8*c,.8*c);max('voy',-.8*c,.8*c);}
function showConfig(){initRanges();for(const [k,val] of Object.entries(pending)){if(k==='durationMode'||k==='geometry')continue;$$(`[data-key="${k}"]`).forEach(el=>{el.value=String(val);});}$('duration-mode').value=pending.durationMode;$('geometry').value=pending.geometry;$$('[data-2d]').forEach(x=>x.hidden=pending.geometry!=='2d');$$('[data-field="duration"]').forEach(x=>x.hidden=pending.durationMode!=='fixed');$$('[data-field="periods"]').forEach(x=>x.hidden=pending.durationMode!=='periods');}
function setLevel(value){level=value;$('app').classList.toggle('advanced',value==='advanced');$$('[data-level]').forEach(b=>b.classList.toggle('selected',b.dataset.level===value));resizeCanvases();drawAll();}
function defaultView(){cam.cx=(cfg.source.x+cfg.observer.x)/2;cam.cy=(cfg.source.y+cfg.observer.y)/2;cam.scale=Math.min(cam.width/1080,cam.height/650);drawAll();}
function fitScene(){const s=P.at(cfg.source,cfg.vs,t),o=P.at(cfg.observer,cfg.vo,t),maxRadius=Math.min(cfg.c*(2/cfg.f),cfg.c*2);const pad=130;
 const minX=Math.min(s.x,o.x)-maxRadius-pad,maxX=Math.max(s.x,o.x)+maxRadius+pad,minY=Math.min(s.y,o.y)-maxRadius*.55-pad,maxY=Math.max(s.y,o.y)+maxRadius*.55+pad;
 cam.cx=(minX+maxX)/2;cam.cy=(minY+maxY)/2;cam.scale=minmax(Math.min(cam.width/Math.max(1,maxX-minX),cam.height/Math.max(1,maxY-minY)),.004,15);drawAll();}
function buildExperiment(resetView=true){
 let candidate;
 try{candidate=makeCfg(pending);}catch(error){alertToast(error.message);$('pending-msg').textContent=error.message;return false;}
 cfg=candidate;model=P.build(cfg);pause();t=0;selectedId=null;timelineVersion++;flashUntil=0;setDirty(false);
 $('time-slider').max=String(model.total);$('time-slider').step=String(1/(cfg.f*Number($('subdivision').value)));$('time-slider').value='0';
 if(resetView)defaultView();updateScreen();drawAll();return true;
}
function setPending(k,value){const num=Number(value);if(!Number.isFinite(num))return;pending[k]=num;if(k==='c')initRanges();$$(`[data-key="${k}"]`).forEach(el=>{if(el!==document.activeElement||el.type==='range')el.value=String(num);});setDirty(true);}
$$('input[data-key]').forEach(el=>el.addEventListener(el.type==='range'?'input':'change',()=>setPending(el.dataset.key,el.value)));
$('geometry').addEventListener('change',e=>{pending.geometry=e.target.value;if(pending.geometry==='1d'){pending.sy=0;pending.oy=0;pending.vsy=0;pending.voy=0;}showConfig();setDirty(true);});
$('duration-mode').addEventListener('change',e=>{pending.durationMode=e.target.value;showConfig();setDirty(true);});
$('apply-btn').addEventListener('click',()=>buildExperiment(true));
function applyScenario(id){const lesson=lessons[id];if(!lesson)return;currentScenario=id;pending={...INITIAL,...lesson.values};showConfig();buildExperiment(true);$('scenario').value=id;$('lesson-tag').textContent='LECCIÓN '+String(Object.keys(lessons).indexOf(id)+1).padStart(2,'0');$('lesson-title').textContent=lesson.name;$('lesson-objective').textContent=lesson.objective;$('lesson-question').textContent=lesson.question;$('lesson-procedure').textContent=lesson.procedure;$('lesson-explanation').textContent=lesson.why;$('lesson-answer').value='';$('answer-feedback').textContent='';$('lesson-check-label').textContent='Comprueba tu predicción';}
$('scenario').addEventListener('change',e=>applyScenario(e.target.value));
$('check-answer').addEventListener('click',()=>{const a=$('lesson-answer').value;if(!a){$('answer-feedback').textContent='Selecciona una respuesta.';return;}$('answer-feedback').textContent=a===lessons[currentScenario].answer?'✓ Correcto. '+lessons[currentScenario].why:'Intenta de nuevo: revisa las llegadas y abre «Ver explicación».';});
$$('[data-level]').forEach(b=>b.addEventListener('click',()=>setLevel(b.dataset.level)));
function pause(){playing=false;lastFrame=null;$('play-btn').textContent='▶ Reproducir';stopSounds();}
function play(){if(t>=model.total-1e-9){t=0;updateScreen();}playing=true;lastFrame=null;$('play-btn').textContent='Ⅱ Pausar';}
$('play-btn').addEventListener('click',()=>playing?pause():play());
$('restart-btn').addEventListener('click',()=>{pause();seekTo(0);});
$('step-btn').addEventListener('click',()=>{pause();seekTo(t+1/(cfg.f*Number($('subdivision').value)));});
$('period-btn').addEventListener('click',()=>{pause();seekTo(t+1/cfg.f);});
$('time-slider').addEventListener('input',e=>{pause();seekTo(Number(e.target.value));});
$('subdivision').addEventListener('change',()=>{$('time-slider').step=String(1/(cfg.f*Number($('subdivision').value)));});
$('playback').addEventListener('change',e=>{rate=Number(e.target.value);});
function seekTo(value){t=minmax(Number(value)||0,0,model.total);flashUntil=0;updateScreen();drawAll();}
function receiveStatus(st){const M=P.mach(cfg).M;
 if(M>1+1e-7)return 'Supersónico · M '+fmt(M,2);
 if(Math.abs(M-1)<=1e-7)return 'Régimen sónico · Mach 1';
 if(M>1e-6)return 'Subsónico · M '+fmt(M,2);
 return (P.norm(cfg.vo)>1e-6?'Observador móvil':'En reposo');
}
function latestFrequency(st){const b=st.regular;return b&&Number.isFinite(b.value)&&b.value>0?b.value:null;}
function updateScreen(){
 const st=P.stateAt(cfg,model,t);const M=P.mach(cfg);
 $('clock-top').textContent=fmt(t,3);$('clock-bottom').textContent=`${fmt(t,3)} / ${fmt(model.total,3)} s`;$('time-slider').value=String(t);
 $('motion-label').textContent=receiveStatus(st);
 $('metric-emitted').textContent=fmt(cfg.f,2);$('metric-period').textContent=fmt(1/cfg.f,3)+' s';
 const f0=latestFrequency(st);
 $('metric-theory').textContent=f0!==null?fmt(f0,3):'—';
 $('metric-pred-note').textContent=f0!==null?'Rama retardada regular':st.branches.length>1?'Varias ramas retardadas':st.branches[0]?.kind==='singular'?'Singularidad · no es un tono infinito':st.branches[0]?.kind==='inverted'?'Rama invertida · no usar |f|':'Esperando llegada';
 $('metric-measured').textContent=st.latest?.measured!==null&&st.latest?.measured!==undefined?fmt(st.latest.measured,3):'—';
 $('metric-measure-note').textContent=st.latest?.interval!==null&&st.latest?.interval!==undefined?(st.latest.interval>1e-7?`Δt = ${fmt(st.latest.interval,4)} s`:'Llegadas simultáneas; intervalo cero'):'Esperando dos llegadas';
 $('metric-count').textContent=String(st.received.length);
 $('metric-flight').textContent=`Primera llegada: ${model.receptions.length?fmt(model.receptions[0].tr,3)+' s':'fuera del experimento'}`;
 $('lambda-rest').textContent=fmt(cfg.c/cfg.f,2)+' m';$('mach-value').textContent=fmt(M.M,3);
 $('distance-value').textContent=fmt(st.separation,2)+' m';
 const recent=st.latest&&t-st.latest.tr<=.10+1e-8;
 $('scene-status').textContent=recent?`● Llegada de frente #${st.latest.id} · ${fmt(st.latest.tr,3)} s`:st.received.length===0?'Esperando llegada':st.branches.length>1?'Hay múltiples ramas de emisión':M.M>=1?'Geometría sónica/supersónica':'Frentes propagándose en el medio';
 if(activeTab==='inspect')updateInspector();
 if(activeTab==='math')updateMath(st);
 if(activeTab==='events'&&Date.now()-tabRenderAt>180)updateEvents();
}
function advance(now){
 if(lastFrame===null)lastFrame=now;
 if(playing){const previous=t;const dt=Math.max(0,(now-lastFrame)/1000)*rate;t=minmax(t+dt,0,model.total);
 if(t>previous){const events=P.inWindow(model,previous,t);if(events.length){flashUntil=now+170;playArrivalEvents(events,previous,rate);}updateScreen();}
 if(t>=model.total-1e-9){pause();alertToast('Fin del experimento. Reinicia o busca otro instante.');}
 }lastFrame=now;
 if(followSource&&!drag){const st=P.stateAt(cfg,model,t);cam.cx=st.source.x;cam.cy=st.source.y;}
 drawScene();if(level==='advanced'&&activeTab==='graph')drawPlot();
 requestAnimationFrame(advance);
}
function px(x){return cam.width/2+(x-cam.cx)*cam.scale;}
function py(y){return cam.height/2-(y-cam.cy)*cam.scale;}
function wp(x){return cam.cx+(x-cam.width/2)/cam.scale;}
function wpy(y){return cam.cy-(y-cam.height/2)/cam.scale;}
function resizeOne(canvas,context){const r=canvas.getBoundingClientRect(),ratio=Math.min(window.devicePixelRatio||1,2.5),w=Math.max(1,Math.round(r.width)),h=Math.max(1,Math.round(r.height));if(canvas.width!==Math.round(w*ratio)||canvas.height!==Math.round(h*ratio)){canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);}context.setTransform(ratio,0,0,ratio,0,0);return {w,h};}
function resizeCanvases(){const oldW=cam.width,dim=resizeOne(scene,ctx);cam.width=dim.w;cam.height=dim.h;if(!cfg)cam.scale=Math.max(.01,dim.w/1100);else if(oldW!==dim.w&&oldW>1)cam.scale*=dim.w/oldW;resizeOne(plot,pctx);drawAll();}
function tickScale(){const raw=75/cam.scale,p=Math.pow(10,Math.floor(Math.log10(raw))),v=raw/p;return (v<=1?1:v<=2?2:v<=5?5:10)*p;}
function canvasBackground(){const dark=document.documentElement.dataset.theme==='dark';ctx.fillStyle=dark?'#142b3c':'#f8fbfd';ctx.fillRect(0,0,cam.width,cam.height);
 if(!showGrid)return;
 const step=tickScale(),left=wp(0),right=wp(cam.width),bottom=wpy(cam.height),top=wpy(0);
 ctx.lineWidth=1;ctx.strokeStyle=dark?'#2b4354':'#e6eff4';ctx.beginPath();
 for(let x=Math.ceil(left/step)*step;x<=right+step*.01;x+=step){const z=px(x);ctx.moveTo(z,0);ctx.lineTo(z,cam.height);}
 for(let y=Math.ceil(bottom/step)*step;y<=top+step*.01;y+=step){const z=py(y);ctx.moveTo(0,z);ctx.lineTo(cam.width,z);}ctx.stroke();
 ctx.strokeStyle=dark?'#56738b':'#b7cdd9';ctx.lineWidth=1.25;ctx.beginPath();const x0=px(0),y0=py(0);ctx.moveTo(x0,0);ctx.lineTo(x0,cam.height);ctx.moveTo(0,y0);ctx.lineTo(cam.width,y0);ctx.stroke();
 ctx.fillStyle=dark?'#89adbd':'#8ba5b4';ctx.font='10px Segoe UI,Arial';ctx.textAlign='left';
 for(let x=Math.ceil(left/step)*step;x<=right;x+=step)if(Math.abs(x)>step*.1){let z=px(x);if(z>20&&z<cam.width-50)ctx.fillText(`${fmt(x,0)} m`,z+3,minmax(y0+13,13,cam.height-5));}
 for(let y=Math.ceil(bottom/step)*step;y<=top;y+=step)if(Math.abs(y)>step*.1){let z=py(y);if(z>14&&z<cam.height-8)ctx.fillText(`${fmt(y,0)}`,minmax(x0+4,4,cam.width-43),z-3);}
 ctx.fillText(`Escala: ${fmt(step,0)} m / división`,14,cam.height-42);
}
function drawArrow(from,vel,color,label){const n=P.norm(vel);if(n<1e-8)return;const a=px(from.x),b=py(from.y),len=minmax(20+Math.log1p(n)*12,25,93),ux=vel.x/n,uy=vel.y/n,ex=a+ux*len,ey=b-uy*len;
 ctx.save();ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(a,b);ctx.lineTo(ex,ey);ctx.stroke();const ang=Math.atan2(ey-b,ex-a);ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(ex-10*Math.cos(ang-.45),ey-10*Math.sin(ang-.45));ctx.lineTo(ex-10*Math.cos(ang+.45),ey-10*Math.sin(ang+.45));ctx.closePath();ctx.fill();ctx.font='700 11px Segoe UI,Arial';ctx.fillText(`${label} ${fmt(n,1)} m/s`,ex+4,ey-7);ctx.restore();}
function drawMarker(pos,type,velocity){const x=px(pos.x),y=py(pos.y),c=type==='source'?'#e9893a':'#159c92';ctx.save();ctx.translate(x,y);ctx.shadowColor=c+'55';ctx.shadowBlur=17;ctx.fillStyle=c;ctx.strokeStyle='#fff';ctx.lineWidth=3;
 if(type==='source'&&sourceIcon==='car'){ctx.fillRect(-20,-8,40,17);ctx.fillRect(-10,-17,19,12);ctx.beginPath();ctx.arc(-13,10,5,0,Math.PI*2);ctx.arc(13,10,5,0,Math.PI*2);ctx.fill();}
 else if(type==='source'&&sourceIcon==='plane'){ctx.beginPath();ctx.moveTo(25,0);ctx.lineTo(-4,-5);ctx.lineTo(-15,-22);ctx.lineTo(-21,-20);ctx.lineTo(-16,0);ctx.lineTo(-21,20);ctx.lineTo(-15,22);ctx.lineTo(-4,5);ctx.closePath();ctx.fill();ctx.stroke();}
 else if(type==='observer'){ctx.beginPath();ctx.roundRect(-8,-17,16,22,8);ctx.fill();ctx.stroke();ctx.strokeStyle=c;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,1,13,0,Math.PI);ctx.stroke();ctx.beginPath();ctx.moveTo(0,14);ctx.lineTo(0,20);ctx.moveTo(-8,20);ctx.lineTo(8,20);ctx.stroke();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(0,-6,3,0,Math.PI*2);ctx.fill();}
 else{ctx.beginPath();ctx.arc(0,0,10,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(0,0,3.2,0,Math.PI*2);ctx.fill();}
 ctx.restore();ctx.font='750 11px Segoe UI,Arial';ctx.fillStyle=c;ctx.textAlign='center';ctx.fillText(type==='source'?'FUENTE':'OBSERVADOR',x,y+35);if(showVectors)drawArrow(pos,velocity,c,type==='source'?'vf':'vo');}
function drawMach(st){const {M,mu}=P.mach(cfg);if(!(M>1+1e-8)||t===0)return;const direction=P.mul(cfg.vs,1/P.norm(cfg.vs)),back=P.mul(direction,-1);const length=(P.norm(cfg.vs)-cfg.c*cfg.c/P.norm(cfg.vs))*t/Math.cos(mu),s=st.source;ctx.save();ctx.lineWidth=2;ctx.setLineDash([8,6]);ctx.strokeStyle='#d55d36';ctx.fillStyle='#d55d36';const angle=Math.atan2(back.y,back.x);for(const sign of [-1,1]){const a=angle+sign*mu;const end=P.add(s,P.v(Math.cos(a)*length,Math.sin(a)*length));ctx.beginPath();ctx.moveTo(px(s.x),py(s.y));ctx.lineTo(px(end.x),py(end.y));ctx.stroke();}ctx.setLineDash([]);ctx.font='700 11px Segoe UI,Arial';ctx.fillText(`Mach ${fmt(M,2)} · μ = ${fmt(mu*180/Math.PI,1)}° (sección 2D)`,15,62);ctx.restore();}
function drawMeasurement(){if(!drag||drag.mode!=='measure')return;const {a,b}=drag;if(!a||!b)return;ctx.save();ctx.strokeStyle='#b26c2a';ctx.lineWidth=2;ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(px(a.x),py(a.y));ctx.lineTo(px(b.x),py(b.y));ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#ab6c2a';ctx.font='700 12px Segoe UI,Arial';ctx.fillText(`${fmt(P.norm(P.sub(a,b)),2)} m`,(px(a.x)+px(b.x))/2+8,(py(a.y)+py(b.y))/2-9);ctx.restore();}
function drawWavelength(st){if(cfg.vs.y!==0||cfg.vo.y!==0||cfg.vs.x<=-cfg.c||cfg.vs.x>=cfg.c)return;
 if(st.waves.length<3)return;
 const a=st.waves[st.waves.length-1],b=st.waves[st.waves.length-2];
 const currentR=cfg.c*(t-a.te),priorR=cfg.c*(t-b.te);if(currentR<0||priorR<0)return;
 const ahead1=a.center.x+currentR,ahead2=b.center.x+priorR;const y=st.source.y-70;
 ctx.save();ctx.strokeStyle='#bc812b';ctx.lineWidth=1.5;ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(px(ahead1),py(y));ctx.lineTo(px(ahead2),py(y));ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#a77523';ctx.font='700 11px Segoe UI,Arial';ctx.textAlign='center';ctx.fillText(`λ frente = ${fmt(Math.abs(ahead1-ahead2),1)} m`,(px(ahead1)+px(ahead2))/2,py(y)-8);ctx.restore();}
function drawScene(){if(!cfg)return;const dim=resizeOne(scene,ctx);cam.width=dim.w;cam.height=dim.h;
 canvasBackground();const st=P.stateAt(cfg,model,t),dark=document.documentElement.dataset.theme==='dark';
 const active=st.waves;
 ctx.save();ctx.strokeStyle=waveStyle.color;ctx.lineWidth=waveStyle.width;ctx.setLineDash(waveStyle.dash==='dashed'?[11,8]:waveStyle.dash==='dotted'?[1,6]:[]);
 for(const w of active){const r=cfg.c*(t-w.te),sr=r*cam.scale;if(sr<0||sr>1e7)continue;
 const x=px(w.center.x),y=py(w.center.y);if(x+sr<0||x-sr>cam.width||y+sr<0||y-sr>cam.height)continue;
 ctx.globalAlpha=waveStyle.fade?Math.max(.13,Math.min(.92,320/(320+r))):.75;
 ctx.lineWidth=selectedId===w.id?Math.max(3,waveStyle.width+1.5):waveStyle.width;
 if(selectedId===w.id){ctx.globalAlpha=1;ctx.strokeStyle='#f2a434';}ctx.beginPath();ctx.arc(x,y,sr,0,Math.PI*2);ctx.stroke();ctx.strokeStyle=waveStyle.color;
 }ctx.restore();
 drawMach(st);drawWavelength(st);drawMarker(st.source,'source',cfg.vs);drawMarker(st.observer,'observer',cfg.vo);drawMeasurement();
 if(st.latest&&t-st.latest.tr<.15&&t-st.latest.tr>=-1e-8){ctx.save();ctx.strokeStyle='#f09d43';ctx.lineWidth=3.5;ctx.globalAlpha=1-Math.max(0,t-st.latest.tr)/.15;ctx.beginPath();ctx.arc(px(st.observer.x),py(st.observer.y),23+60*Math.max(0,t-st.latest.tr),0,Math.PI*2);ctx.stroke();ctx.restore();}
 ctx.save();ctx.textAlign='right';ctx.fillStyle=dark?'#8cadbe':'#6c8897';ctx.font='10px Segoe UI,Arial';ctx.fillText('Todas las coordenadas y radios en metros',cam.width-12,cam.height-12);ctx.restore();
}
function drawAll(){if(!cfg)return;drawScene();if(level==='advanced'&&activeTab==='graph')drawPlot();}
function clientPoint(e){const r=scene.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
function zoomAt(factor,x=cam.width/2,y=cam.height/2){const before=P.v(wp(x),wpy(y));cam.scale=minmax(cam.scale*factor,.003,40);cam.cx=before.x-(x-cam.width/2)/cam.scale;cam.cy=before.y+(y-cam.height/2)/cam.scale;drawAll();}
scene.addEventListener('wheel',e=>{e.preventDefault();const p=clientPoint(e);zoomAt(Math.exp(-e.deltaY*.0015),p.x,p.y);},{passive:false});
$('zoom-in').onclick=()=>zoomAt(1.25);$('zoom-out').onclick=()=>zoomAt(.8);$('reset-view').onclick=()=>defaultView();$('fit-scene').onclick=()=>fitScene();
$('measure-btn').onclick=()=>{measureMode=!measureMode;$('measure-btn').classList.toggle('active',measureMode);$('measure-btn').setAttribute('aria-pressed',String(measureMode));alertToast(measureMode?'Arrastra en el plano para medir una distancia.':'Modo medición desactivado.');};
function hitTarget(p){const st=P.stateAt(cfg,model,t),src=Math.hypot(px(st.source.x)-p.x,py(st.source.y)-p.y),obs=Math.hypot(px(st.observer.x)-p.x,py(st.observer.y)-p.y);return Math.min(src,obs)<27?(src<obs?'source':'observer'):null;}
function pickWave(p){const st=P.stateAt(cfg,model,t);let best=null,dist=11;for(const w of st.waves){const d=Math.abs(Math.hypot(p.x-px(w.center.x),p.y-py(w.center.y))-cfg.c*(t-w.te)*cam.scale);if(d<dist){best=w;dist=d;}}return best;}
scene.addEventListener('pointerdown',e=>{const p=clientPoint(e);pointerMap.set(e.pointerId,p);try{scene.setPointerCapture(e.pointerId);}catch{}
 if(pointerMap.size===2){drag={mode:'pinch',initial:[...pointerMap.values()],scale:cam.scale,center:P.v(cam.cx,cam.cy)};return;}
 const target=!measureMode?hitTarget(p):null;
 if(target&&playing){alertToast('Pausa antes de recolocar una fuente o un observador.');return;}
 drag=target?{mode:'object',target,start:p,moved:false}:measureMode?{mode:'measure',a:P.v(wp(p.x),wpy(p.y)),b:P.v(wp(p.x),wpy(p.y))}:{mode:'pan',start:p,cx:cam.cx,cy:cam.cy,moved:false};
});
scene.addEventListener('pointermove',e=>{if(!pointerMap.has(e.pointerId))return;const p=clientPoint(e);pointerMap.set(e.pointerId,p);
 if(!drag)return;
 if(drag.mode==='pinch'&&pointerMap.size>=2){const pts=[...pointerMap.values()],old=drag.initial,dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),factor=dist(pts[0],pts[1])/Math.max(1,dist(old[0],old[1]));const mid=P.v((pts[0].x+pts[1].x)/2,(pts[0].y+pts[1].y)/2);cam.scale=drag.scale;cam.cx=drag.center.x;cam.cy=drag.center.y;zoomAt(factor,mid.x,mid.y);return;}
 if(drag.mode==='pan'){drag.moved||=Math.hypot(p.x-drag.start.x,p.y-drag.start.y)>5;cam.cx=drag.cx-(p.x-drag.start.x)/cam.scale;cam.cy=drag.cy+(p.y-drag.start.y)/cam.scale;}
 if(drag.mode==='measure')drag.b=P.v(wp(p.x),wpy(p.y));
 if(drag.mode==='object'){drag.moved||=Math.hypot(p.x-drag.start.x,p.y-drag.start.y)>4;const a=P.v(wp(p.x),pending.geometry==='1d'?0:wpy(p.y));const kind=drag.target;if(kind==='source'){pending.sx=a.x;pending.sy=a.y;}else{pending.ox=a.x;pending.oy=a.y;}
  if(drag.moved){const next=makeCfg(pending);cfg=next;model=P.build(cfg);t=0;setDirty(false);showConfig();updateScreen();}}
 drawAll();
});
function stopPointer(e){const last=drag;const p=clientPoint(e);pointerMap.delete(e.pointerId);if(pointerMap.size>=1&&last?.mode==='pinch'){drag=null;return;}
 drag=null;if(last?.mode==='measure'&&last.a&&last.b){const d=P.norm(P.sub(last.a,last.b));if(d>0.01)alertToast('Distancia medida: '+fmt(d,2)+' m');}
 if(last?.mode==='pan'&&!last.moved){const w=pickWave(p);if(w){selectedId=w.id;setLevel('advanced');setTab('inspect');updateInspector();alertToast(`Frente #${w.id} seleccionado`);}}
 if(last?.mode==='object'&&last.moved){pause();model=P.build(cfg);t=0;updateScreen();}
 drawAll();}
scene.addEventListener('pointerup',stopPointer);scene.addEventListener('pointercancel',e=>{pointerMap.delete(e.pointerId);drag=null;});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('theory-dialog').open){$('theory-dialog').close();return;}if(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName)||e.ctrlKey||e.metaKey)return;if(e.code==='Space'){e.preventDefault();playing?pause():play();}if(e.key==='ArrowRight'){e.preventDefault();pause();seekTo(t+1/(cfg.f*Number($('subdivision').value)));}if(e.key==='ArrowLeft'){e.preventDefault();pause();seekTo(t-1/(cfg.f*Number($('subdivision').value)));}});
function setTab(name){activeTab=name;$$('[data-data-tab]').forEach(b=>{b.classList.toggle('selected',b.dataset.dataTab===name);b.setAttribute('aria-selected',String(b.dataset.dataTab===name));});$$('[data-tab-panel]').forEach(el=>el.hidden=el.dataset.tabPanel!==name);
 if(name==='events')updateEvents();if(name==='inspect')updateInspector();if(name==='math'){updateMath(P.stateAt(cfg,model,t));typesetStaticMath();}if(name==='graph')drawPlot();}
$$('[data-data-tab]').forEach(b=>b.onclick=()=>setTab(b.dataset.dataTab));
function updateEvents(){tabRenderAt=Date.now();let out='';for(const w of model.waves){const arrived=w.tr!==null&&w.tr<=t+1e-9;out+=`<tr><td>#${w.id}</td><td>${fmt(w.te,4)}</td><td>${w.tr!==null?fmt(w.tr,4):'—'}</td><td>${arrived&&w.tr!==null?fmt(model.receptions.find(r=>r.id===w.id)?.interval,4):'—'}</td><td>${arrived?'Recibido':w.te<=t?'En propagación':'Por emitir'}</td></tr>`;}$('event-table').innerHTML=out;}
function updateInspector(){const w=model.waves.find(w=>w.id===selectedId);if(!w){$('inspect-panel').textContent='Selecciona un anillo de la escena para ver cuándo y dónde nació y cuándo llega al observador.';return;}const tr=w.tr,pred=P.predictionForWave(cfg,w),received=tr!==null&&tr<=t+1e-9;
 $('inspect-panel').innerHTML=`<h3>Frente #${w.id}</h3><dl><dt>Emisión</dt><dd>${fmt(w.te,4)} s</dd><dt>Centro físico</dt><dd>(${fmt(w.center.x,2)}, ${fmt(w.center.y,2)}) m</dd><dt>Radio actual</dt><dd>${w.te<=t?fmt(cfg.c*(t-w.te),2)+' m':'Aún no emitido'}</dd><dt>Llegada calculada</dt><dd>${tr===null?'No existe':fmt(tr,4)+' s'}</dd><dt>Recepción</dt><dd>${received?'Recibido':'Pendiente'}</dd><dt>Frecuencia por rama</dt><dd>${pred.kind==='regular'?fmt(pred.value,4)+' Hz':pred.kind}</dd></dl><p>El centro permanece inmóvil en el medio. Haz clic en otro frente para comparar su origen y tiempo de vuelo.</p>`;}

let didRenderMath=false;
function typesetStaticMath(){
 if(didRenderMath||!window.MathJax?.typesetPromise)return;
 const node=$('math-static-latex');
 if(!node)return;
 window.MathJax.typesetPromise([node]).then(()=>{didRenderMath=true;node.classList.add('math-ready');}).catch(()=>{});
}

function updateMath(st){const m=P.mach(cfg),b=st.branches[0],wl=P.wavelengths(cfg),regular=st.regular;const n=b?.n??P.v(0,0),num=regular?.num,den=regular?.den;
 $('math-panel').innerHTML=`<h3>Ecuaciones físicas</h3><div class="equation">t<sub>e,n</sub> = n/f &nbsp; · &nbsp; r<sub>n</sub>(t) = c(t−t<sub>e,n</sub>) &nbsp; · &nbsp; T = 1/f</div><p>La primera emisión ocurre en t = 0 s; cada centro queda en x<sub>f</sub>(t<sub>e</sub>), fijo respecto al medio. El observador recibe cuando |x<sub>o</sub>(t<sub>r</sub>)−x<sub>f</sub>(t<sub>e</sub>)|=c(t<sub>r</sub>−t<sub>e</sub>).</p><div class="equation">f<sub>o</sub> = f · (c − n·v<sub>o</sub>) / (c − n·v<sub>f</sub>)</div><p>n apunta desde la fuente cuando <em>emitió</em> hacia el observador cuando <em>recibió</em>. El producto n·v es positivo en la dirección de propagación. La fórmula requiere una rama retardada regular.</p><div class="substitution"><strong>Datos:</strong> f=${fmt(cfg.f,3)} Hz · c=${fmt(cfg.c,3)} m/s · |v<sub>f</sub>|=${fmt(P.norm(cfg.vs),3)} m/s · |v<sub>o</sub>|=${fmt(P.norm(cfg.vo),3)} m/s.<br><strong>Resultado:</strong> ${regular?`${fmt(cfg.f,3)} × (${fmt(cfg.c,3)} − (${fmt(P.dot(n,cfg.vo),3)})) / (${fmt(cfg.c,3)} − (${fmt(P.dot(n,cfg.vs),3)})) = ${fmt(regular.value,4)} Hz`:'No existe una única rama retardada regular en este instante.'}</div><h3>Longitudes de onda en el medio</h3><div class="equation">λ₀ = c/f = ${fmt(wl.rest,3)} m</div><p>${cfg.vs.y===0&&P.norm(cfg.vs)<cfg.c?`Para la fuente subsónica con movimiento +x: λ delante=(c−v<sub>f,x</sub>)/f=${fmt(wl.ahead,3)} m; λ detrás=(c+v<sub>f,x</sub>)/f=${fmt(wl.behind,3)} m.`:'Las expresiones frente/detrás sobre x solo son directamente aplicables en movimiento colineal subsónico.'}</p><p>Si se mueve el observador, <b>λ no es automáticamente c/f<sub>o</sub></b>; f<sub>o</sub> también incluye el movimiento del receptor.</p><h3>Mach y límites</h3><div class="equation">M = |v<sub>f</sub>|/c = ${fmt(m.M,4)} ${m.mu!==null?'· μ = arcsen(1/M) = '+fmt(m.mu*180/Math.PI,3)+'°':''}</div><p>${m.M>=1?'Régimen sónico o supersónico: pueden existir ramas múltiples, inversión de orden y concentraciones. Una singularidad no significa tono audible infinito. La envolvente no calcula presión de choque.':'Régimen subsónico: la rama regular permite una predicción física de frecuencia.'}</p>`;
}
function graphSeries(){const total=model.total,stops=140,arr=[];
 for(let j=0;j<=stops;j++){const tt=total*j/stops,src=P.at(cfg.source,cfg.vs,tt),obs=P.at(cfg.observer,cfg.vo,tt),br=P.retardedBranches(cfg,tt),single=br.length===1&&br[0].kind==='regular'?br[0].value:null;arr.push({t:tt,sx:src.x,ox:obs.x,dist:P.norm(P.sub(src,obs)),observed:single});}return arr;}
function drawPlot(){if(!cfg)return;const dim=resizeOne(plot,pctx),w=dim.w,h=dim.h;if(w<50||h<50)return;
 const dark=document.documentElement.dataset.theme==='dark';const ink=dark?'#bcd8e4':'#537386',axis=dark?'#365264':'#e1eaf0';pctx.clearRect(0,0,w,h);pctx.fillStyle=dark?'#192c3b':'#fff';pctx.fillRect(0,0,w,h);
 const type=$('graph-type').value,series=graphSeries(),left=49,right=w-14,top=22,bottom=h-31;
 const curves=[];let ymin=Infinity,ymax=-Infinity,title='';
 if(type==='positions'){title='Posición x (m)';curves.push({label:'Fuente x',color:'#e48b49',vals:series.map(p=>[p.t,p.sx])},{label:'Observador x',color:'#0a9488',vals:series.map(p=>[p.t,p.ox])});}
 if(type==='distance'){title='Distancia (m)';curves.push({label:'Separación',color:'#2687b5',vals:series.map(p=>[p.t,p.dist])});}
 if(type==='frequency'){title='Frecuencia (Hz)';curves.push({label:'Emitida',color:'#e48b49',vals:series.map(p=>[p.t,cfg.f])},{label:'Recibida (teórica)',color:'#0a9488',vals:series.filter(p=>Number.isFinite(p.observed)&&p.observed>0).map(p=>[p.t,p.observed]),breakGaps:true});}
 if(type==='events'){title='Tiempo de emisión / llegada (s)';curves.push({label:'Emisión tₑ',color:'#e48b49',vals:model.waves.map(p=>[p.te,p.te]),dots:true},{label:'Llegada tᵣ según emisión',color:'#0a9488',vals:model.receptions.map(p=>[p.te,p.tr]),dots:true});}
 if(type==='intervals'){title='Intervalo entre llegadas (s)';curves.push({label:'Δ recepción',color:'#2687b5',vals:model.receptions.filter(p=>p.interval!==null&&p.interval>1e-7).map(p=>[p.tr,p.interval]),dots:true});}
 for(const c of curves)for(const p of c.vals)if(Number.isFinite(p[1])){ymin=Math.min(ymin,p[1]);ymax=Math.max(ymax,p[1]);}
 if(!Number.isFinite(ymin)){ymin=0;ymax=1;}if(ymin===ymax){const pad=Math.max(Math.abs(ymin)*.15,.1);ymin-=pad;ymax+=pad;}else{const pad=(ymax-ymin)*.14;ymin-=pad;ymax+=pad;}
 const X=x=>left+(x/model.total)*(right-left),Y=y=>bottom-(y-ymin)/(ymax-ymin)*(bottom-top);
 pctx.lineWidth=1;pctx.strokeStyle=axis;pctx.font='10px Segoe UI,Arial';pctx.fillStyle=ink;
 for(let k=0;k<=4;k++){const y=bottom-(bottom-top)*k/4;pctx.beginPath();pctx.moveTo(left,y);pctx.lineTo(right,y);pctx.stroke();pctx.textAlign='right';pctx.fillText(fmt(ymin+(ymax-ymin)*k/4,1),left-6,y+3);}
 for(let k=0;k<=5;k++){const x=left+(right-left)*k/5;pctx.beginPath();pctx.moveTo(x,top);pctx.lineTo(x,bottom);pctx.stroke();pctx.textAlign='center';pctx.fillText(fmt(model.total*k/5,1),x,bottom+15);}
 pctx.fillStyle=ink;pctx.textAlign='left';pctx.fillText(title,left,12);pctx.textAlign='right';pctx.fillText(type==='events'?'t emisión (s)':'t (s)',right,bottom+27);
 curves.forEach((c,i)=>{pctx.strokeStyle=c.color;pctx.fillStyle=c.color;pctx.lineWidth=2;pctx.beginPath();let started=false,prevX=null;
 for(const [a,b] of c.vals){if(!Number.isFinite(a)||!Number.isFinite(b))continue;const x=X(a),y=Y(b);if(!started||(c.breakGaps&&prevX!==null&&a-prevX>model.total/100)){pctx.moveTo(x,y);}else pctx.lineTo(x,y);started=true;prevX=a;}pctx.stroke();if(c.dots)for(const [a,b] of c.vals){if(!Number.isFinite(b))continue;pctx.beginPath();pctx.arc(X(a),Y(b),2.4,0,Math.PI*2);pctx.fill();}
 const xLabel=left+14+i*Math.min(145,(w-80)/Math.max(1,curves.length));pctx.fillStyle=c.color;pctx.fillRect(xLabel,top+8,12,3);pctx.fillStyle=ink;pctx.font='10px Segoe UI,Arial';pctx.textAlign='left';pctx.fillText(c.label,xLabel+16,top+13);
 });
 pctx.save();pctx.setLineDash([4,5]);pctx.strokeStyle=dark?'#ffffff':'#192e3c';pctx.beginPath();pctx.moveTo(X(t),top);pctx.lineTo(X(t),bottom);pctx.stroke();pctx.restore();
}
$('graph-type').onchange=drawPlot;
function downloadData(filename,text,mime){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([text],{type:mime}));a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('export-csv').onclick=()=>{let text='id;emision_s;centro_x_m;centro_y_m;llegada_s;delta_llegadas_s;frecuencia_medida_Hz;prediccion_rama_Hz;tipo_rama;recibido_al_instante\n';for(const wave of model.waves){const r=model.receptions.find(x=>x.id===wave.id),p=P.predictionForWave(cfg,wave);text+=[wave.id,wave.te,wave.center.x,wave.center.y,wave.tr??'',r?.interval??'',r?.measured??'',p.value??'',p.kind,wave.tr!==null&&wave.tr<=t?1:0].join(';')+'\n';}downloadData('efecto_doppler_datos.csv','\ufeff'+text,'text/csv;charset=utf-8');alertToast('Datos CSV exportados.');};
$('export-png').onclick=()=>{drawScene();scene.toBlob(b=>{if(!b){alertToast('No fue posible exportar PNG');return;}const u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download='experimento_doppler.png';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);},'image/png');};
$('source-icon').onchange=e=>{sourceIcon=e.target.value;drawAll();};
$('show-grid').onchange=e=>{showGrid=e.target.checked;drawAll();};$('show-vectors').onchange=e=>{showVectors=e.target.checked;drawAll();};$('follow-source').onchange=e=>{followSource=e.target.checked;drawAll();};
$('wave-color').oninput=e=>{waveStyle.color=e.target.value;drawAll();};$('wave-width').oninput=e=>{waveStyle.width=Number(e.target.value);drawAll();};$('wave-dash').onchange=e=>{waveStyle.dash=e.target.value;drawAll();};$('wave-fade').onchange=e=>{waveStyle.fade=e.target.checked;drawAll();};
$('theme-btn').onclick=()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';try{localStorage.setItem('doppler-theme',document.documentElement.dataset.theme);}catch{}drawAll();};
$('help-btn').onclick=()=>$('theory-dialog').showModal();$('close-help').onclick=()=>$('theory-dialog').close();
$('fullscreen-btn').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(e){alertToast('Pantalla completa no disponible en este navegador.');}};
function stopSounds(){for(const item of activeAudio){try{item.gain.gain.cancelScheduledValues(0);item.gain.gain.setTargetAtTime(0,item.ctx.currentTime,.008);item.osc.stop(item.ctx.currentTime+.06);}catch{}}activeAudio=[];}
function ensureAudio(){if(!audioCtx){const C=window.AudioContext||window.webkitAudioContext;if(!C){alertToast('Este navegador no admite Web Audio.');return false;}audioCtx=new C();}if(audioCtx.state==='suspended')audioCtx.resume().catch(()=>{});return true;}
function playTone(hz,offset=0,seconds=.14){if(!audioEnabled||!audioCtx||!Number.isFinite(hz)||hz<70||hz>2200)return;const osc=audioCtx.createOscillator(),gain=audioCtx.createGain(),when=audioCtx.currentTime+Math.max(0,offset),vol=Number($('volume').value);osc.type='sine';osc.frequency.value=hz;gain.gain.setValueAtTime(0,when);gain.gain.linearRampToValueAtTime(vol*.18,when+.013);gain.gain.setValueAtTime(vol*.18,when+Math.max(.02,seconds-.06));gain.gain.linearRampToValueAtTime(0,when+seconds);osc.connect(gain).connect(audioCtx.destination);osc.start(when);osc.stop(when+seconds+.02);const item={osc,gain,ctx:audioCtx};activeAudio.push(item);osc.onended=()=>{activeAudio=activeAudio.filter(x=>x!==item);try{osc.disconnect();gain.disconnect();}catch{}};}
function playArrivalEvents(events,previous,speed){if(!audioEnabled||$('audio-mode').value!=='pulses'||!ensureAudio())return;for(const e of events){const lag=Math.max(0,(e.tr-previous)/speed);playTone(660,Math.min(.32,lag),.075);}}
$('audio-enabled').onchange=e=>{audioEnabled=e.target.checked;if(audioEnabled&&!ensureAudio()){audioEnabled=false;e.target.checked=false;}if(!audioEnabled)stopSounds();updateAudioText();};
$('audio-mode').onchange=()=>{stopSounds();$('tone-buttons').hidden=$('audio-mode').value!=='tone';updateAudioText();};
function updateAudioText(){const fscale=220;$('audio-note').textContent=!audioEnabled?'Desactivado. 2 Hz visuales no equivalen a un tono audible.':$('audio-mode').value==='pulses'?'Aviso breve a 660 Hz por recepción física; el tono es didáctico, solo el ritmo representa la llegada.':`Escala visible: 1 Hz simulado → ${fscale} Hz audible. Selecciona cada tono para compararlos.`;}
$('listen-emitted').onclick=()=>{if(!audioEnabled){alertToast('Activa primero el sonido.');return;}if(!ensureAudio())return;const hz=cfg.f*220;if(hz>2200){alertToast('Tono fuera del rango de sonificación 70–2200 Hz.');return;}playTone(hz,0,.85);};
$('listen-received').onclick=()=>{if(!audioEnabled){alertToast('Activa primero el sonido.');return;}const st=P.stateAt(cfg,model,t),value=latestFrequency(st);if(value===null){alertToast('No hay una única frecuencia recibida regular en este instante.');return;}const hz=value*220;if(hz<70||hz>2200){alertToast('Tono fuera del rango de sonificación 70–2200 Hz.');return;}if(ensureAudio())playTone(hz,0,.85);};
try{document.documentElement.dataset.theme=localStorage.getItem('doppler-theme')==='dark'?'dark':'light';}catch{}
showConfig();resizeCanvases();applyScenario('still');setLevel('explore');resizeCanvases();window.addEventListener('resize',resizeCanvases);if(window.ResizeObserver){new ResizeObserver(resizeCanvases).observe($('scene-wrap'));new ResizeObserver(resizeCanvases).observe(plot);}
if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)pause();
requestAnimationFrame(advance);
})();
